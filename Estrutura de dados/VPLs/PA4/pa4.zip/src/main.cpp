#include <iostream>
#include <vector>
#include "unionFind.hpp"

using namespace std;

int main() {
    int n, m;
    cin >> n >> m;

    vector<Aresta> arestas(m);

    for (int i = 0; i < m; i++) {
        cin >> arestas[i].u >> arestas[i].v >> arestas[i].custo;
    }

    int resultado = arvoreGeradoraMinima(n, m, arestas);

    cout << resultado << endl;

    return 0;
}
