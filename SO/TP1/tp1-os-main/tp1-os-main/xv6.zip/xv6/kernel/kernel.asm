
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	0000b117          	auipc	sp,0xb
    80000004:	1a013103          	ld	sp,416(sp) # 8000b1a0 <_GLOBAL_OFFSET_TABLE_+0x8>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	076000ef          	jal	8000008c <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
// at timervec in kernelvec.S,
// which turns them into software interrupts for
// devintr() in trap.c.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
// which hart (core) is this?
static inline uint64
r_mhartid()
{
  uint64 x;
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80000022:	f14027f3          	csrr	a5,mhartid
  // each CPU has a separate source of timer interrupts.
  int id = r_mhartid();
    80000026:	0007859b          	sext.w	a1,a5

  // ask the CLINT for a timer interrupt.
  int interval = 1000000; // cycles; about 1/10th second in qemu.
  *(uint64*)CLINT_MTIMECMP(id) = *(uint64*)CLINT_MTIME + interval;
    8000002a:	0037979b          	slliw	a5,a5,0x3
    8000002e:	02004737          	lui	a4,0x2004
    80000032:	97ba                	add	a5,a5,a4
    80000034:	0200c737          	lui	a4,0x200c
    80000038:	1761                	addi	a4,a4,-8 # 200bff8 <_entry-0x7dff4008>
    8000003a:	6318                	ld	a4,0(a4)
    8000003c:	000f4637          	lui	a2,0xf4
    80000040:	24060613          	addi	a2,a2,576 # f4240 <_entry-0x7ff0bdc0>
    80000044:	9732                	add	a4,a4,a2
    80000046:	e398                	sd	a4,0(a5)

  // prepare information in scratch[] for timervec.
  // scratch[0..2] : space for timervec to save registers.
  // scratch[3] : address of CLINT MTIMECMP register.
  // scratch[4] : desired interval (in cycles) between timer interrupts.
  uint64 *scratch = &timer_scratch[id][0];
    80000048:	00259693          	slli	a3,a1,0x2
    8000004c:	96ae                	add	a3,a3,a1
    8000004e:	068e                	slli	a3,a3,0x3
    80000050:	0000b717          	auipc	a4,0xb
    80000054:	1b070713          	addi	a4,a4,432 # 8000b200 <timer_scratch>
    80000058:	9736                	add	a4,a4,a3
  scratch[3] = CLINT_MTIMECMP(id);
    8000005a:	ef1c                	sd	a5,24(a4)
  scratch[4] = interval;
    8000005c:	f310                	sd	a2,32(a4)
}

static inline void 
w_mscratch(uint64 x)
{
  asm volatile("csrw mscratch, %0" : : "r" (x));
    8000005e:	34071073          	csrw	mscratch,a4
  asm volatile("csrw mtvec, %0" : : "r" (x));
    80000062:	00006797          	auipc	a5,0x6
    80000066:	d7e78793          	addi	a5,a5,-642 # 80005de0 <timervec>
    8000006a:	30579073          	csrw	mtvec,a5
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000006e:	300027f3          	csrr	a5,mstatus

  // set the machine-mode trap handler.
  w_mtvec((uint64)timervec);

  // enable machine-mode interrupts.
  w_mstatus(r_mstatus() | MSTATUS_MIE);
    80000072:	0087e793          	ori	a5,a5,8
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000076:	30079073          	csrw	mstatus,a5
  asm volatile("csrr %0, mie" : "=r" (x) );
    8000007a:	304027f3          	csrr	a5,mie

  // enable machine-mode timer interrupts.
  w_mie(r_mie() | MIE_MTIE);
    8000007e:	0807e793          	ori	a5,a5,128
  asm volatile("csrw mie, %0" : : "r" (x));
    80000082:	30479073          	csrw	mie,a5
}
    80000086:	6422                	ld	s0,8(sp)
    80000088:	0141                	addi	sp,sp,16
    8000008a:	8082                	ret

000000008000008c <start>:
{
    8000008c:	1141                	addi	sp,sp,-16
    8000008e:	e406                	sd	ra,8(sp)
    80000090:	e022                	sd	s0,0(sp)
    80000092:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000094:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000098:	7779                	lui	a4,0xffffe
    8000009a:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffda117>
    8000009e:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    800000a0:	6705                	lui	a4,0x1
    800000a2:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    800000a6:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    800000a8:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    800000ac:	00001797          	auipc	a5,0x1
    800000b0:	e2678793          	addi	a5,a5,-474 # 80000ed2 <main>
    800000b4:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    800000b8:	4781                	li	a5,0
    800000ba:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    800000be:	67c1                	lui	a5,0x10
    800000c0:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    800000c2:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    800000c6:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000ca:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    800000ce:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    800000d2:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000d6:	57fd                	li	a5,-1
    800000d8:	83a9                	srli	a5,a5,0xa
    800000da:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000de:	47bd                	li	a5,15
    800000e0:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000e4:	00000097          	auipc	ra,0x0
    800000e8:	f38080e7          	jalr	-200(ra) # 8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000ec:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000f0:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000f2:	823e                	mv	tp,a5
  asm volatile("mret");
    800000f4:	30200073          	mret
}
    800000f8:	60a2                	ld	ra,8(sp)
    800000fa:	6402                	ld	s0,0(sp)
    800000fc:	0141                	addi	sp,sp,16
    800000fe:	8082                	ret

0000000080000100 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80000100:	715d                	addi	sp,sp,-80
    80000102:	e486                	sd	ra,72(sp)
    80000104:	e0a2                	sd	s0,64(sp)
    80000106:	f84a                	sd	s2,48(sp)
    80000108:	0880                	addi	s0,sp,80
  int i;

  for(i = 0; i < n; i++){
    8000010a:	04c05663          	blez	a2,80000156 <consolewrite+0x56>
    8000010e:	fc26                	sd	s1,56(sp)
    80000110:	f44e                	sd	s3,40(sp)
    80000112:	f052                	sd	s4,32(sp)
    80000114:	ec56                	sd	s5,24(sp)
    80000116:	8a2a                	mv	s4,a0
    80000118:	84ae                	mv	s1,a1
    8000011a:	89b2                	mv	s3,a2
    8000011c:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    8000011e:	5afd                	li	s5,-1
    80000120:	4685                	li	a3,1
    80000122:	8626                	mv	a2,s1
    80000124:	85d2                	mv	a1,s4
    80000126:	fbf40513          	addi	a0,s0,-65
    8000012a:	00002097          	auipc	ra,0x2
    8000012e:	440080e7          	jalr	1088(ra) # 8000256a <either_copyin>
    80000132:	03550463          	beq	a0,s5,8000015a <consolewrite+0x5a>
      break;
    uartputc(c);
    80000136:	fbf44503          	lbu	a0,-65(s0)
    8000013a:	00000097          	auipc	ra,0x0
    8000013e:	7e4080e7          	jalr	2020(ra) # 8000091e <uartputc>
  for(i = 0; i < n; i++){
    80000142:	2905                	addiw	s2,s2,1
    80000144:	0485                	addi	s1,s1,1
    80000146:	fd299de3          	bne	s3,s2,80000120 <consolewrite+0x20>
    8000014a:	894e                	mv	s2,s3
    8000014c:	74e2                	ld	s1,56(sp)
    8000014e:	79a2                	ld	s3,40(sp)
    80000150:	7a02                	ld	s4,32(sp)
    80000152:	6ae2                	ld	s5,24(sp)
    80000154:	a039                	j	80000162 <consolewrite+0x62>
    80000156:	4901                	li	s2,0
    80000158:	a029                	j	80000162 <consolewrite+0x62>
    8000015a:	74e2                	ld	s1,56(sp)
    8000015c:	79a2                	ld	s3,40(sp)
    8000015e:	7a02                	ld	s4,32(sp)
    80000160:	6ae2                	ld	s5,24(sp)
  }

  return i;
}
    80000162:	854a                	mv	a0,s2
    80000164:	60a6                	ld	ra,72(sp)
    80000166:	6406                	ld	s0,64(sp)
    80000168:	7942                	ld	s2,48(sp)
    8000016a:	6161                	addi	sp,sp,80
    8000016c:	8082                	ret

000000008000016e <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000016e:	711d                	addi	sp,sp,-96
    80000170:	ec86                	sd	ra,88(sp)
    80000172:	e8a2                	sd	s0,80(sp)
    80000174:	e4a6                	sd	s1,72(sp)
    80000176:	e0ca                	sd	s2,64(sp)
    80000178:	fc4e                	sd	s3,56(sp)
    8000017a:	f852                	sd	s4,48(sp)
    8000017c:	f456                	sd	s5,40(sp)
    8000017e:	f05a                	sd	s6,32(sp)
    80000180:	1080                	addi	s0,sp,96
    80000182:	8aaa                	mv	s5,a0
    80000184:	8a2e                	mv	s4,a1
    80000186:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000188:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    8000018c:	00013517          	auipc	a0,0x13
    80000190:	1b450513          	addi	a0,a0,436 # 80013340 <cons>
    80000194:	00001097          	auipc	ra,0x1
    80000198:	aa4080e7          	jalr	-1372(ra) # 80000c38 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000019c:	00013497          	auipc	s1,0x13
    800001a0:	1a448493          	addi	s1,s1,420 # 80013340 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a4:	00013917          	auipc	s2,0x13
    800001a8:	23490913          	addi	s2,s2,564 # 800133d8 <cons+0x98>
  while(n > 0){
    800001ac:	0d305763          	blez	s3,8000027a <consoleread+0x10c>
    while(cons.r == cons.w){
    800001b0:	0984a783          	lw	a5,152(s1)
    800001b4:	09c4a703          	lw	a4,156(s1)
    800001b8:	0af71c63          	bne	a4,a5,80000270 <consoleread+0x102>
      if(killed(myproc())){
    800001bc:	00002097          	auipc	ra,0x2
    800001c0:	8a6080e7          	jalr	-1882(ra) # 80001a62 <myproc>
    800001c4:	00002097          	auipc	ra,0x2
    800001c8:	1f0080e7          	jalr	496(ra) # 800023b4 <killed>
    800001cc:	e52d                	bnez	a0,80000236 <consoleread+0xc8>
      sleep(&cons.r, &cons.lock);
    800001ce:	85a6                	mv	a1,s1
    800001d0:	854a                	mv	a0,s2
    800001d2:	00002097          	auipc	ra,0x2
    800001d6:	f3a080e7          	jalr	-198(ra) # 8000210c <sleep>
    while(cons.r == cons.w){
    800001da:	0984a783          	lw	a5,152(s1)
    800001de:	09c4a703          	lw	a4,156(s1)
    800001e2:	fcf70de3          	beq	a4,a5,800001bc <consoleread+0x4e>
    800001e6:	ec5e                	sd	s7,24(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001e8:	00013717          	auipc	a4,0x13
    800001ec:	15870713          	addi	a4,a4,344 # 80013340 <cons>
    800001f0:	0017869b          	addiw	a3,a5,1
    800001f4:	08d72c23          	sw	a3,152(a4)
    800001f8:	07f7f693          	andi	a3,a5,127
    800001fc:	9736                	add	a4,a4,a3
    800001fe:	01874703          	lbu	a4,24(a4)
    80000202:	00070b9b          	sext.w	s7,a4

    if(c == C('D')){  // end-of-file
    80000206:	4691                	li	a3,4
    80000208:	04db8a63          	beq	s7,a3,8000025c <consoleread+0xee>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    8000020c:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000210:	4685                	li	a3,1
    80000212:	faf40613          	addi	a2,s0,-81
    80000216:	85d2                	mv	a1,s4
    80000218:	8556                	mv	a0,s5
    8000021a:	00002097          	auipc	ra,0x2
    8000021e:	2fa080e7          	jalr	762(ra) # 80002514 <either_copyout>
    80000222:	57fd                	li	a5,-1
    80000224:	04f50a63          	beq	a0,a5,80000278 <consoleread+0x10a>
      break;

    dst++;
    80000228:	0a05                	addi	s4,s4,1
    --n;
    8000022a:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    8000022c:	47a9                	li	a5,10
    8000022e:	06fb8163          	beq	s7,a5,80000290 <consoleread+0x122>
    80000232:	6be2                	ld	s7,24(sp)
    80000234:	bfa5                	j	800001ac <consoleread+0x3e>
        release(&cons.lock);
    80000236:	00013517          	auipc	a0,0x13
    8000023a:	10a50513          	addi	a0,a0,266 # 80013340 <cons>
    8000023e:	00001097          	auipc	ra,0x1
    80000242:	aae080e7          	jalr	-1362(ra) # 80000cec <release>
        return -1;
    80000246:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000248:	60e6                	ld	ra,88(sp)
    8000024a:	6446                	ld	s0,80(sp)
    8000024c:	64a6                	ld	s1,72(sp)
    8000024e:	6906                	ld	s2,64(sp)
    80000250:	79e2                	ld	s3,56(sp)
    80000252:	7a42                	ld	s4,48(sp)
    80000254:	7aa2                	ld	s5,40(sp)
    80000256:	7b02                	ld	s6,32(sp)
    80000258:	6125                	addi	sp,sp,96
    8000025a:	8082                	ret
      if(n < target){
    8000025c:	0009871b          	sext.w	a4,s3
    80000260:	01677a63          	bgeu	a4,s6,80000274 <consoleread+0x106>
        cons.r--;
    80000264:	00013717          	auipc	a4,0x13
    80000268:	16f72a23          	sw	a5,372(a4) # 800133d8 <cons+0x98>
    8000026c:	6be2                	ld	s7,24(sp)
    8000026e:	a031                	j	8000027a <consoleread+0x10c>
    80000270:	ec5e                	sd	s7,24(sp)
    80000272:	bf9d                	j	800001e8 <consoleread+0x7a>
    80000274:	6be2                	ld	s7,24(sp)
    80000276:	a011                	j	8000027a <consoleread+0x10c>
    80000278:	6be2                	ld	s7,24(sp)
  release(&cons.lock);
    8000027a:	00013517          	auipc	a0,0x13
    8000027e:	0c650513          	addi	a0,a0,198 # 80013340 <cons>
    80000282:	00001097          	auipc	ra,0x1
    80000286:	a6a080e7          	jalr	-1430(ra) # 80000cec <release>
  return target - n;
    8000028a:	413b053b          	subw	a0,s6,s3
    8000028e:	bf6d                	j	80000248 <consoleread+0xda>
    80000290:	6be2                	ld	s7,24(sp)
    80000292:	b7e5                	j	8000027a <consoleread+0x10c>

0000000080000294 <consputc>:
{
    80000294:	1141                	addi	sp,sp,-16
    80000296:	e406                	sd	ra,8(sp)
    80000298:	e022                	sd	s0,0(sp)
    8000029a:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    8000029c:	10000793          	li	a5,256
    800002a0:	00f50a63          	beq	a0,a5,800002b4 <consputc+0x20>
    uartputc_sync(c);
    800002a4:	00000097          	auipc	ra,0x0
    800002a8:	59c080e7          	jalr	1436(ra) # 80000840 <uartputc_sync>
}
    800002ac:	60a2                	ld	ra,8(sp)
    800002ae:	6402                	ld	s0,0(sp)
    800002b0:	0141                	addi	sp,sp,16
    800002b2:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    800002b4:	4521                	li	a0,8
    800002b6:	00000097          	auipc	ra,0x0
    800002ba:	58a080e7          	jalr	1418(ra) # 80000840 <uartputc_sync>
    800002be:	02000513          	li	a0,32
    800002c2:	00000097          	auipc	ra,0x0
    800002c6:	57e080e7          	jalr	1406(ra) # 80000840 <uartputc_sync>
    800002ca:	4521                	li	a0,8
    800002cc:	00000097          	auipc	ra,0x0
    800002d0:	574080e7          	jalr	1396(ra) # 80000840 <uartputc_sync>
    800002d4:	bfe1                	j	800002ac <consputc+0x18>

00000000800002d6 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002d6:	1101                	addi	sp,sp,-32
    800002d8:	ec06                	sd	ra,24(sp)
    800002da:	e822                	sd	s0,16(sp)
    800002dc:	e426                	sd	s1,8(sp)
    800002de:	1000                	addi	s0,sp,32
    800002e0:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002e2:	00013517          	auipc	a0,0x13
    800002e6:	05e50513          	addi	a0,a0,94 # 80013340 <cons>
    800002ea:	00001097          	auipc	ra,0x1
    800002ee:	94e080e7          	jalr	-1714(ra) # 80000c38 <acquire>

  switch(c){
    800002f2:	47d5                	li	a5,21
    800002f4:	0af48563          	beq	s1,a5,8000039e <consoleintr+0xc8>
    800002f8:	0297c963          	blt	a5,s1,8000032a <consoleintr+0x54>
    800002fc:	47a1                	li	a5,8
    800002fe:	0ef48c63          	beq	s1,a5,800003f6 <consoleintr+0x120>
    80000302:	47c1                	li	a5,16
    80000304:	10f49f63          	bne	s1,a5,80000422 <consoleintr+0x14c>
  case C('P'):  // Print process list.
    procdump();
    80000308:	00002097          	auipc	ra,0x2
    8000030c:	2b8080e7          	jalr	696(ra) # 800025c0 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    80000310:	00013517          	auipc	a0,0x13
    80000314:	03050513          	addi	a0,a0,48 # 80013340 <cons>
    80000318:	00001097          	auipc	ra,0x1
    8000031c:	9d4080e7          	jalr	-1580(ra) # 80000cec <release>
}
    80000320:	60e2                	ld	ra,24(sp)
    80000322:	6442                	ld	s0,16(sp)
    80000324:	64a2                	ld	s1,8(sp)
    80000326:	6105                	addi	sp,sp,32
    80000328:	8082                	ret
  switch(c){
    8000032a:	07f00793          	li	a5,127
    8000032e:	0cf48463          	beq	s1,a5,800003f6 <consoleintr+0x120>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80000332:	00013717          	auipc	a4,0x13
    80000336:	00e70713          	addi	a4,a4,14 # 80013340 <cons>
    8000033a:	0a072783          	lw	a5,160(a4)
    8000033e:	09872703          	lw	a4,152(a4)
    80000342:	9f99                	subw	a5,a5,a4
    80000344:	07f00713          	li	a4,127
    80000348:	fcf764e3          	bltu	a4,a5,80000310 <consoleintr+0x3a>
      c = (c == '\r') ? '\n' : c;
    8000034c:	47b5                	li	a5,13
    8000034e:	0cf48d63          	beq	s1,a5,80000428 <consoleintr+0x152>
      consputc(c);
    80000352:	8526                	mv	a0,s1
    80000354:	00000097          	auipc	ra,0x0
    80000358:	f40080e7          	jalr	-192(ra) # 80000294 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    8000035c:	00013797          	auipc	a5,0x13
    80000360:	fe478793          	addi	a5,a5,-28 # 80013340 <cons>
    80000364:	0a07a683          	lw	a3,160(a5)
    80000368:	0016871b          	addiw	a4,a3,1
    8000036c:	0007061b          	sext.w	a2,a4
    80000370:	0ae7a023          	sw	a4,160(a5)
    80000374:	07f6f693          	andi	a3,a3,127
    80000378:	97b6                	add	a5,a5,a3
    8000037a:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    8000037e:	47a9                	li	a5,10
    80000380:	0cf48b63          	beq	s1,a5,80000456 <consoleintr+0x180>
    80000384:	4791                	li	a5,4
    80000386:	0cf48863          	beq	s1,a5,80000456 <consoleintr+0x180>
    8000038a:	00013797          	auipc	a5,0x13
    8000038e:	04e7a783          	lw	a5,78(a5) # 800133d8 <cons+0x98>
    80000392:	9f1d                	subw	a4,a4,a5
    80000394:	08000793          	li	a5,128
    80000398:	f6f71ce3          	bne	a4,a5,80000310 <consoleintr+0x3a>
    8000039c:	a86d                	j	80000456 <consoleintr+0x180>
    8000039e:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    800003a0:	00013717          	auipc	a4,0x13
    800003a4:	fa070713          	addi	a4,a4,-96 # 80013340 <cons>
    800003a8:	0a072783          	lw	a5,160(a4)
    800003ac:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800003b0:	00013497          	auipc	s1,0x13
    800003b4:	f9048493          	addi	s1,s1,-112 # 80013340 <cons>
    while(cons.e != cons.w &&
    800003b8:	4929                	li	s2,10
    800003ba:	02f70a63          	beq	a4,a5,800003ee <consoleintr+0x118>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800003be:	37fd                	addiw	a5,a5,-1
    800003c0:	07f7f713          	andi	a4,a5,127
    800003c4:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    800003c6:	01874703          	lbu	a4,24(a4)
    800003ca:	03270463          	beq	a4,s2,800003f2 <consoleintr+0x11c>
      cons.e--;
    800003ce:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003d2:	10000513          	li	a0,256
    800003d6:	00000097          	auipc	ra,0x0
    800003da:	ebe080e7          	jalr	-322(ra) # 80000294 <consputc>
    while(cons.e != cons.w &&
    800003de:	0a04a783          	lw	a5,160(s1)
    800003e2:	09c4a703          	lw	a4,156(s1)
    800003e6:	fcf71ce3          	bne	a4,a5,800003be <consoleintr+0xe8>
    800003ea:	6902                	ld	s2,0(sp)
    800003ec:	b715                	j	80000310 <consoleintr+0x3a>
    800003ee:	6902                	ld	s2,0(sp)
    800003f0:	b705                	j	80000310 <consoleintr+0x3a>
    800003f2:	6902                	ld	s2,0(sp)
    800003f4:	bf31                	j	80000310 <consoleintr+0x3a>
    if(cons.e != cons.w){
    800003f6:	00013717          	auipc	a4,0x13
    800003fa:	f4a70713          	addi	a4,a4,-182 # 80013340 <cons>
    800003fe:	0a072783          	lw	a5,160(a4)
    80000402:	09c72703          	lw	a4,156(a4)
    80000406:	f0f705e3          	beq	a4,a5,80000310 <consoleintr+0x3a>
      cons.e--;
    8000040a:	37fd                	addiw	a5,a5,-1
    8000040c:	00013717          	auipc	a4,0x13
    80000410:	fcf72a23          	sw	a5,-44(a4) # 800133e0 <cons+0xa0>
      consputc(BACKSPACE);
    80000414:	10000513          	li	a0,256
    80000418:	00000097          	auipc	ra,0x0
    8000041c:	e7c080e7          	jalr	-388(ra) # 80000294 <consputc>
    80000420:	bdc5                	j	80000310 <consoleintr+0x3a>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80000422:	ee0487e3          	beqz	s1,80000310 <consoleintr+0x3a>
    80000426:	b731                	j	80000332 <consoleintr+0x5c>
      consputc(c);
    80000428:	4529                	li	a0,10
    8000042a:	00000097          	auipc	ra,0x0
    8000042e:	e6a080e7          	jalr	-406(ra) # 80000294 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000432:	00013797          	auipc	a5,0x13
    80000436:	f0e78793          	addi	a5,a5,-242 # 80013340 <cons>
    8000043a:	0a07a703          	lw	a4,160(a5)
    8000043e:	0017069b          	addiw	a3,a4,1
    80000442:	0006861b          	sext.w	a2,a3
    80000446:	0ad7a023          	sw	a3,160(a5)
    8000044a:	07f77713          	andi	a4,a4,127
    8000044e:	97ba                	add	a5,a5,a4
    80000450:	4729                	li	a4,10
    80000452:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80000456:	00013797          	auipc	a5,0x13
    8000045a:	f8c7a323          	sw	a2,-122(a5) # 800133dc <cons+0x9c>
        wakeup(&cons.r);
    8000045e:	00013517          	auipc	a0,0x13
    80000462:	f7a50513          	addi	a0,a0,-134 # 800133d8 <cons+0x98>
    80000466:	00002097          	auipc	ra,0x2
    8000046a:	d0a080e7          	jalr	-758(ra) # 80002170 <wakeup>
    8000046e:	b54d                	j	80000310 <consoleintr+0x3a>

0000000080000470 <consoleinit>:

void
consoleinit(void)
{
    80000470:	1141                	addi	sp,sp,-16
    80000472:	e406                	sd	ra,8(sp)
    80000474:	e022                	sd	s0,0(sp)
    80000476:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000478:	00008597          	auipc	a1,0x8
    8000047c:	b9858593          	addi	a1,a1,-1128 # 80008010 <etext+0x10>
    80000480:	00013517          	auipc	a0,0x13
    80000484:	ec050513          	addi	a0,a0,-320 # 80013340 <cons>
    80000488:	00000097          	auipc	ra,0x0
    8000048c:	720080e7          	jalr	1824(ra) # 80000ba8 <initlock>

  uartinit();
    80000490:	00000097          	auipc	ra,0x0
    80000494:	354080e7          	jalr	852(ra) # 800007e4 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000498:	00023797          	auipc	a5,0x23
    8000049c:	0b878793          	addi	a5,a5,184 # 80023550 <devsw>
    800004a0:	00000717          	auipc	a4,0x0
    800004a4:	cce70713          	addi	a4,a4,-818 # 8000016e <consoleread>
    800004a8:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    800004aa:	00000717          	auipc	a4,0x0
    800004ae:	c5670713          	addi	a4,a4,-938 # 80000100 <consolewrite>
    800004b2:	ef98                	sd	a4,24(a5)
}
    800004b4:	60a2                	ld	ra,8(sp)
    800004b6:	6402                	ld	s0,0(sp)
    800004b8:	0141                	addi	sp,sp,16
    800004ba:	8082                	ret

00000000800004bc <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(int xx, int base, int sign)
{
    800004bc:	7179                	addi	sp,sp,-48
    800004be:	f406                	sd	ra,40(sp)
    800004c0:	f022                	sd	s0,32(sp)
    800004c2:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  uint x;

  if(sign && (sign = xx < 0))
    800004c4:	c219                	beqz	a2,800004ca <printint+0xe>
    800004c6:	08054963          	bltz	a0,80000558 <printint+0x9c>
    x = -xx;
  else
    x = xx;
    800004ca:	2501                	sext.w	a0,a0
    800004cc:	4881                	li	a7,0
    800004ce:	fd040693          	addi	a3,s0,-48

  i = 0;
    800004d2:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    800004d4:	2581                	sext.w	a1,a1
    800004d6:	00008617          	auipc	a2,0x8
    800004da:	27260613          	addi	a2,a2,626 # 80008748 <digits>
    800004de:	883a                	mv	a6,a4
    800004e0:	2705                	addiw	a4,a4,1
    800004e2:	02b577bb          	remuw	a5,a0,a1
    800004e6:	1782                	slli	a5,a5,0x20
    800004e8:	9381                	srli	a5,a5,0x20
    800004ea:	97b2                	add	a5,a5,a2
    800004ec:	0007c783          	lbu	a5,0(a5)
    800004f0:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    800004f4:	0005079b          	sext.w	a5,a0
    800004f8:	02b5553b          	divuw	a0,a0,a1
    800004fc:	0685                	addi	a3,a3,1
    800004fe:	feb7f0e3          	bgeu	a5,a1,800004de <printint+0x22>

  if(sign)
    80000502:	00088c63          	beqz	a7,8000051a <printint+0x5e>
    buf[i++] = '-';
    80000506:	fe070793          	addi	a5,a4,-32
    8000050a:	00878733          	add	a4,a5,s0
    8000050e:	02d00793          	li	a5,45
    80000512:	fef70823          	sb	a5,-16(a4)
    80000516:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
    8000051a:	02e05b63          	blez	a4,80000550 <printint+0x94>
    8000051e:	ec26                	sd	s1,24(sp)
    80000520:	e84a                	sd	s2,16(sp)
    80000522:	fd040793          	addi	a5,s0,-48
    80000526:	00e784b3          	add	s1,a5,a4
    8000052a:	fff78913          	addi	s2,a5,-1
    8000052e:	993a                	add	s2,s2,a4
    80000530:	377d                	addiw	a4,a4,-1
    80000532:	1702                	slli	a4,a4,0x20
    80000534:	9301                	srli	a4,a4,0x20
    80000536:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    8000053a:	fff4c503          	lbu	a0,-1(s1)
    8000053e:	00000097          	auipc	ra,0x0
    80000542:	d56080e7          	jalr	-682(ra) # 80000294 <consputc>
  while(--i >= 0)
    80000546:	14fd                	addi	s1,s1,-1
    80000548:	ff2499e3          	bne	s1,s2,8000053a <printint+0x7e>
    8000054c:	64e2                	ld	s1,24(sp)
    8000054e:	6942                	ld	s2,16(sp)
}
    80000550:	70a2                	ld	ra,40(sp)
    80000552:	7402                	ld	s0,32(sp)
    80000554:	6145                	addi	sp,sp,48
    80000556:	8082                	ret
    x = -xx;
    80000558:	40a0053b          	negw	a0,a0
  if(sign && (sign = xx < 0))
    8000055c:	4885                	li	a7,1
    x = -xx;
    8000055e:	bf85                	j	800004ce <printint+0x12>

0000000080000560 <panic>:
    release(&pr.lock);
}

void
panic(char *s)
{
    80000560:	1101                	addi	sp,sp,-32
    80000562:	ec06                	sd	ra,24(sp)
    80000564:	e822                	sd	s0,16(sp)
    80000566:	e426                	sd	s1,8(sp)
    80000568:	1000                	addi	s0,sp,32
    8000056a:	84aa                	mv	s1,a0
  pr.locking = 0;
    8000056c:	00013797          	auipc	a5,0x13
    80000570:	e807aa23          	sw	zero,-364(a5) # 80013400 <pr+0x18>
  printf("panic: ");
    80000574:	00008517          	auipc	a0,0x8
    80000578:	aa450513          	addi	a0,a0,-1372 # 80008018 <etext+0x18>
    8000057c:	00000097          	auipc	ra,0x0
    80000580:	02e080e7          	jalr	46(ra) # 800005aa <printf>
  printf(s);
    80000584:	8526                	mv	a0,s1
    80000586:	00000097          	auipc	ra,0x0
    8000058a:	024080e7          	jalr	36(ra) # 800005aa <printf>
  printf("\n");
    8000058e:	00008517          	auipc	a0,0x8
    80000592:	a9250513          	addi	a0,a0,-1390 # 80008020 <etext+0x20>
    80000596:	00000097          	auipc	ra,0x0
    8000059a:	014080e7          	jalr	20(ra) # 800005aa <printf>
  panicked = 1; // freeze uart output from other CPUs
    8000059e:	4785                	li	a5,1
    800005a0:	0000b717          	auipc	a4,0xb
    800005a4:	c2f72023          	sw	a5,-992(a4) # 8000b1c0 <panicked>
  for(;;)
    800005a8:	a001                	j	800005a8 <panic+0x48>

00000000800005aa <printf>:
{
    800005aa:	7131                	addi	sp,sp,-192
    800005ac:	fc86                	sd	ra,120(sp)
    800005ae:	f8a2                	sd	s0,112(sp)
    800005b0:	e8d2                	sd	s4,80(sp)
    800005b2:	f06a                	sd	s10,32(sp)
    800005b4:	0100                	addi	s0,sp,128
    800005b6:	8a2a                	mv	s4,a0
    800005b8:	e40c                	sd	a1,8(s0)
    800005ba:	e810                	sd	a2,16(s0)
    800005bc:	ec14                	sd	a3,24(s0)
    800005be:	f018                	sd	a4,32(s0)
    800005c0:	f41c                	sd	a5,40(s0)
    800005c2:	03043823          	sd	a6,48(s0)
    800005c6:	03143c23          	sd	a7,56(s0)
  locking = pr.locking;
    800005ca:	00013d17          	auipc	s10,0x13
    800005ce:	e36d2d03          	lw	s10,-458(s10) # 80013400 <pr+0x18>
  if(locking)
    800005d2:	040d1463          	bnez	s10,8000061a <printf+0x70>
  if (fmt == 0)
    800005d6:	040a0b63          	beqz	s4,8000062c <printf+0x82>
  va_start(ap, fmt);
    800005da:	00840793          	addi	a5,s0,8
    800005de:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    800005e2:	000a4503          	lbu	a0,0(s4)
    800005e6:	18050b63          	beqz	a0,8000077c <printf+0x1d2>
    800005ea:	f4a6                	sd	s1,104(sp)
    800005ec:	f0ca                	sd	s2,96(sp)
    800005ee:	ecce                	sd	s3,88(sp)
    800005f0:	e4d6                	sd	s5,72(sp)
    800005f2:	e0da                	sd	s6,64(sp)
    800005f4:	fc5e                	sd	s7,56(sp)
    800005f6:	f862                	sd	s8,48(sp)
    800005f8:	f466                	sd	s9,40(sp)
    800005fa:	ec6e                	sd	s11,24(sp)
    800005fc:	4981                	li	s3,0
    if(c != '%'){
    800005fe:	02500b13          	li	s6,37
    switch(c){
    80000602:	07000b93          	li	s7,112
  consputc('x');
    80000606:	4cc1                	li	s9,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000608:	00008a97          	auipc	s5,0x8
    8000060c:	140a8a93          	addi	s5,s5,320 # 80008748 <digits>
    switch(c){
    80000610:	07300c13          	li	s8,115
    80000614:	06400d93          	li	s11,100
    80000618:	a0b1                	j	80000664 <printf+0xba>
    acquire(&pr.lock);
    8000061a:	00013517          	auipc	a0,0x13
    8000061e:	dce50513          	addi	a0,a0,-562 # 800133e8 <pr>
    80000622:	00000097          	auipc	ra,0x0
    80000626:	616080e7          	jalr	1558(ra) # 80000c38 <acquire>
    8000062a:	b775                	j	800005d6 <printf+0x2c>
    8000062c:	f4a6                	sd	s1,104(sp)
    8000062e:	f0ca                	sd	s2,96(sp)
    80000630:	ecce                	sd	s3,88(sp)
    80000632:	e4d6                	sd	s5,72(sp)
    80000634:	e0da                	sd	s6,64(sp)
    80000636:	fc5e                	sd	s7,56(sp)
    80000638:	f862                	sd	s8,48(sp)
    8000063a:	f466                	sd	s9,40(sp)
    8000063c:	ec6e                	sd	s11,24(sp)
    panic("null fmt");
    8000063e:	00008517          	auipc	a0,0x8
    80000642:	9f250513          	addi	a0,a0,-1550 # 80008030 <etext+0x30>
    80000646:	00000097          	auipc	ra,0x0
    8000064a:	f1a080e7          	jalr	-230(ra) # 80000560 <panic>
      consputc(c);
    8000064e:	00000097          	auipc	ra,0x0
    80000652:	c46080e7          	jalr	-954(ra) # 80000294 <consputc>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    80000656:	2985                	addiw	s3,s3,1
    80000658:	013a07b3          	add	a5,s4,s3
    8000065c:	0007c503          	lbu	a0,0(a5)
    80000660:	10050563          	beqz	a0,8000076a <printf+0x1c0>
    if(c != '%'){
    80000664:	ff6515e3          	bne	a0,s6,8000064e <printf+0xa4>
    c = fmt[++i] & 0xff;
    80000668:	2985                	addiw	s3,s3,1
    8000066a:	013a07b3          	add	a5,s4,s3
    8000066e:	0007c783          	lbu	a5,0(a5)
    80000672:	0007849b          	sext.w	s1,a5
    if(c == 0)
    80000676:	10078b63          	beqz	a5,8000078c <printf+0x1e2>
    switch(c){
    8000067a:	05778a63          	beq	a5,s7,800006ce <printf+0x124>
    8000067e:	02fbf663          	bgeu	s7,a5,800006aa <printf+0x100>
    80000682:	09878863          	beq	a5,s8,80000712 <printf+0x168>
    80000686:	07800713          	li	a4,120
    8000068a:	0ce79563          	bne	a5,a4,80000754 <printf+0x1aa>
      printint(va_arg(ap, int), 16, 1);
    8000068e:	f8843783          	ld	a5,-120(s0)
    80000692:	00878713          	addi	a4,a5,8
    80000696:	f8e43423          	sd	a4,-120(s0)
    8000069a:	4605                	li	a2,1
    8000069c:	85e6                	mv	a1,s9
    8000069e:	4388                	lw	a0,0(a5)
    800006a0:	00000097          	auipc	ra,0x0
    800006a4:	e1c080e7          	jalr	-484(ra) # 800004bc <printint>
      break;
    800006a8:	b77d                	j	80000656 <printf+0xac>
    switch(c){
    800006aa:	09678f63          	beq	a5,s6,80000748 <printf+0x19e>
    800006ae:	0bb79363          	bne	a5,s11,80000754 <printf+0x1aa>
      printint(va_arg(ap, int), 10, 1);
    800006b2:	f8843783          	ld	a5,-120(s0)
    800006b6:	00878713          	addi	a4,a5,8
    800006ba:	f8e43423          	sd	a4,-120(s0)
    800006be:	4605                	li	a2,1
    800006c0:	45a9                	li	a1,10
    800006c2:	4388                	lw	a0,0(a5)
    800006c4:	00000097          	auipc	ra,0x0
    800006c8:	df8080e7          	jalr	-520(ra) # 800004bc <printint>
      break;
    800006cc:	b769                	j	80000656 <printf+0xac>
      printptr(va_arg(ap, uint64));
    800006ce:	f8843783          	ld	a5,-120(s0)
    800006d2:	00878713          	addi	a4,a5,8
    800006d6:	f8e43423          	sd	a4,-120(s0)
    800006da:	0007b903          	ld	s2,0(a5)
  consputc('0');
    800006de:	03000513          	li	a0,48
    800006e2:	00000097          	auipc	ra,0x0
    800006e6:	bb2080e7          	jalr	-1102(ra) # 80000294 <consputc>
  consputc('x');
    800006ea:	07800513          	li	a0,120
    800006ee:	00000097          	auipc	ra,0x0
    800006f2:	ba6080e7          	jalr	-1114(ra) # 80000294 <consputc>
    800006f6:	84e6                	mv	s1,s9
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006f8:	03c95793          	srli	a5,s2,0x3c
    800006fc:	97d6                	add	a5,a5,s5
    800006fe:	0007c503          	lbu	a0,0(a5)
    80000702:	00000097          	auipc	ra,0x0
    80000706:	b92080e7          	jalr	-1134(ra) # 80000294 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    8000070a:	0912                	slli	s2,s2,0x4
    8000070c:	34fd                	addiw	s1,s1,-1
    8000070e:	f4ed                	bnez	s1,800006f8 <printf+0x14e>
    80000710:	b799                	j	80000656 <printf+0xac>
      if((s = va_arg(ap, char*)) == 0)
    80000712:	f8843783          	ld	a5,-120(s0)
    80000716:	00878713          	addi	a4,a5,8
    8000071a:	f8e43423          	sd	a4,-120(s0)
    8000071e:	6384                	ld	s1,0(a5)
    80000720:	cc89                	beqz	s1,8000073a <printf+0x190>
      for(; *s; s++)
    80000722:	0004c503          	lbu	a0,0(s1)
    80000726:	d905                	beqz	a0,80000656 <printf+0xac>
        consputc(*s);
    80000728:	00000097          	auipc	ra,0x0
    8000072c:	b6c080e7          	jalr	-1172(ra) # 80000294 <consputc>
      for(; *s; s++)
    80000730:	0485                	addi	s1,s1,1
    80000732:	0004c503          	lbu	a0,0(s1)
    80000736:	f96d                	bnez	a0,80000728 <printf+0x17e>
    80000738:	bf39                	j	80000656 <printf+0xac>
        s = "(null)";
    8000073a:	00008497          	auipc	s1,0x8
    8000073e:	8ee48493          	addi	s1,s1,-1810 # 80008028 <etext+0x28>
      for(; *s; s++)
    80000742:	02800513          	li	a0,40
    80000746:	b7cd                	j	80000728 <printf+0x17e>
      consputc('%');
    80000748:	855a                	mv	a0,s6
    8000074a:	00000097          	auipc	ra,0x0
    8000074e:	b4a080e7          	jalr	-1206(ra) # 80000294 <consputc>
      break;
    80000752:	b711                	j	80000656 <printf+0xac>
      consputc('%');
    80000754:	855a                	mv	a0,s6
    80000756:	00000097          	auipc	ra,0x0
    8000075a:	b3e080e7          	jalr	-1218(ra) # 80000294 <consputc>
      consputc(c);
    8000075e:	8526                	mv	a0,s1
    80000760:	00000097          	auipc	ra,0x0
    80000764:	b34080e7          	jalr	-1228(ra) # 80000294 <consputc>
      break;
    80000768:	b5fd                	j	80000656 <printf+0xac>
    8000076a:	74a6                	ld	s1,104(sp)
    8000076c:	7906                	ld	s2,96(sp)
    8000076e:	69e6                	ld	s3,88(sp)
    80000770:	6aa6                	ld	s5,72(sp)
    80000772:	6b06                	ld	s6,64(sp)
    80000774:	7be2                	ld	s7,56(sp)
    80000776:	7c42                	ld	s8,48(sp)
    80000778:	7ca2                	ld	s9,40(sp)
    8000077a:	6de2                	ld	s11,24(sp)
  if(locking)
    8000077c:	020d1263          	bnez	s10,800007a0 <printf+0x1f6>
}
    80000780:	70e6                	ld	ra,120(sp)
    80000782:	7446                	ld	s0,112(sp)
    80000784:	6a46                	ld	s4,80(sp)
    80000786:	7d02                	ld	s10,32(sp)
    80000788:	6129                	addi	sp,sp,192
    8000078a:	8082                	ret
    8000078c:	74a6                	ld	s1,104(sp)
    8000078e:	7906                	ld	s2,96(sp)
    80000790:	69e6                	ld	s3,88(sp)
    80000792:	6aa6                	ld	s5,72(sp)
    80000794:	6b06                	ld	s6,64(sp)
    80000796:	7be2                	ld	s7,56(sp)
    80000798:	7c42                	ld	s8,48(sp)
    8000079a:	7ca2                	ld	s9,40(sp)
    8000079c:	6de2                	ld	s11,24(sp)
    8000079e:	bff9                	j	8000077c <printf+0x1d2>
    release(&pr.lock);
    800007a0:	00013517          	auipc	a0,0x13
    800007a4:	c4850513          	addi	a0,a0,-952 # 800133e8 <pr>
    800007a8:	00000097          	auipc	ra,0x0
    800007ac:	544080e7          	jalr	1348(ra) # 80000cec <release>
}
    800007b0:	bfc1                	j	80000780 <printf+0x1d6>

00000000800007b2 <printfinit>:
    ;
}

void
printfinit(void)
{
    800007b2:	1101                	addi	sp,sp,-32
    800007b4:	ec06                	sd	ra,24(sp)
    800007b6:	e822                	sd	s0,16(sp)
    800007b8:	e426                	sd	s1,8(sp)
    800007ba:	1000                	addi	s0,sp,32
  initlock(&pr.lock, "pr");
    800007bc:	00013497          	auipc	s1,0x13
    800007c0:	c2c48493          	addi	s1,s1,-980 # 800133e8 <pr>
    800007c4:	00008597          	auipc	a1,0x8
    800007c8:	87c58593          	addi	a1,a1,-1924 # 80008040 <etext+0x40>
    800007cc:	8526                	mv	a0,s1
    800007ce:	00000097          	auipc	ra,0x0
    800007d2:	3da080e7          	jalr	986(ra) # 80000ba8 <initlock>
  pr.locking = 1;
    800007d6:	4785                	li	a5,1
    800007d8:	cc9c                	sw	a5,24(s1)
}
    800007da:	60e2                	ld	ra,24(sp)
    800007dc:	6442                	ld	s0,16(sp)
    800007de:	64a2                	ld	s1,8(sp)
    800007e0:	6105                	addi	sp,sp,32
    800007e2:	8082                	ret

00000000800007e4 <uartinit>:

void uartstart();

void
uartinit(void)
{
    800007e4:	1141                	addi	sp,sp,-16
    800007e6:	e406                	sd	ra,8(sp)
    800007e8:	e022                	sd	s0,0(sp)
    800007ea:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    800007ec:	100007b7          	lui	a5,0x10000
    800007f0:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800007f4:	10000737          	lui	a4,0x10000
    800007f8:	f8000693          	li	a3,-128
    800007fc:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80000800:	468d                	li	a3,3
    80000802:	10000637          	lui	a2,0x10000
    80000806:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000080a:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    8000080e:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80000812:	10000737          	lui	a4,0x10000
    80000816:	461d                	li	a2,7
    80000818:	00c70123          	sb	a2,2(a4) # 10000002 <_entry-0x6ffffffe>

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000081c:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    80000820:	00008597          	auipc	a1,0x8
    80000824:	82858593          	addi	a1,a1,-2008 # 80008048 <etext+0x48>
    80000828:	00013517          	auipc	a0,0x13
    8000082c:	be050513          	addi	a0,a0,-1056 # 80013408 <uart_tx_lock>
    80000830:	00000097          	auipc	ra,0x0
    80000834:	378080e7          	jalr	888(ra) # 80000ba8 <initlock>
}
    80000838:	60a2                	ld	ra,8(sp)
    8000083a:	6402                	ld	s0,0(sp)
    8000083c:	0141                	addi	sp,sp,16
    8000083e:	8082                	ret

0000000080000840 <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    80000840:	1101                	addi	sp,sp,-32
    80000842:	ec06                	sd	ra,24(sp)
    80000844:	e822                	sd	s0,16(sp)
    80000846:	e426                	sd	s1,8(sp)
    80000848:	1000                	addi	s0,sp,32
    8000084a:	84aa                	mv	s1,a0
  push_off();
    8000084c:	00000097          	auipc	ra,0x0
    80000850:	3a0080e7          	jalr	928(ra) # 80000bec <push_off>

  if(panicked){
    80000854:	0000b797          	auipc	a5,0xb
    80000858:	96c7a783          	lw	a5,-1684(a5) # 8000b1c0 <panicked>
    8000085c:	eb85                	bnez	a5,8000088c <uartputc_sync+0x4c>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000085e:	10000737          	lui	a4,0x10000
    80000862:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000864:	00074783          	lbu	a5,0(a4)
    80000868:	0207f793          	andi	a5,a5,32
    8000086c:	dfe5                	beqz	a5,80000864 <uartputc_sync+0x24>
    ;
  WriteReg(THR, c);
    8000086e:	0ff4f513          	zext.b	a0,s1
    80000872:	100007b7          	lui	a5,0x10000
    80000876:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    8000087a:	00000097          	auipc	ra,0x0
    8000087e:	412080e7          	jalr	1042(ra) # 80000c8c <pop_off>
}
    80000882:	60e2                	ld	ra,24(sp)
    80000884:	6442                	ld	s0,16(sp)
    80000886:	64a2                	ld	s1,8(sp)
    80000888:	6105                	addi	sp,sp,32
    8000088a:	8082                	ret
    for(;;)
    8000088c:	a001                	j	8000088c <uartputc_sync+0x4c>

000000008000088e <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    8000088e:	0000b797          	auipc	a5,0xb
    80000892:	93a7b783          	ld	a5,-1734(a5) # 8000b1c8 <uart_tx_r>
    80000896:	0000b717          	auipc	a4,0xb
    8000089a:	93a73703          	ld	a4,-1734(a4) # 8000b1d0 <uart_tx_w>
    8000089e:	06f70f63          	beq	a4,a5,8000091c <uartstart+0x8e>
{
    800008a2:	7139                	addi	sp,sp,-64
    800008a4:	fc06                	sd	ra,56(sp)
    800008a6:	f822                	sd	s0,48(sp)
    800008a8:	f426                	sd	s1,40(sp)
    800008aa:	f04a                	sd	s2,32(sp)
    800008ac:	ec4e                	sd	s3,24(sp)
    800008ae:	e852                	sd	s4,16(sp)
    800008b0:	e456                	sd	s5,8(sp)
    800008b2:	e05a                	sd	s6,0(sp)
    800008b4:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    800008b6:	10000937          	lui	s2,0x10000
    800008ba:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    800008bc:	00013a97          	auipc	s5,0x13
    800008c0:	b4ca8a93          	addi	s5,s5,-1204 # 80013408 <uart_tx_lock>
    uart_tx_r += 1;
    800008c4:	0000b497          	auipc	s1,0xb
    800008c8:	90448493          	addi	s1,s1,-1788 # 8000b1c8 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    800008cc:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    800008d0:	0000b997          	auipc	s3,0xb
    800008d4:	90098993          	addi	s3,s3,-1792 # 8000b1d0 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    800008d8:	00094703          	lbu	a4,0(s2)
    800008dc:	02077713          	andi	a4,a4,32
    800008e0:	c705                	beqz	a4,80000908 <uartstart+0x7a>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    800008e2:	01f7f713          	andi	a4,a5,31
    800008e6:	9756                	add	a4,a4,s5
    800008e8:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    800008ec:	0785                	addi	a5,a5,1
    800008ee:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    800008f0:	8526                	mv	a0,s1
    800008f2:	00002097          	auipc	ra,0x2
    800008f6:	87e080e7          	jalr	-1922(ra) # 80002170 <wakeup>
    WriteReg(THR, c);
    800008fa:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    800008fe:	609c                	ld	a5,0(s1)
    80000900:	0009b703          	ld	a4,0(s3)
    80000904:	fcf71ae3          	bne	a4,a5,800008d8 <uartstart+0x4a>
  }
}
    80000908:	70e2                	ld	ra,56(sp)
    8000090a:	7442                	ld	s0,48(sp)
    8000090c:	74a2                	ld	s1,40(sp)
    8000090e:	7902                	ld	s2,32(sp)
    80000910:	69e2                	ld	s3,24(sp)
    80000912:	6a42                	ld	s4,16(sp)
    80000914:	6aa2                	ld	s5,8(sp)
    80000916:	6b02                	ld	s6,0(sp)
    80000918:	6121                	addi	sp,sp,64
    8000091a:	8082                	ret
    8000091c:	8082                	ret

000000008000091e <uartputc>:
{
    8000091e:	7179                	addi	sp,sp,-48
    80000920:	f406                	sd	ra,40(sp)
    80000922:	f022                	sd	s0,32(sp)
    80000924:	ec26                	sd	s1,24(sp)
    80000926:	e84a                	sd	s2,16(sp)
    80000928:	e44e                	sd	s3,8(sp)
    8000092a:	e052                	sd	s4,0(sp)
    8000092c:	1800                	addi	s0,sp,48
    8000092e:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    80000930:	00013517          	auipc	a0,0x13
    80000934:	ad850513          	addi	a0,a0,-1320 # 80013408 <uart_tx_lock>
    80000938:	00000097          	auipc	ra,0x0
    8000093c:	300080e7          	jalr	768(ra) # 80000c38 <acquire>
  if(panicked){
    80000940:	0000b797          	auipc	a5,0xb
    80000944:	8807a783          	lw	a5,-1920(a5) # 8000b1c0 <panicked>
    80000948:	e7c9                	bnez	a5,800009d2 <uartputc+0xb4>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000094a:	0000b717          	auipc	a4,0xb
    8000094e:	88673703          	ld	a4,-1914(a4) # 8000b1d0 <uart_tx_w>
    80000952:	0000b797          	auipc	a5,0xb
    80000956:	8767b783          	ld	a5,-1930(a5) # 8000b1c8 <uart_tx_r>
    8000095a:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    8000095e:	00013997          	auipc	s3,0x13
    80000962:	aaa98993          	addi	s3,s3,-1366 # 80013408 <uart_tx_lock>
    80000966:	0000b497          	auipc	s1,0xb
    8000096a:	86248493          	addi	s1,s1,-1950 # 8000b1c8 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000096e:	0000b917          	auipc	s2,0xb
    80000972:	86290913          	addi	s2,s2,-1950 # 8000b1d0 <uart_tx_w>
    80000976:	00e79f63          	bne	a5,a4,80000994 <uartputc+0x76>
    sleep(&uart_tx_r, &uart_tx_lock);
    8000097a:	85ce                	mv	a1,s3
    8000097c:	8526                	mv	a0,s1
    8000097e:	00001097          	auipc	ra,0x1
    80000982:	78e080e7          	jalr	1934(ra) # 8000210c <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80000986:	00093703          	ld	a4,0(s2)
    8000098a:	609c                	ld	a5,0(s1)
    8000098c:	02078793          	addi	a5,a5,32
    80000990:	fee785e3          	beq	a5,a4,8000097a <uartputc+0x5c>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    80000994:	00013497          	auipc	s1,0x13
    80000998:	a7448493          	addi	s1,s1,-1420 # 80013408 <uart_tx_lock>
    8000099c:	01f77793          	andi	a5,a4,31
    800009a0:	97a6                	add	a5,a5,s1
    800009a2:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    800009a6:	0705                	addi	a4,a4,1
    800009a8:	0000b797          	auipc	a5,0xb
    800009ac:	82e7b423          	sd	a4,-2008(a5) # 8000b1d0 <uart_tx_w>
  uartstart();
    800009b0:	00000097          	auipc	ra,0x0
    800009b4:	ede080e7          	jalr	-290(ra) # 8000088e <uartstart>
  release(&uart_tx_lock);
    800009b8:	8526                	mv	a0,s1
    800009ba:	00000097          	auipc	ra,0x0
    800009be:	332080e7          	jalr	818(ra) # 80000cec <release>
}
    800009c2:	70a2                	ld	ra,40(sp)
    800009c4:	7402                	ld	s0,32(sp)
    800009c6:	64e2                	ld	s1,24(sp)
    800009c8:	6942                	ld	s2,16(sp)
    800009ca:	69a2                	ld	s3,8(sp)
    800009cc:	6a02                	ld	s4,0(sp)
    800009ce:	6145                	addi	sp,sp,48
    800009d0:	8082                	ret
    for(;;)
    800009d2:	a001                	j	800009d2 <uartputc+0xb4>

00000000800009d4 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    800009d4:	1141                	addi	sp,sp,-16
    800009d6:	e422                	sd	s0,8(sp)
    800009d8:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    800009da:	100007b7          	lui	a5,0x10000
    800009de:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    800009e0:	0007c783          	lbu	a5,0(a5)
    800009e4:	8b85                	andi	a5,a5,1
    800009e6:	cb81                	beqz	a5,800009f6 <uartgetc+0x22>
    // input data is ready.
    return ReadReg(RHR);
    800009e8:	100007b7          	lui	a5,0x10000
    800009ec:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800009f0:	6422                	ld	s0,8(sp)
    800009f2:	0141                	addi	sp,sp,16
    800009f4:	8082                	ret
    return -1;
    800009f6:	557d                	li	a0,-1
    800009f8:	bfe5                	j	800009f0 <uartgetc+0x1c>

00000000800009fa <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009fa:	1101                	addi	sp,sp,-32
    800009fc:	ec06                	sd	ra,24(sp)
    800009fe:	e822                	sd	s0,16(sp)
    80000a00:	e426                	sd	s1,8(sp)
    80000a02:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000a04:	54fd                	li	s1,-1
    80000a06:	a029                	j	80000a10 <uartintr+0x16>
      break;
    consoleintr(c);
    80000a08:	00000097          	auipc	ra,0x0
    80000a0c:	8ce080e7          	jalr	-1842(ra) # 800002d6 <consoleintr>
    int c = uartgetc();
    80000a10:	00000097          	auipc	ra,0x0
    80000a14:	fc4080e7          	jalr	-60(ra) # 800009d4 <uartgetc>
    if(c == -1)
    80000a18:	fe9518e3          	bne	a0,s1,80000a08 <uartintr+0xe>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    80000a1c:	00013497          	auipc	s1,0x13
    80000a20:	9ec48493          	addi	s1,s1,-1556 # 80013408 <uart_tx_lock>
    80000a24:	8526                	mv	a0,s1
    80000a26:	00000097          	auipc	ra,0x0
    80000a2a:	212080e7          	jalr	530(ra) # 80000c38 <acquire>
  uartstart();
    80000a2e:	00000097          	auipc	ra,0x0
    80000a32:	e60080e7          	jalr	-416(ra) # 8000088e <uartstart>
  release(&uart_tx_lock);
    80000a36:	8526                	mv	a0,s1
    80000a38:	00000097          	auipc	ra,0x0
    80000a3c:	2b4080e7          	jalr	692(ra) # 80000cec <release>
}
    80000a40:	60e2                	ld	ra,24(sp)
    80000a42:	6442                	ld	s0,16(sp)
    80000a44:	64a2                	ld	s1,8(sp)
    80000a46:	6105                	addi	sp,sp,32
    80000a48:	8082                	ret

0000000080000a4a <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a4a:	1101                	addi	sp,sp,-32
    80000a4c:	ec06                	sd	ra,24(sp)
    80000a4e:	e822                	sd	s0,16(sp)
    80000a50:	e426                	sd	s1,8(sp)
    80000a52:	e04a                	sd	s2,0(sp)
    80000a54:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000a56:	03451793          	slli	a5,a0,0x34
    80000a5a:	ebb9                	bnez	a5,80000ab0 <kfree+0x66>
    80000a5c:	84aa                	mv	s1,a0
    80000a5e:	00024797          	auipc	a5,0x24
    80000a62:	c8a78793          	addi	a5,a5,-886 # 800246e8 <end>
    80000a66:	04f56563          	bltu	a0,a5,80000ab0 <kfree+0x66>
    80000a6a:	47c5                	li	a5,17
    80000a6c:	07ee                	slli	a5,a5,0x1b
    80000a6e:	04f57163          	bgeu	a0,a5,80000ab0 <kfree+0x66>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a72:	6605                	lui	a2,0x1
    80000a74:	4585                	li	a1,1
    80000a76:	00000097          	auipc	ra,0x0
    80000a7a:	2be080e7          	jalr	702(ra) # 80000d34 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a7e:	00013917          	auipc	s2,0x13
    80000a82:	9c290913          	addi	s2,s2,-1598 # 80013440 <kmem>
    80000a86:	854a                	mv	a0,s2
    80000a88:	00000097          	auipc	ra,0x0
    80000a8c:	1b0080e7          	jalr	432(ra) # 80000c38 <acquire>
  r->next = kmem.freelist;
    80000a90:	01893783          	ld	a5,24(s2)
    80000a94:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a96:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a9a:	854a                	mv	a0,s2
    80000a9c:	00000097          	auipc	ra,0x0
    80000aa0:	250080e7          	jalr	592(ra) # 80000cec <release>
}
    80000aa4:	60e2                	ld	ra,24(sp)
    80000aa6:	6442                	ld	s0,16(sp)
    80000aa8:	64a2                	ld	s1,8(sp)
    80000aaa:	6902                	ld	s2,0(sp)
    80000aac:	6105                	addi	sp,sp,32
    80000aae:	8082                	ret
    panic("kfree");
    80000ab0:	00007517          	auipc	a0,0x7
    80000ab4:	5a050513          	addi	a0,a0,1440 # 80008050 <etext+0x50>
    80000ab8:	00000097          	auipc	ra,0x0
    80000abc:	aa8080e7          	jalr	-1368(ra) # 80000560 <panic>

0000000080000ac0 <freerange>:
{
    80000ac0:	7179                	addi	sp,sp,-48
    80000ac2:	f406                	sd	ra,40(sp)
    80000ac4:	f022                	sd	s0,32(sp)
    80000ac6:	ec26                	sd	s1,24(sp)
    80000ac8:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000aca:	6785                	lui	a5,0x1
    80000acc:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000ad0:	00e504b3          	add	s1,a0,a4
    80000ad4:	777d                	lui	a4,0xfffff
    80000ad6:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ad8:	94be                	add	s1,s1,a5
    80000ada:	0295e463          	bltu	a1,s1,80000b02 <freerange+0x42>
    80000ade:	e84a                	sd	s2,16(sp)
    80000ae0:	e44e                	sd	s3,8(sp)
    80000ae2:	e052                	sd	s4,0(sp)
    80000ae4:	892e                	mv	s2,a1
    kfree(p);
    80000ae6:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ae8:	6985                	lui	s3,0x1
    kfree(p);
    80000aea:	01448533          	add	a0,s1,s4
    80000aee:	00000097          	auipc	ra,0x0
    80000af2:	f5c080e7          	jalr	-164(ra) # 80000a4a <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000af6:	94ce                	add	s1,s1,s3
    80000af8:	fe9979e3          	bgeu	s2,s1,80000aea <freerange+0x2a>
    80000afc:	6942                	ld	s2,16(sp)
    80000afe:	69a2                	ld	s3,8(sp)
    80000b00:	6a02                	ld	s4,0(sp)
}
    80000b02:	70a2                	ld	ra,40(sp)
    80000b04:	7402                	ld	s0,32(sp)
    80000b06:	64e2                	ld	s1,24(sp)
    80000b08:	6145                	addi	sp,sp,48
    80000b0a:	8082                	ret

0000000080000b0c <kinit>:
{
    80000b0c:	1141                	addi	sp,sp,-16
    80000b0e:	e406                	sd	ra,8(sp)
    80000b10:	e022                	sd	s0,0(sp)
    80000b12:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000b14:	00007597          	auipc	a1,0x7
    80000b18:	54458593          	addi	a1,a1,1348 # 80008058 <etext+0x58>
    80000b1c:	00013517          	auipc	a0,0x13
    80000b20:	92450513          	addi	a0,a0,-1756 # 80013440 <kmem>
    80000b24:	00000097          	auipc	ra,0x0
    80000b28:	084080e7          	jalr	132(ra) # 80000ba8 <initlock>
  freerange(end, (void*)PHYSTOP);
    80000b2c:	45c5                	li	a1,17
    80000b2e:	05ee                	slli	a1,a1,0x1b
    80000b30:	00024517          	auipc	a0,0x24
    80000b34:	bb850513          	addi	a0,a0,-1096 # 800246e8 <end>
    80000b38:	00000097          	auipc	ra,0x0
    80000b3c:	f88080e7          	jalr	-120(ra) # 80000ac0 <freerange>
}
    80000b40:	60a2                	ld	ra,8(sp)
    80000b42:	6402                	ld	s0,0(sp)
    80000b44:	0141                	addi	sp,sp,16
    80000b46:	8082                	ret

0000000080000b48 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b48:	1101                	addi	sp,sp,-32
    80000b4a:	ec06                	sd	ra,24(sp)
    80000b4c:	e822                	sd	s0,16(sp)
    80000b4e:	e426                	sd	s1,8(sp)
    80000b50:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b52:	00013497          	auipc	s1,0x13
    80000b56:	8ee48493          	addi	s1,s1,-1810 # 80013440 <kmem>
    80000b5a:	8526                	mv	a0,s1
    80000b5c:	00000097          	auipc	ra,0x0
    80000b60:	0dc080e7          	jalr	220(ra) # 80000c38 <acquire>
  r = kmem.freelist;
    80000b64:	6c84                	ld	s1,24(s1)
  if(r)
    80000b66:	c885                	beqz	s1,80000b96 <kalloc+0x4e>
    kmem.freelist = r->next;
    80000b68:	609c                	ld	a5,0(s1)
    80000b6a:	00013517          	auipc	a0,0x13
    80000b6e:	8d650513          	addi	a0,a0,-1834 # 80013440 <kmem>
    80000b72:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000b74:	00000097          	auipc	ra,0x0
    80000b78:	178080e7          	jalr	376(ra) # 80000cec <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b7c:	6605                	lui	a2,0x1
    80000b7e:	4595                	li	a1,5
    80000b80:	8526                	mv	a0,s1
    80000b82:	00000097          	auipc	ra,0x0
    80000b86:	1b2080e7          	jalr	434(ra) # 80000d34 <memset>
  return (void*)r;
}
    80000b8a:	8526                	mv	a0,s1
    80000b8c:	60e2                	ld	ra,24(sp)
    80000b8e:	6442                	ld	s0,16(sp)
    80000b90:	64a2                	ld	s1,8(sp)
    80000b92:	6105                	addi	sp,sp,32
    80000b94:	8082                	ret
  release(&kmem.lock);
    80000b96:	00013517          	auipc	a0,0x13
    80000b9a:	8aa50513          	addi	a0,a0,-1878 # 80013440 <kmem>
    80000b9e:	00000097          	auipc	ra,0x0
    80000ba2:	14e080e7          	jalr	334(ra) # 80000cec <release>
  if(r)
    80000ba6:	b7d5                	j	80000b8a <kalloc+0x42>

0000000080000ba8 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000ba8:	1141                	addi	sp,sp,-16
    80000baa:	e422                	sd	s0,8(sp)
    80000bac:	0800                	addi	s0,sp,16
  lk->name = name;
    80000bae:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000bb0:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000bb4:	00053823          	sd	zero,16(a0)
}
    80000bb8:	6422                	ld	s0,8(sp)
    80000bba:	0141                	addi	sp,sp,16
    80000bbc:	8082                	ret

0000000080000bbe <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000bbe:	411c                	lw	a5,0(a0)
    80000bc0:	e399                	bnez	a5,80000bc6 <holding+0x8>
    80000bc2:	4501                	li	a0,0
  return r;
}
    80000bc4:	8082                	ret
{
    80000bc6:	1101                	addi	sp,sp,-32
    80000bc8:	ec06                	sd	ra,24(sp)
    80000bca:	e822                	sd	s0,16(sp)
    80000bcc:	e426                	sd	s1,8(sp)
    80000bce:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000bd0:	6904                	ld	s1,16(a0)
    80000bd2:	00001097          	auipc	ra,0x1
    80000bd6:	e74080e7          	jalr	-396(ra) # 80001a46 <mycpu>
    80000bda:	40a48533          	sub	a0,s1,a0
    80000bde:	00153513          	seqz	a0,a0
}
    80000be2:	60e2                	ld	ra,24(sp)
    80000be4:	6442                	ld	s0,16(sp)
    80000be6:	64a2                	ld	s1,8(sp)
    80000be8:	6105                	addi	sp,sp,32
    80000bea:	8082                	ret

0000000080000bec <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000bec:	1101                	addi	sp,sp,-32
    80000bee:	ec06                	sd	ra,24(sp)
    80000bf0:	e822                	sd	s0,16(sp)
    80000bf2:	e426                	sd	s1,8(sp)
    80000bf4:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000bf6:	100024f3          	csrr	s1,sstatus
    80000bfa:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000bfe:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c00:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    80000c04:	00001097          	auipc	ra,0x1
    80000c08:	e42080e7          	jalr	-446(ra) # 80001a46 <mycpu>
    80000c0c:	5d3c                	lw	a5,120(a0)
    80000c0e:	cf89                	beqz	a5,80000c28 <push_off+0x3c>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000c10:	00001097          	auipc	ra,0x1
    80000c14:	e36080e7          	jalr	-458(ra) # 80001a46 <mycpu>
    80000c18:	5d3c                	lw	a5,120(a0)
    80000c1a:	2785                	addiw	a5,a5,1
    80000c1c:	dd3c                	sw	a5,120(a0)
}
    80000c1e:	60e2                	ld	ra,24(sp)
    80000c20:	6442                	ld	s0,16(sp)
    80000c22:	64a2                	ld	s1,8(sp)
    80000c24:	6105                	addi	sp,sp,32
    80000c26:	8082                	ret
    mycpu()->intena = old;
    80000c28:	00001097          	auipc	ra,0x1
    80000c2c:	e1e080e7          	jalr	-482(ra) # 80001a46 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000c30:	8085                	srli	s1,s1,0x1
    80000c32:	8885                	andi	s1,s1,1
    80000c34:	dd64                	sw	s1,124(a0)
    80000c36:	bfe9                	j	80000c10 <push_off+0x24>

0000000080000c38 <acquire>:
{
    80000c38:	1101                	addi	sp,sp,-32
    80000c3a:	ec06                	sd	ra,24(sp)
    80000c3c:	e822                	sd	s0,16(sp)
    80000c3e:	e426                	sd	s1,8(sp)
    80000c40:	1000                	addi	s0,sp,32
    80000c42:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c44:	00000097          	auipc	ra,0x0
    80000c48:	fa8080e7          	jalr	-88(ra) # 80000bec <push_off>
  if(holding(lk))
    80000c4c:	8526                	mv	a0,s1
    80000c4e:	00000097          	auipc	ra,0x0
    80000c52:	f70080e7          	jalr	-144(ra) # 80000bbe <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c56:	4705                	li	a4,1
  if(holding(lk))
    80000c58:	e115                	bnez	a0,80000c7c <acquire+0x44>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c5a:	87ba                	mv	a5,a4
    80000c5c:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c60:	2781                	sext.w	a5,a5
    80000c62:	ffe5                	bnez	a5,80000c5a <acquire+0x22>
  __sync_synchronize();
    80000c64:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000c68:	00001097          	auipc	ra,0x1
    80000c6c:	dde080e7          	jalr	-546(ra) # 80001a46 <mycpu>
    80000c70:	e888                	sd	a0,16(s1)
}
    80000c72:	60e2                	ld	ra,24(sp)
    80000c74:	6442                	ld	s0,16(sp)
    80000c76:	64a2                	ld	s1,8(sp)
    80000c78:	6105                	addi	sp,sp,32
    80000c7a:	8082                	ret
    panic("acquire");
    80000c7c:	00007517          	auipc	a0,0x7
    80000c80:	3e450513          	addi	a0,a0,996 # 80008060 <etext+0x60>
    80000c84:	00000097          	auipc	ra,0x0
    80000c88:	8dc080e7          	jalr	-1828(ra) # 80000560 <panic>

0000000080000c8c <pop_off>:

void
pop_off(void)
{
    80000c8c:	1141                	addi	sp,sp,-16
    80000c8e:	e406                	sd	ra,8(sp)
    80000c90:	e022                	sd	s0,0(sp)
    80000c92:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c94:	00001097          	auipc	ra,0x1
    80000c98:	db2080e7          	jalr	-590(ra) # 80001a46 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c9c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000ca0:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000ca2:	e78d                	bnez	a5,80000ccc <pop_off+0x40>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000ca4:	5d3c                	lw	a5,120(a0)
    80000ca6:	02f05b63          	blez	a5,80000cdc <pop_off+0x50>
    panic("pop_off");
  c->noff -= 1;
    80000caa:	37fd                	addiw	a5,a5,-1
    80000cac:	0007871b          	sext.w	a4,a5
    80000cb0:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000cb2:	eb09                	bnez	a4,80000cc4 <pop_off+0x38>
    80000cb4:	5d7c                	lw	a5,124(a0)
    80000cb6:	c799                	beqz	a5,80000cc4 <pop_off+0x38>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000cb8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000cbc:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000cc0:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000cc4:	60a2                	ld	ra,8(sp)
    80000cc6:	6402                	ld	s0,0(sp)
    80000cc8:	0141                	addi	sp,sp,16
    80000cca:	8082                	ret
    panic("pop_off - interruptible");
    80000ccc:	00007517          	auipc	a0,0x7
    80000cd0:	39c50513          	addi	a0,a0,924 # 80008068 <etext+0x68>
    80000cd4:	00000097          	auipc	ra,0x0
    80000cd8:	88c080e7          	jalr	-1908(ra) # 80000560 <panic>
    panic("pop_off");
    80000cdc:	00007517          	auipc	a0,0x7
    80000ce0:	3a450513          	addi	a0,a0,932 # 80008080 <etext+0x80>
    80000ce4:	00000097          	auipc	ra,0x0
    80000ce8:	87c080e7          	jalr	-1924(ra) # 80000560 <panic>

0000000080000cec <release>:
{
    80000cec:	1101                	addi	sp,sp,-32
    80000cee:	ec06                	sd	ra,24(sp)
    80000cf0:	e822                	sd	s0,16(sp)
    80000cf2:	e426                	sd	s1,8(sp)
    80000cf4:	1000                	addi	s0,sp,32
    80000cf6:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000cf8:	00000097          	auipc	ra,0x0
    80000cfc:	ec6080e7          	jalr	-314(ra) # 80000bbe <holding>
    80000d00:	c115                	beqz	a0,80000d24 <release+0x38>
  lk->cpu = 0;
    80000d02:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000d06:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000d0a:	0310000f          	fence	rw,w
    80000d0e:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000d12:	00000097          	auipc	ra,0x0
    80000d16:	f7a080e7          	jalr	-134(ra) # 80000c8c <pop_off>
}
    80000d1a:	60e2                	ld	ra,24(sp)
    80000d1c:	6442                	ld	s0,16(sp)
    80000d1e:	64a2                	ld	s1,8(sp)
    80000d20:	6105                	addi	sp,sp,32
    80000d22:	8082                	ret
    panic("release");
    80000d24:	00007517          	auipc	a0,0x7
    80000d28:	36450513          	addi	a0,a0,868 # 80008088 <etext+0x88>
    80000d2c:	00000097          	auipc	ra,0x0
    80000d30:	834080e7          	jalr	-1996(ra) # 80000560 <panic>

0000000080000d34 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000d34:	1141                	addi	sp,sp,-16
    80000d36:	e422                	sd	s0,8(sp)
    80000d38:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000d3a:	ca19                	beqz	a2,80000d50 <memset+0x1c>
    80000d3c:	87aa                	mv	a5,a0
    80000d3e:	1602                	slli	a2,a2,0x20
    80000d40:	9201                	srli	a2,a2,0x20
    80000d42:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000d46:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000d4a:	0785                	addi	a5,a5,1
    80000d4c:	fee79de3          	bne	a5,a4,80000d46 <memset+0x12>
  }
  return dst;
}
    80000d50:	6422                	ld	s0,8(sp)
    80000d52:	0141                	addi	sp,sp,16
    80000d54:	8082                	ret

0000000080000d56 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d56:	1141                	addi	sp,sp,-16
    80000d58:	e422                	sd	s0,8(sp)
    80000d5a:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000d5c:	ca05                	beqz	a2,80000d8c <memcmp+0x36>
    80000d5e:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000d62:	1682                	slli	a3,a3,0x20
    80000d64:	9281                	srli	a3,a3,0x20
    80000d66:	0685                	addi	a3,a3,1
    80000d68:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000d6a:	00054783          	lbu	a5,0(a0)
    80000d6e:	0005c703          	lbu	a4,0(a1)
    80000d72:	00e79863          	bne	a5,a4,80000d82 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000d76:	0505                	addi	a0,a0,1
    80000d78:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d7a:	fed518e3          	bne	a0,a3,80000d6a <memcmp+0x14>
  }

  return 0;
    80000d7e:	4501                	li	a0,0
    80000d80:	a019                	j	80000d86 <memcmp+0x30>
      return *s1 - *s2;
    80000d82:	40e7853b          	subw	a0,a5,a4
}
    80000d86:	6422                	ld	s0,8(sp)
    80000d88:	0141                	addi	sp,sp,16
    80000d8a:	8082                	ret
  return 0;
    80000d8c:	4501                	li	a0,0
    80000d8e:	bfe5                	j	80000d86 <memcmp+0x30>

0000000080000d90 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d90:	1141                	addi	sp,sp,-16
    80000d92:	e422                	sd	s0,8(sp)
    80000d94:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d96:	c205                	beqz	a2,80000db6 <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d98:	02a5e263          	bltu	a1,a0,80000dbc <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d9c:	1602                	slli	a2,a2,0x20
    80000d9e:	9201                	srli	a2,a2,0x20
    80000da0:	00c587b3          	add	a5,a1,a2
{
    80000da4:	872a                	mv	a4,a0
      *d++ = *s++;
    80000da6:	0585                	addi	a1,a1,1
    80000da8:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffda919>
    80000daa:	fff5c683          	lbu	a3,-1(a1)
    80000dae:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000db2:	feb79ae3          	bne	a5,a1,80000da6 <memmove+0x16>

  return dst;
}
    80000db6:	6422                	ld	s0,8(sp)
    80000db8:	0141                	addi	sp,sp,16
    80000dba:	8082                	ret
  if(s < d && s + n > d){
    80000dbc:	02061693          	slli	a3,a2,0x20
    80000dc0:	9281                	srli	a3,a3,0x20
    80000dc2:	00d58733          	add	a4,a1,a3
    80000dc6:	fce57be3          	bgeu	a0,a4,80000d9c <memmove+0xc>
    d += n;
    80000dca:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000dcc:	fff6079b          	addiw	a5,a2,-1
    80000dd0:	1782                	slli	a5,a5,0x20
    80000dd2:	9381                	srli	a5,a5,0x20
    80000dd4:	fff7c793          	not	a5,a5
    80000dd8:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000dda:	177d                	addi	a4,a4,-1
    80000ddc:	16fd                	addi	a3,a3,-1
    80000dde:	00074603          	lbu	a2,0(a4)
    80000de2:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000de6:	fef71ae3          	bne	a4,a5,80000dda <memmove+0x4a>
    80000dea:	b7f1                	j	80000db6 <memmove+0x26>

0000000080000dec <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000dec:	1141                	addi	sp,sp,-16
    80000dee:	e406                	sd	ra,8(sp)
    80000df0:	e022                	sd	s0,0(sp)
    80000df2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000df4:	00000097          	auipc	ra,0x0
    80000df8:	f9c080e7          	jalr	-100(ra) # 80000d90 <memmove>
}
    80000dfc:	60a2                	ld	ra,8(sp)
    80000dfe:	6402                	ld	s0,0(sp)
    80000e00:	0141                	addi	sp,sp,16
    80000e02:	8082                	ret

0000000080000e04 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000e04:	1141                	addi	sp,sp,-16
    80000e06:	e422                	sd	s0,8(sp)
    80000e08:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000e0a:	ce11                	beqz	a2,80000e26 <strncmp+0x22>
    80000e0c:	00054783          	lbu	a5,0(a0)
    80000e10:	cf89                	beqz	a5,80000e2a <strncmp+0x26>
    80000e12:	0005c703          	lbu	a4,0(a1)
    80000e16:	00f71a63          	bne	a4,a5,80000e2a <strncmp+0x26>
    n--, p++, q++;
    80000e1a:	367d                	addiw	a2,a2,-1
    80000e1c:	0505                	addi	a0,a0,1
    80000e1e:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000e20:	f675                	bnez	a2,80000e0c <strncmp+0x8>
  if(n == 0)
    return 0;
    80000e22:	4501                	li	a0,0
    80000e24:	a801                	j	80000e34 <strncmp+0x30>
    80000e26:	4501                	li	a0,0
    80000e28:	a031                	j	80000e34 <strncmp+0x30>
  return (uchar)*p - (uchar)*q;
    80000e2a:	00054503          	lbu	a0,0(a0)
    80000e2e:	0005c783          	lbu	a5,0(a1)
    80000e32:	9d1d                	subw	a0,a0,a5
}
    80000e34:	6422                	ld	s0,8(sp)
    80000e36:	0141                	addi	sp,sp,16
    80000e38:	8082                	ret

0000000080000e3a <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000e3a:	1141                	addi	sp,sp,-16
    80000e3c:	e422                	sd	s0,8(sp)
    80000e3e:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000e40:	87aa                	mv	a5,a0
    80000e42:	86b2                	mv	a3,a2
    80000e44:	367d                	addiw	a2,a2,-1
    80000e46:	02d05563          	blez	a3,80000e70 <strncpy+0x36>
    80000e4a:	0785                	addi	a5,a5,1
    80000e4c:	0005c703          	lbu	a4,0(a1)
    80000e50:	fee78fa3          	sb	a4,-1(a5)
    80000e54:	0585                	addi	a1,a1,1
    80000e56:	f775                	bnez	a4,80000e42 <strncpy+0x8>
    ;
  while(n-- > 0)
    80000e58:	873e                	mv	a4,a5
    80000e5a:	9fb5                	addw	a5,a5,a3
    80000e5c:	37fd                	addiw	a5,a5,-1
    80000e5e:	00c05963          	blez	a2,80000e70 <strncpy+0x36>
    *s++ = 0;
    80000e62:	0705                	addi	a4,a4,1
    80000e64:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000e68:	40e786bb          	subw	a3,a5,a4
    80000e6c:	fed04be3          	bgtz	a3,80000e62 <strncpy+0x28>
  return os;
}
    80000e70:	6422                	ld	s0,8(sp)
    80000e72:	0141                	addi	sp,sp,16
    80000e74:	8082                	ret

0000000080000e76 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e76:	1141                	addi	sp,sp,-16
    80000e78:	e422                	sd	s0,8(sp)
    80000e7a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e7c:	02c05363          	blez	a2,80000ea2 <safestrcpy+0x2c>
    80000e80:	fff6069b          	addiw	a3,a2,-1
    80000e84:	1682                	slli	a3,a3,0x20
    80000e86:	9281                	srli	a3,a3,0x20
    80000e88:	96ae                	add	a3,a3,a1
    80000e8a:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e8c:	00d58963          	beq	a1,a3,80000e9e <safestrcpy+0x28>
    80000e90:	0585                	addi	a1,a1,1
    80000e92:	0785                	addi	a5,a5,1
    80000e94:	fff5c703          	lbu	a4,-1(a1)
    80000e98:	fee78fa3          	sb	a4,-1(a5)
    80000e9c:	fb65                	bnez	a4,80000e8c <safestrcpy+0x16>
    ;
  *s = 0;
    80000e9e:	00078023          	sb	zero,0(a5)
  return os;
}
    80000ea2:	6422                	ld	s0,8(sp)
    80000ea4:	0141                	addi	sp,sp,16
    80000ea6:	8082                	ret

0000000080000ea8 <strlen>:

int
strlen(const char *s)
{
    80000ea8:	1141                	addi	sp,sp,-16
    80000eaa:	e422                	sd	s0,8(sp)
    80000eac:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000eae:	00054783          	lbu	a5,0(a0)
    80000eb2:	cf91                	beqz	a5,80000ece <strlen+0x26>
    80000eb4:	0505                	addi	a0,a0,1
    80000eb6:	87aa                	mv	a5,a0
    80000eb8:	86be                	mv	a3,a5
    80000eba:	0785                	addi	a5,a5,1
    80000ebc:	fff7c703          	lbu	a4,-1(a5)
    80000ec0:	ff65                	bnez	a4,80000eb8 <strlen+0x10>
    80000ec2:	40a6853b          	subw	a0,a3,a0
    80000ec6:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    80000ec8:	6422                	ld	s0,8(sp)
    80000eca:	0141                	addi	sp,sp,16
    80000ecc:	8082                	ret
  for(n = 0; s[n]; n++)
    80000ece:	4501                	li	a0,0
    80000ed0:	bfe5                	j	80000ec8 <strlen+0x20>

0000000080000ed2 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000ed2:	1141                	addi	sp,sp,-16
    80000ed4:	e406                	sd	ra,8(sp)
    80000ed6:	e022                	sd	s0,0(sp)
    80000ed8:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000eda:	00001097          	auipc	ra,0x1
    80000ede:	b5c080e7          	jalr	-1188(ra) # 80001a36 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000ee2:	0000a717          	auipc	a4,0xa
    80000ee6:	2f670713          	addi	a4,a4,758 # 8000b1d8 <started>
  if(cpuid() == 0){
    80000eea:	c139                	beqz	a0,80000f30 <main+0x5e>
    while(started == 0)
    80000eec:	431c                	lw	a5,0(a4)
    80000eee:	2781                	sext.w	a5,a5
    80000ef0:	dff5                	beqz	a5,80000eec <main+0x1a>
      ;
    __sync_synchronize();
    80000ef2:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000ef6:	00001097          	auipc	ra,0x1
    80000efa:	b40080e7          	jalr	-1216(ra) # 80001a36 <cpuid>
    80000efe:	85aa                	mv	a1,a0
    80000f00:	00007517          	auipc	a0,0x7
    80000f04:	1a850513          	addi	a0,a0,424 # 800080a8 <etext+0xa8>
    80000f08:	fffff097          	auipc	ra,0xfffff
    80000f0c:	6a2080e7          	jalr	1698(ra) # 800005aa <printf>
    kvminithart();    // turn on paging
    80000f10:	00000097          	auipc	ra,0x0
    80000f14:	0d8080e7          	jalr	216(ra) # 80000fe8 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000f18:	00001097          	auipc	ra,0x1
    80000f1c:	7ea080e7          	jalr	2026(ra) # 80002702 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000f20:	00005097          	auipc	ra,0x5
    80000f24:	f04080e7          	jalr	-252(ra) # 80005e24 <plicinithart>
  }

  scheduler();        
    80000f28:	00001097          	auipc	ra,0x1
    80000f2c:	032080e7          	jalr	50(ra) # 80001f5a <scheduler>
    consoleinit();
    80000f30:	fffff097          	auipc	ra,0xfffff
    80000f34:	540080e7          	jalr	1344(ra) # 80000470 <consoleinit>
    printfinit();
    80000f38:	00000097          	auipc	ra,0x0
    80000f3c:	87a080e7          	jalr	-1926(ra) # 800007b2 <printfinit>
    printf("\n");
    80000f40:	00007517          	auipc	a0,0x7
    80000f44:	0e050513          	addi	a0,a0,224 # 80008020 <etext+0x20>
    80000f48:	fffff097          	auipc	ra,0xfffff
    80000f4c:	662080e7          	jalr	1634(ra) # 800005aa <printf>
    printf("xv6 kernel is booting\n");
    80000f50:	00007517          	auipc	a0,0x7
    80000f54:	14050513          	addi	a0,a0,320 # 80008090 <etext+0x90>
    80000f58:	fffff097          	auipc	ra,0xfffff
    80000f5c:	652080e7          	jalr	1618(ra) # 800005aa <printf>
    printf("\n");
    80000f60:	00007517          	auipc	a0,0x7
    80000f64:	0c050513          	addi	a0,a0,192 # 80008020 <etext+0x20>
    80000f68:	fffff097          	auipc	ra,0xfffff
    80000f6c:	642080e7          	jalr	1602(ra) # 800005aa <printf>
    kinit();         // physical page allocator
    80000f70:	00000097          	auipc	ra,0x0
    80000f74:	b9c080e7          	jalr	-1124(ra) # 80000b0c <kinit>
    kvminit();       // create kernel page table
    80000f78:	00000097          	auipc	ra,0x0
    80000f7c:	326080e7          	jalr	806(ra) # 8000129e <kvminit>
    kvminithart();   // turn on paging
    80000f80:	00000097          	auipc	ra,0x0
    80000f84:	068080e7          	jalr	104(ra) # 80000fe8 <kvminithart>
    procinit();      // process table
    80000f88:	00001097          	auipc	ra,0x1
    80000f8c:	9d4080e7          	jalr	-1580(ra) # 8000195c <procinit>
    trapinit();      // trap vectors
    80000f90:	00001097          	auipc	ra,0x1
    80000f94:	74a080e7          	jalr	1866(ra) # 800026da <trapinit>
    trapinithart();  // install kernel trap vector
    80000f98:	00001097          	auipc	ra,0x1
    80000f9c:	76a080e7          	jalr	1898(ra) # 80002702 <trapinithart>
    plicinit();      // set up interrupt controller
    80000fa0:	00005097          	auipc	ra,0x5
    80000fa4:	e6a080e7          	jalr	-406(ra) # 80005e0a <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000fa8:	00005097          	auipc	ra,0x5
    80000fac:	e7c080e7          	jalr	-388(ra) # 80005e24 <plicinithart>
    binit();         // buffer cache
    80000fb0:	00002097          	auipc	ra,0x2
    80000fb4:	f3e080e7          	jalr	-194(ra) # 80002eee <binit>
    iinit();         // inode table
    80000fb8:	00002097          	auipc	ra,0x2
    80000fbc:	5f4080e7          	jalr	1524(ra) # 800035ac <iinit>
    fileinit();      // file table
    80000fc0:	00003097          	auipc	ra,0x3
    80000fc4:	5a4080e7          	jalr	1444(ra) # 80004564 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000fc8:	00005097          	auipc	ra,0x5
    80000fcc:	f64080e7          	jalr	-156(ra) # 80005f2c <virtio_disk_init>
    userinit();      // first user process
    80000fd0:	00001097          	auipc	ra,0x1
    80000fd4:	d6a080e7          	jalr	-662(ra) # 80001d3a <userinit>
    __sync_synchronize();
    80000fd8:	0330000f          	fence	rw,rw
    started = 1;
    80000fdc:	4785                	li	a5,1
    80000fde:	0000a717          	auipc	a4,0xa
    80000fe2:	1ef72d23          	sw	a5,506(a4) # 8000b1d8 <started>
    80000fe6:	b789                	j	80000f28 <main+0x56>

0000000080000fe8 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    80000fe8:	1141                	addi	sp,sp,-16
    80000fea:	e422                	sd	s0,8(sp)
    80000fec:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000fee:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000ff2:	0000a797          	auipc	a5,0xa
    80000ff6:	1ee7b783          	ld	a5,494(a5) # 8000b1e0 <kernel_pagetable>
    80000ffa:	83b1                	srli	a5,a5,0xc
    80000ffc:	577d                	li	a4,-1
    80000ffe:	177e                	slli	a4,a4,0x3f
    80001000:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80001002:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80001006:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    8000100a:	6422                	ld	s0,8(sp)
    8000100c:	0141                	addi	sp,sp,16
    8000100e:	8082                	ret

0000000080001010 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80001010:	7139                	addi	sp,sp,-64
    80001012:	fc06                	sd	ra,56(sp)
    80001014:	f822                	sd	s0,48(sp)
    80001016:	f426                	sd	s1,40(sp)
    80001018:	f04a                	sd	s2,32(sp)
    8000101a:	ec4e                	sd	s3,24(sp)
    8000101c:	e852                	sd	s4,16(sp)
    8000101e:	e456                	sd	s5,8(sp)
    80001020:	e05a                	sd	s6,0(sp)
    80001022:	0080                	addi	s0,sp,64
    80001024:	84aa                	mv	s1,a0
    80001026:	89ae                	mv	s3,a1
    80001028:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    8000102a:	57fd                	li	a5,-1
    8000102c:	83e9                	srli	a5,a5,0x1a
    8000102e:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80001030:	4b31                	li	s6,12
  if(va >= MAXVA)
    80001032:	04b7f263          	bgeu	a5,a1,80001076 <walk+0x66>
    panic("walk");
    80001036:	00007517          	auipc	a0,0x7
    8000103a:	08a50513          	addi	a0,a0,138 # 800080c0 <etext+0xc0>
    8000103e:	fffff097          	auipc	ra,0xfffff
    80001042:	522080e7          	jalr	1314(ra) # 80000560 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80001046:	060a8663          	beqz	s5,800010b2 <walk+0xa2>
    8000104a:	00000097          	auipc	ra,0x0
    8000104e:	afe080e7          	jalr	-1282(ra) # 80000b48 <kalloc>
    80001052:	84aa                	mv	s1,a0
    80001054:	c529                	beqz	a0,8000109e <walk+0x8e>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80001056:	6605                	lui	a2,0x1
    80001058:	4581                	li	a1,0
    8000105a:	00000097          	auipc	ra,0x0
    8000105e:	cda080e7          	jalr	-806(ra) # 80000d34 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80001062:	00c4d793          	srli	a5,s1,0xc
    80001066:	07aa                	slli	a5,a5,0xa
    80001068:	0017e793          	ori	a5,a5,1
    8000106c:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80001070:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffda90f>
    80001072:	036a0063          	beq	s4,s6,80001092 <walk+0x82>
    pte_t *pte = &pagetable[PX(level, va)];
    80001076:	0149d933          	srl	s2,s3,s4
    8000107a:	1ff97913          	andi	s2,s2,511
    8000107e:	090e                	slli	s2,s2,0x3
    80001080:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80001082:	00093483          	ld	s1,0(s2)
    80001086:	0014f793          	andi	a5,s1,1
    8000108a:	dfd5                	beqz	a5,80001046 <walk+0x36>
      pagetable = (pagetable_t)PTE2PA(*pte);
    8000108c:	80a9                	srli	s1,s1,0xa
    8000108e:	04b2                	slli	s1,s1,0xc
    80001090:	b7c5                	j	80001070 <walk+0x60>
    }
  }
  return &pagetable[PX(0, va)];
    80001092:	00c9d513          	srli	a0,s3,0xc
    80001096:	1ff57513          	andi	a0,a0,511
    8000109a:	050e                	slli	a0,a0,0x3
    8000109c:	9526                	add	a0,a0,s1
}
    8000109e:	70e2                	ld	ra,56(sp)
    800010a0:	7442                	ld	s0,48(sp)
    800010a2:	74a2                	ld	s1,40(sp)
    800010a4:	7902                	ld	s2,32(sp)
    800010a6:	69e2                	ld	s3,24(sp)
    800010a8:	6a42                	ld	s4,16(sp)
    800010aa:	6aa2                	ld	s5,8(sp)
    800010ac:	6b02                	ld	s6,0(sp)
    800010ae:	6121                	addi	sp,sp,64
    800010b0:	8082                	ret
        return 0;
    800010b2:	4501                	li	a0,0
    800010b4:	b7ed                	j	8000109e <walk+0x8e>

00000000800010b6 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    800010b6:	57fd                	li	a5,-1
    800010b8:	83e9                	srli	a5,a5,0x1a
    800010ba:	00b7f463          	bgeu	a5,a1,800010c2 <walkaddr+0xc>
    return 0;
    800010be:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    800010c0:	8082                	ret
{
    800010c2:	1141                	addi	sp,sp,-16
    800010c4:	e406                	sd	ra,8(sp)
    800010c6:	e022                	sd	s0,0(sp)
    800010c8:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    800010ca:	4601                	li	a2,0
    800010cc:	00000097          	auipc	ra,0x0
    800010d0:	f44080e7          	jalr	-188(ra) # 80001010 <walk>
  if(pte == 0)
    800010d4:	c105                	beqz	a0,800010f4 <walkaddr+0x3e>
  if((*pte & PTE_V) == 0)
    800010d6:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    800010d8:	0117f693          	andi	a3,a5,17
    800010dc:	4745                	li	a4,17
    return 0;
    800010de:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    800010e0:	00e68663          	beq	a3,a4,800010ec <walkaddr+0x36>
}
    800010e4:	60a2                	ld	ra,8(sp)
    800010e6:	6402                	ld	s0,0(sp)
    800010e8:	0141                	addi	sp,sp,16
    800010ea:	8082                	ret
  pa = PTE2PA(*pte);
    800010ec:	83a9                	srli	a5,a5,0xa
    800010ee:	00c79513          	slli	a0,a5,0xc
  return pa;
    800010f2:	bfcd                	j	800010e4 <walkaddr+0x2e>
    return 0;
    800010f4:	4501                	li	a0,0
    800010f6:	b7fd                	j	800010e4 <walkaddr+0x2e>

00000000800010f8 <mappages>:
// physical addresses starting at pa. va and size might not
// be page-aligned. Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    800010f8:	715d                	addi	sp,sp,-80
    800010fa:	e486                	sd	ra,72(sp)
    800010fc:	e0a2                	sd	s0,64(sp)
    800010fe:	fc26                	sd	s1,56(sp)
    80001100:	f84a                	sd	s2,48(sp)
    80001102:	f44e                	sd	s3,40(sp)
    80001104:	f052                	sd	s4,32(sp)
    80001106:	ec56                	sd	s5,24(sp)
    80001108:	e85a                	sd	s6,16(sp)
    8000110a:	e45e                	sd	s7,8(sp)
    8000110c:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if(size == 0)
    8000110e:	c639                	beqz	a2,8000115c <mappages+0x64>
    80001110:	8aaa                	mv	s5,a0
    80001112:	8b3a                	mv	s6,a4
    panic("mappages: size");
  
  a = PGROUNDDOWN(va);
    80001114:	777d                	lui	a4,0xfffff
    80001116:	00e5f7b3          	and	a5,a1,a4
  last = PGROUNDDOWN(va + size - 1);
    8000111a:	fff58993          	addi	s3,a1,-1
    8000111e:	99b2                	add	s3,s3,a2
    80001120:	00e9f9b3          	and	s3,s3,a4
  a = PGROUNDDOWN(va);
    80001124:	893e                	mv	s2,a5
    80001126:	40f68a33          	sub	s4,a3,a5
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    8000112a:	6b85                	lui	s7,0x1
    8000112c:	014904b3          	add	s1,s2,s4
    if((pte = walk(pagetable, a, 1)) == 0)
    80001130:	4605                	li	a2,1
    80001132:	85ca                	mv	a1,s2
    80001134:	8556                	mv	a0,s5
    80001136:	00000097          	auipc	ra,0x0
    8000113a:	eda080e7          	jalr	-294(ra) # 80001010 <walk>
    8000113e:	cd1d                	beqz	a0,8000117c <mappages+0x84>
    if(*pte & PTE_V)
    80001140:	611c                	ld	a5,0(a0)
    80001142:	8b85                	andi	a5,a5,1
    80001144:	e785                	bnez	a5,8000116c <mappages+0x74>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80001146:	80b1                	srli	s1,s1,0xc
    80001148:	04aa                	slli	s1,s1,0xa
    8000114a:	0164e4b3          	or	s1,s1,s6
    8000114e:	0014e493          	ori	s1,s1,1
    80001152:	e104                	sd	s1,0(a0)
    if(a == last)
    80001154:	05390063          	beq	s2,s3,80001194 <mappages+0x9c>
    a += PGSIZE;
    80001158:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    8000115a:	bfc9                	j	8000112c <mappages+0x34>
    panic("mappages: size");
    8000115c:	00007517          	auipc	a0,0x7
    80001160:	f6c50513          	addi	a0,a0,-148 # 800080c8 <etext+0xc8>
    80001164:	fffff097          	auipc	ra,0xfffff
    80001168:	3fc080e7          	jalr	1020(ra) # 80000560 <panic>
      panic("mappages: remap");
    8000116c:	00007517          	auipc	a0,0x7
    80001170:	f6c50513          	addi	a0,a0,-148 # 800080d8 <etext+0xd8>
    80001174:	fffff097          	auipc	ra,0xfffff
    80001178:	3ec080e7          	jalr	1004(ra) # 80000560 <panic>
      return -1;
    8000117c:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    8000117e:	60a6                	ld	ra,72(sp)
    80001180:	6406                	ld	s0,64(sp)
    80001182:	74e2                	ld	s1,56(sp)
    80001184:	7942                	ld	s2,48(sp)
    80001186:	79a2                	ld	s3,40(sp)
    80001188:	7a02                	ld	s4,32(sp)
    8000118a:	6ae2                	ld	s5,24(sp)
    8000118c:	6b42                	ld	s6,16(sp)
    8000118e:	6ba2                	ld	s7,8(sp)
    80001190:	6161                	addi	sp,sp,80
    80001192:	8082                	ret
  return 0;
    80001194:	4501                	li	a0,0
    80001196:	b7e5                	j	8000117e <mappages+0x86>

0000000080001198 <kvmmap>:
{
    80001198:	1141                	addi	sp,sp,-16
    8000119a:	e406                	sd	ra,8(sp)
    8000119c:	e022                	sd	s0,0(sp)
    8000119e:	0800                	addi	s0,sp,16
    800011a0:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    800011a2:	86b2                	mv	a3,a2
    800011a4:	863e                	mv	a2,a5
    800011a6:	00000097          	auipc	ra,0x0
    800011aa:	f52080e7          	jalr	-174(ra) # 800010f8 <mappages>
    800011ae:	e509                	bnez	a0,800011b8 <kvmmap+0x20>
}
    800011b0:	60a2                	ld	ra,8(sp)
    800011b2:	6402                	ld	s0,0(sp)
    800011b4:	0141                	addi	sp,sp,16
    800011b6:	8082                	ret
    panic("kvmmap");
    800011b8:	00007517          	auipc	a0,0x7
    800011bc:	f3050513          	addi	a0,a0,-208 # 800080e8 <etext+0xe8>
    800011c0:	fffff097          	auipc	ra,0xfffff
    800011c4:	3a0080e7          	jalr	928(ra) # 80000560 <panic>

00000000800011c8 <kvmmake>:
{
    800011c8:	1101                	addi	sp,sp,-32
    800011ca:	ec06                	sd	ra,24(sp)
    800011cc:	e822                	sd	s0,16(sp)
    800011ce:	e426                	sd	s1,8(sp)
    800011d0:	e04a                	sd	s2,0(sp)
    800011d2:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    800011d4:	00000097          	auipc	ra,0x0
    800011d8:	974080e7          	jalr	-1676(ra) # 80000b48 <kalloc>
    800011dc:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800011de:	6605                	lui	a2,0x1
    800011e0:	4581                	li	a1,0
    800011e2:	00000097          	auipc	ra,0x0
    800011e6:	b52080e7          	jalr	-1198(ra) # 80000d34 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800011ea:	4719                	li	a4,6
    800011ec:	6685                	lui	a3,0x1
    800011ee:	10000637          	lui	a2,0x10000
    800011f2:	100005b7          	lui	a1,0x10000
    800011f6:	8526                	mv	a0,s1
    800011f8:	00000097          	auipc	ra,0x0
    800011fc:	fa0080e7          	jalr	-96(ra) # 80001198 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001200:	4719                	li	a4,6
    80001202:	6685                	lui	a3,0x1
    80001204:	10001637          	lui	a2,0x10001
    80001208:	100015b7          	lui	a1,0x10001
    8000120c:	8526                	mv	a0,s1
    8000120e:	00000097          	auipc	ra,0x0
    80001212:	f8a080e7          	jalr	-118(ra) # 80001198 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x400000, PTE_R | PTE_W);
    80001216:	4719                	li	a4,6
    80001218:	004006b7          	lui	a3,0x400
    8000121c:	0c000637          	lui	a2,0xc000
    80001220:	0c0005b7          	lui	a1,0xc000
    80001224:	8526                	mv	a0,s1
    80001226:	00000097          	auipc	ra,0x0
    8000122a:	f72080e7          	jalr	-142(ra) # 80001198 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    8000122e:	00007917          	auipc	s2,0x7
    80001232:	dd290913          	addi	s2,s2,-558 # 80008000 <etext>
    80001236:	4729                	li	a4,10
    80001238:	80007697          	auipc	a3,0x80007
    8000123c:	dc868693          	addi	a3,a3,-568 # 8000 <_entry-0x7fff8000>
    80001240:	4605                	li	a2,1
    80001242:	067e                	slli	a2,a2,0x1f
    80001244:	85b2                	mv	a1,a2
    80001246:	8526                	mv	a0,s1
    80001248:	00000097          	auipc	ra,0x0
    8000124c:	f50080e7          	jalr	-176(ra) # 80001198 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80001250:	46c5                	li	a3,17
    80001252:	06ee                	slli	a3,a3,0x1b
    80001254:	4719                	li	a4,6
    80001256:	412686b3          	sub	a3,a3,s2
    8000125a:	864a                	mv	a2,s2
    8000125c:	85ca                	mv	a1,s2
    8000125e:	8526                	mv	a0,s1
    80001260:	00000097          	auipc	ra,0x0
    80001264:	f38080e7          	jalr	-200(ra) # 80001198 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80001268:	4729                	li	a4,10
    8000126a:	6685                	lui	a3,0x1
    8000126c:	00006617          	auipc	a2,0x6
    80001270:	d9460613          	addi	a2,a2,-620 # 80007000 <_trampoline>
    80001274:	040005b7          	lui	a1,0x4000
    80001278:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000127a:	05b2                	slli	a1,a1,0xc
    8000127c:	8526                	mv	a0,s1
    8000127e:	00000097          	auipc	ra,0x0
    80001282:	f1a080e7          	jalr	-230(ra) # 80001198 <kvmmap>
  proc_mapstacks(kpgtbl);
    80001286:	8526                	mv	a0,s1
    80001288:	00000097          	auipc	ra,0x0
    8000128c:	630080e7          	jalr	1584(ra) # 800018b8 <proc_mapstacks>
}
    80001290:	8526                	mv	a0,s1
    80001292:	60e2                	ld	ra,24(sp)
    80001294:	6442                	ld	s0,16(sp)
    80001296:	64a2                	ld	s1,8(sp)
    80001298:	6902                	ld	s2,0(sp)
    8000129a:	6105                	addi	sp,sp,32
    8000129c:	8082                	ret

000000008000129e <kvminit>:
{
    8000129e:	1141                	addi	sp,sp,-16
    800012a0:	e406                	sd	ra,8(sp)
    800012a2:	e022                	sd	s0,0(sp)
    800012a4:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800012a6:	00000097          	auipc	ra,0x0
    800012aa:	f22080e7          	jalr	-222(ra) # 800011c8 <kvmmake>
    800012ae:	0000a797          	auipc	a5,0xa
    800012b2:	f2a7b923          	sd	a0,-206(a5) # 8000b1e0 <kernel_pagetable>
}
    800012b6:	60a2                	ld	ra,8(sp)
    800012b8:	6402                	ld	s0,0(sp)
    800012ba:	0141                	addi	sp,sp,16
    800012bc:	8082                	ret

00000000800012be <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800012be:	715d                	addi	sp,sp,-80
    800012c0:	e486                	sd	ra,72(sp)
    800012c2:	e0a2                	sd	s0,64(sp)
    800012c4:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800012c6:	03459793          	slli	a5,a1,0x34
    800012ca:	e39d                	bnez	a5,800012f0 <uvmunmap+0x32>
    800012cc:	f84a                	sd	s2,48(sp)
    800012ce:	f44e                	sd	s3,40(sp)
    800012d0:	f052                	sd	s4,32(sp)
    800012d2:	ec56                	sd	s5,24(sp)
    800012d4:	e85a                	sd	s6,16(sp)
    800012d6:	e45e                	sd	s7,8(sp)
    800012d8:	8a2a                	mv	s4,a0
    800012da:	892e                	mv	s2,a1
    800012dc:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800012de:	0632                	slli	a2,a2,0xc
    800012e0:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    800012e4:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800012e6:	6b05                	lui	s6,0x1
    800012e8:	0935fb63          	bgeu	a1,s3,8000137e <uvmunmap+0xc0>
    800012ec:	fc26                	sd	s1,56(sp)
    800012ee:	a8a9                	j	80001348 <uvmunmap+0x8a>
    800012f0:	fc26                	sd	s1,56(sp)
    800012f2:	f84a                	sd	s2,48(sp)
    800012f4:	f44e                	sd	s3,40(sp)
    800012f6:	f052                	sd	s4,32(sp)
    800012f8:	ec56                	sd	s5,24(sp)
    800012fa:	e85a                	sd	s6,16(sp)
    800012fc:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    800012fe:	00007517          	auipc	a0,0x7
    80001302:	df250513          	addi	a0,a0,-526 # 800080f0 <etext+0xf0>
    80001306:	fffff097          	auipc	ra,0xfffff
    8000130a:	25a080e7          	jalr	602(ra) # 80000560 <panic>
      panic("uvmunmap: walk");
    8000130e:	00007517          	auipc	a0,0x7
    80001312:	dfa50513          	addi	a0,a0,-518 # 80008108 <etext+0x108>
    80001316:	fffff097          	auipc	ra,0xfffff
    8000131a:	24a080e7          	jalr	586(ra) # 80000560 <panic>
      panic("uvmunmap: not mapped");
    8000131e:	00007517          	auipc	a0,0x7
    80001322:	dfa50513          	addi	a0,a0,-518 # 80008118 <etext+0x118>
    80001326:	fffff097          	auipc	ra,0xfffff
    8000132a:	23a080e7          	jalr	570(ra) # 80000560 <panic>
      panic("uvmunmap: not a leaf");
    8000132e:	00007517          	auipc	a0,0x7
    80001332:	e0250513          	addi	a0,a0,-510 # 80008130 <etext+0x130>
    80001336:	fffff097          	auipc	ra,0xfffff
    8000133a:	22a080e7          	jalr	554(ra) # 80000560 <panic>
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    8000133e:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001342:	995a                	add	s2,s2,s6
    80001344:	03397c63          	bgeu	s2,s3,8000137c <uvmunmap+0xbe>
    if((pte = walk(pagetable, a, 0)) == 0)
    80001348:	4601                	li	a2,0
    8000134a:	85ca                	mv	a1,s2
    8000134c:	8552                	mv	a0,s4
    8000134e:	00000097          	auipc	ra,0x0
    80001352:	cc2080e7          	jalr	-830(ra) # 80001010 <walk>
    80001356:	84aa                	mv	s1,a0
    80001358:	d95d                	beqz	a0,8000130e <uvmunmap+0x50>
    if((*pte & PTE_V) == 0)
    8000135a:	6108                	ld	a0,0(a0)
    8000135c:	00157793          	andi	a5,a0,1
    80001360:	dfdd                	beqz	a5,8000131e <uvmunmap+0x60>
    if(PTE_FLAGS(*pte) == PTE_V)
    80001362:	3ff57793          	andi	a5,a0,1023
    80001366:	fd7784e3          	beq	a5,s7,8000132e <uvmunmap+0x70>
    if(do_free){
    8000136a:	fc0a8ae3          	beqz	s5,8000133e <uvmunmap+0x80>
      uint64 pa = PTE2PA(*pte);
    8000136e:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    80001370:	0532                	slli	a0,a0,0xc
    80001372:	fffff097          	auipc	ra,0xfffff
    80001376:	6d8080e7          	jalr	1752(ra) # 80000a4a <kfree>
    8000137a:	b7d1                	j	8000133e <uvmunmap+0x80>
    8000137c:	74e2                	ld	s1,56(sp)
    8000137e:	7942                	ld	s2,48(sp)
    80001380:	79a2                	ld	s3,40(sp)
    80001382:	7a02                	ld	s4,32(sp)
    80001384:	6ae2                	ld	s5,24(sp)
    80001386:	6b42                	ld	s6,16(sp)
    80001388:	6ba2                	ld	s7,8(sp)
  }
}
    8000138a:	60a6                	ld	ra,72(sp)
    8000138c:	6406                	ld	s0,64(sp)
    8000138e:	6161                	addi	sp,sp,80
    80001390:	8082                	ret

0000000080001392 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001392:	1101                	addi	sp,sp,-32
    80001394:	ec06                	sd	ra,24(sp)
    80001396:	e822                	sd	s0,16(sp)
    80001398:	e426                	sd	s1,8(sp)
    8000139a:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    8000139c:	fffff097          	auipc	ra,0xfffff
    800013a0:	7ac080e7          	jalr	1964(ra) # 80000b48 <kalloc>
    800013a4:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800013a6:	c519                	beqz	a0,800013b4 <uvmcreate+0x22>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800013a8:	6605                	lui	a2,0x1
    800013aa:	4581                	li	a1,0
    800013ac:	00000097          	auipc	ra,0x0
    800013b0:	988080e7          	jalr	-1656(ra) # 80000d34 <memset>
  return pagetable;
}
    800013b4:	8526                	mv	a0,s1
    800013b6:	60e2                	ld	ra,24(sp)
    800013b8:	6442                	ld	s0,16(sp)
    800013ba:	64a2                	ld	s1,8(sp)
    800013bc:	6105                	addi	sp,sp,32
    800013be:	8082                	ret

00000000800013c0 <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    800013c0:	7179                	addi	sp,sp,-48
    800013c2:	f406                	sd	ra,40(sp)
    800013c4:	f022                	sd	s0,32(sp)
    800013c6:	ec26                	sd	s1,24(sp)
    800013c8:	e84a                	sd	s2,16(sp)
    800013ca:	e44e                	sd	s3,8(sp)
    800013cc:	e052                	sd	s4,0(sp)
    800013ce:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    800013d0:	6785                	lui	a5,0x1
    800013d2:	04f67863          	bgeu	a2,a5,80001422 <uvmfirst+0x62>
    800013d6:	8a2a                	mv	s4,a0
    800013d8:	89ae                	mv	s3,a1
    800013da:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    800013dc:	fffff097          	auipc	ra,0xfffff
    800013e0:	76c080e7          	jalr	1900(ra) # 80000b48 <kalloc>
    800013e4:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    800013e6:	6605                	lui	a2,0x1
    800013e8:	4581                	li	a1,0
    800013ea:	00000097          	auipc	ra,0x0
    800013ee:	94a080e7          	jalr	-1718(ra) # 80000d34 <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    800013f2:	4779                	li	a4,30
    800013f4:	86ca                	mv	a3,s2
    800013f6:	6605                	lui	a2,0x1
    800013f8:	4581                	li	a1,0
    800013fa:	8552                	mv	a0,s4
    800013fc:	00000097          	auipc	ra,0x0
    80001400:	cfc080e7          	jalr	-772(ra) # 800010f8 <mappages>
  memmove(mem, src, sz);
    80001404:	8626                	mv	a2,s1
    80001406:	85ce                	mv	a1,s3
    80001408:	854a                	mv	a0,s2
    8000140a:	00000097          	auipc	ra,0x0
    8000140e:	986080e7          	jalr	-1658(ra) # 80000d90 <memmove>
}
    80001412:	70a2                	ld	ra,40(sp)
    80001414:	7402                	ld	s0,32(sp)
    80001416:	64e2                	ld	s1,24(sp)
    80001418:	6942                	ld	s2,16(sp)
    8000141a:	69a2                	ld	s3,8(sp)
    8000141c:	6a02                	ld	s4,0(sp)
    8000141e:	6145                	addi	sp,sp,48
    80001420:	8082                	ret
    panic("uvmfirst: more than a page");
    80001422:	00007517          	auipc	a0,0x7
    80001426:	d2650513          	addi	a0,a0,-730 # 80008148 <etext+0x148>
    8000142a:	fffff097          	auipc	ra,0xfffff
    8000142e:	136080e7          	jalr	310(ra) # 80000560 <panic>

0000000080001432 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    80001432:	1101                	addi	sp,sp,-32
    80001434:	ec06                	sd	ra,24(sp)
    80001436:	e822                	sd	s0,16(sp)
    80001438:	e426                	sd	s1,8(sp)
    8000143a:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    8000143c:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    8000143e:	00b67d63          	bgeu	a2,a1,80001458 <uvmdealloc+0x26>
    80001442:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80001444:	6785                	lui	a5,0x1
    80001446:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001448:	00f60733          	add	a4,a2,a5
    8000144c:	76fd                	lui	a3,0xfffff
    8000144e:	8f75                	and	a4,a4,a3
    80001450:	97ae                	add	a5,a5,a1
    80001452:	8ff5                	and	a5,a5,a3
    80001454:	00f76863          	bltu	a4,a5,80001464 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80001458:	8526                	mv	a0,s1
    8000145a:	60e2                	ld	ra,24(sp)
    8000145c:	6442                	ld	s0,16(sp)
    8000145e:	64a2                	ld	s1,8(sp)
    80001460:	6105                	addi	sp,sp,32
    80001462:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001464:	8f99                	sub	a5,a5,a4
    80001466:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80001468:	4685                	li	a3,1
    8000146a:	0007861b          	sext.w	a2,a5
    8000146e:	85ba                	mv	a1,a4
    80001470:	00000097          	auipc	ra,0x0
    80001474:	e4e080e7          	jalr	-434(ra) # 800012be <uvmunmap>
    80001478:	b7c5                	j	80001458 <uvmdealloc+0x26>

000000008000147a <uvmalloc>:
  if(newsz < oldsz)
    8000147a:	0ab66b63          	bltu	a2,a1,80001530 <uvmalloc+0xb6>
{
    8000147e:	7139                	addi	sp,sp,-64
    80001480:	fc06                	sd	ra,56(sp)
    80001482:	f822                	sd	s0,48(sp)
    80001484:	ec4e                	sd	s3,24(sp)
    80001486:	e852                	sd	s4,16(sp)
    80001488:	e456                	sd	s5,8(sp)
    8000148a:	0080                	addi	s0,sp,64
    8000148c:	8aaa                	mv	s5,a0
    8000148e:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001490:	6785                	lui	a5,0x1
    80001492:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001494:	95be                	add	a1,a1,a5
    80001496:	77fd                	lui	a5,0xfffff
    80001498:	00f5f9b3          	and	s3,a1,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    8000149c:	08c9fc63          	bgeu	s3,a2,80001534 <uvmalloc+0xba>
    800014a0:	f426                	sd	s1,40(sp)
    800014a2:	f04a                	sd	s2,32(sp)
    800014a4:	e05a                	sd	s6,0(sp)
    800014a6:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800014a8:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800014ac:	fffff097          	auipc	ra,0xfffff
    800014b0:	69c080e7          	jalr	1692(ra) # 80000b48 <kalloc>
    800014b4:	84aa                	mv	s1,a0
    if(mem == 0){
    800014b6:	c915                	beqz	a0,800014ea <uvmalloc+0x70>
    memset(mem, 0, PGSIZE);
    800014b8:	6605                	lui	a2,0x1
    800014ba:	4581                	li	a1,0
    800014bc:	00000097          	auipc	ra,0x0
    800014c0:	878080e7          	jalr	-1928(ra) # 80000d34 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800014c4:	875a                	mv	a4,s6
    800014c6:	86a6                	mv	a3,s1
    800014c8:	6605                	lui	a2,0x1
    800014ca:	85ca                	mv	a1,s2
    800014cc:	8556                	mv	a0,s5
    800014ce:	00000097          	auipc	ra,0x0
    800014d2:	c2a080e7          	jalr	-982(ra) # 800010f8 <mappages>
    800014d6:	ed05                	bnez	a0,8000150e <uvmalloc+0x94>
  for(a = oldsz; a < newsz; a += PGSIZE){
    800014d8:	6785                	lui	a5,0x1
    800014da:	993e                	add	s2,s2,a5
    800014dc:	fd4968e3          	bltu	s2,s4,800014ac <uvmalloc+0x32>
  return newsz;
    800014e0:	8552                	mv	a0,s4
    800014e2:	74a2                	ld	s1,40(sp)
    800014e4:	7902                	ld	s2,32(sp)
    800014e6:	6b02                	ld	s6,0(sp)
    800014e8:	a821                	j	80001500 <uvmalloc+0x86>
      uvmdealloc(pagetable, a, oldsz);
    800014ea:	864e                	mv	a2,s3
    800014ec:	85ca                	mv	a1,s2
    800014ee:	8556                	mv	a0,s5
    800014f0:	00000097          	auipc	ra,0x0
    800014f4:	f42080e7          	jalr	-190(ra) # 80001432 <uvmdealloc>
      return 0;
    800014f8:	4501                	li	a0,0
    800014fa:	74a2                	ld	s1,40(sp)
    800014fc:	7902                	ld	s2,32(sp)
    800014fe:	6b02                	ld	s6,0(sp)
}
    80001500:	70e2                	ld	ra,56(sp)
    80001502:	7442                	ld	s0,48(sp)
    80001504:	69e2                	ld	s3,24(sp)
    80001506:	6a42                	ld	s4,16(sp)
    80001508:	6aa2                	ld	s5,8(sp)
    8000150a:	6121                	addi	sp,sp,64
    8000150c:	8082                	ret
      kfree(mem);
    8000150e:	8526                	mv	a0,s1
    80001510:	fffff097          	auipc	ra,0xfffff
    80001514:	53a080e7          	jalr	1338(ra) # 80000a4a <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001518:	864e                	mv	a2,s3
    8000151a:	85ca                	mv	a1,s2
    8000151c:	8556                	mv	a0,s5
    8000151e:	00000097          	auipc	ra,0x0
    80001522:	f14080e7          	jalr	-236(ra) # 80001432 <uvmdealloc>
      return 0;
    80001526:	4501                	li	a0,0
    80001528:	74a2                	ld	s1,40(sp)
    8000152a:	7902                	ld	s2,32(sp)
    8000152c:	6b02                	ld	s6,0(sp)
    8000152e:	bfc9                	j	80001500 <uvmalloc+0x86>
    return oldsz;
    80001530:	852e                	mv	a0,a1
}
    80001532:	8082                	ret
  return newsz;
    80001534:	8532                	mv	a0,a2
    80001536:	b7e9                	j	80001500 <uvmalloc+0x86>

0000000080001538 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    80001538:	7179                	addi	sp,sp,-48
    8000153a:	f406                	sd	ra,40(sp)
    8000153c:	f022                	sd	s0,32(sp)
    8000153e:	ec26                	sd	s1,24(sp)
    80001540:	e84a                	sd	s2,16(sp)
    80001542:	e44e                	sd	s3,8(sp)
    80001544:	e052                	sd	s4,0(sp)
    80001546:	1800                	addi	s0,sp,48
    80001548:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    8000154a:	84aa                	mv	s1,a0
    8000154c:	6905                	lui	s2,0x1
    8000154e:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001550:	4985                	li	s3,1
    80001552:	a829                	j	8000156c <freewalk+0x34>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    80001554:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001556:	00c79513          	slli	a0,a5,0xc
    8000155a:	00000097          	auipc	ra,0x0
    8000155e:	fde080e7          	jalr	-34(ra) # 80001538 <freewalk>
      pagetable[i] = 0;
    80001562:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    80001566:	04a1                	addi	s1,s1,8
    80001568:	03248163          	beq	s1,s2,8000158a <freewalk+0x52>
    pte_t pte = pagetable[i];
    8000156c:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    8000156e:	00f7f713          	andi	a4,a5,15
    80001572:	ff3701e3          	beq	a4,s3,80001554 <freewalk+0x1c>
    } else if(pte & PTE_V){
    80001576:	8b85                	andi	a5,a5,1
    80001578:	d7fd                	beqz	a5,80001566 <freewalk+0x2e>
      panic("freewalk: leaf");
    8000157a:	00007517          	auipc	a0,0x7
    8000157e:	bee50513          	addi	a0,a0,-1042 # 80008168 <etext+0x168>
    80001582:	fffff097          	auipc	ra,0xfffff
    80001586:	fde080e7          	jalr	-34(ra) # 80000560 <panic>
    }
  }
  kfree((void*)pagetable);
    8000158a:	8552                	mv	a0,s4
    8000158c:	fffff097          	auipc	ra,0xfffff
    80001590:	4be080e7          	jalr	1214(ra) # 80000a4a <kfree>
}
    80001594:	70a2                	ld	ra,40(sp)
    80001596:	7402                	ld	s0,32(sp)
    80001598:	64e2                	ld	s1,24(sp)
    8000159a:	6942                	ld	s2,16(sp)
    8000159c:	69a2                	ld	s3,8(sp)
    8000159e:	6a02                	ld	s4,0(sp)
    800015a0:	6145                	addi	sp,sp,48
    800015a2:	8082                	ret

00000000800015a4 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800015a4:	1101                	addi	sp,sp,-32
    800015a6:	ec06                	sd	ra,24(sp)
    800015a8:	e822                	sd	s0,16(sp)
    800015aa:	e426                	sd	s1,8(sp)
    800015ac:	1000                	addi	s0,sp,32
    800015ae:	84aa                	mv	s1,a0
  if(sz > 0)
    800015b0:	e999                	bnez	a1,800015c6 <uvmfree+0x22>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    800015b2:	8526                	mv	a0,s1
    800015b4:	00000097          	auipc	ra,0x0
    800015b8:	f84080e7          	jalr	-124(ra) # 80001538 <freewalk>
}
    800015bc:	60e2                	ld	ra,24(sp)
    800015be:	6442                	ld	s0,16(sp)
    800015c0:	64a2                	ld	s1,8(sp)
    800015c2:	6105                	addi	sp,sp,32
    800015c4:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800015c6:	6785                	lui	a5,0x1
    800015c8:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800015ca:	95be                	add	a1,a1,a5
    800015cc:	4685                	li	a3,1
    800015ce:	00c5d613          	srli	a2,a1,0xc
    800015d2:	4581                	li	a1,0
    800015d4:	00000097          	auipc	ra,0x0
    800015d8:	cea080e7          	jalr	-790(ra) # 800012be <uvmunmap>
    800015dc:	bfd9                	j	800015b2 <uvmfree+0xe>

00000000800015de <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    800015de:	c679                	beqz	a2,800016ac <uvmcopy+0xce>
{
    800015e0:	715d                	addi	sp,sp,-80
    800015e2:	e486                	sd	ra,72(sp)
    800015e4:	e0a2                	sd	s0,64(sp)
    800015e6:	fc26                	sd	s1,56(sp)
    800015e8:	f84a                	sd	s2,48(sp)
    800015ea:	f44e                	sd	s3,40(sp)
    800015ec:	f052                	sd	s4,32(sp)
    800015ee:	ec56                	sd	s5,24(sp)
    800015f0:	e85a                	sd	s6,16(sp)
    800015f2:	e45e                	sd	s7,8(sp)
    800015f4:	0880                	addi	s0,sp,80
    800015f6:	8b2a                	mv	s6,a0
    800015f8:	8aae                	mv	s5,a1
    800015fa:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    800015fc:	4981                	li	s3,0
    if((pte = walk(old, i, 0)) == 0)
    800015fe:	4601                	li	a2,0
    80001600:	85ce                	mv	a1,s3
    80001602:	855a                	mv	a0,s6
    80001604:	00000097          	auipc	ra,0x0
    80001608:	a0c080e7          	jalr	-1524(ra) # 80001010 <walk>
    8000160c:	c531                	beqz	a0,80001658 <uvmcopy+0x7a>
      panic("uvmcopy: pte should exist");
    if((*pte & PTE_V) == 0)
    8000160e:	6118                	ld	a4,0(a0)
    80001610:	00177793          	andi	a5,a4,1
    80001614:	cbb1                	beqz	a5,80001668 <uvmcopy+0x8a>
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    80001616:	00a75593          	srli	a1,a4,0xa
    8000161a:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    8000161e:	3ff77493          	andi	s1,a4,1023
    if((mem = kalloc()) == 0)
    80001622:	fffff097          	auipc	ra,0xfffff
    80001626:	526080e7          	jalr	1318(ra) # 80000b48 <kalloc>
    8000162a:	892a                	mv	s2,a0
    8000162c:	c939                	beqz	a0,80001682 <uvmcopy+0xa4>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    8000162e:	6605                	lui	a2,0x1
    80001630:	85de                	mv	a1,s7
    80001632:	fffff097          	auipc	ra,0xfffff
    80001636:	75e080e7          	jalr	1886(ra) # 80000d90 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    8000163a:	8726                	mv	a4,s1
    8000163c:	86ca                	mv	a3,s2
    8000163e:	6605                	lui	a2,0x1
    80001640:	85ce                	mv	a1,s3
    80001642:	8556                	mv	a0,s5
    80001644:	00000097          	auipc	ra,0x0
    80001648:	ab4080e7          	jalr	-1356(ra) # 800010f8 <mappages>
    8000164c:	e515                	bnez	a0,80001678 <uvmcopy+0x9a>
  for(i = 0; i < sz; i += PGSIZE){
    8000164e:	6785                	lui	a5,0x1
    80001650:	99be                	add	s3,s3,a5
    80001652:	fb49e6e3          	bltu	s3,s4,800015fe <uvmcopy+0x20>
    80001656:	a081                	j	80001696 <uvmcopy+0xb8>
      panic("uvmcopy: pte should exist");
    80001658:	00007517          	auipc	a0,0x7
    8000165c:	b2050513          	addi	a0,a0,-1248 # 80008178 <etext+0x178>
    80001660:	fffff097          	auipc	ra,0xfffff
    80001664:	f00080e7          	jalr	-256(ra) # 80000560 <panic>
      panic("uvmcopy: page not present");
    80001668:	00007517          	auipc	a0,0x7
    8000166c:	b3050513          	addi	a0,a0,-1232 # 80008198 <etext+0x198>
    80001670:	fffff097          	auipc	ra,0xfffff
    80001674:	ef0080e7          	jalr	-272(ra) # 80000560 <panic>
      kfree(mem);
    80001678:	854a                	mv	a0,s2
    8000167a:	fffff097          	auipc	ra,0xfffff
    8000167e:	3d0080e7          	jalr	976(ra) # 80000a4a <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80001682:	4685                	li	a3,1
    80001684:	00c9d613          	srli	a2,s3,0xc
    80001688:	4581                	li	a1,0
    8000168a:	8556                	mv	a0,s5
    8000168c:	00000097          	auipc	ra,0x0
    80001690:	c32080e7          	jalr	-974(ra) # 800012be <uvmunmap>
  return -1;
    80001694:	557d                	li	a0,-1
}
    80001696:	60a6                	ld	ra,72(sp)
    80001698:	6406                	ld	s0,64(sp)
    8000169a:	74e2                	ld	s1,56(sp)
    8000169c:	7942                	ld	s2,48(sp)
    8000169e:	79a2                	ld	s3,40(sp)
    800016a0:	7a02                	ld	s4,32(sp)
    800016a2:	6ae2                	ld	s5,24(sp)
    800016a4:	6b42                	ld	s6,16(sp)
    800016a6:	6ba2                	ld	s7,8(sp)
    800016a8:	6161                	addi	sp,sp,80
    800016aa:	8082                	ret
  return 0;
    800016ac:	4501                	li	a0,0
}
    800016ae:	8082                	ret

00000000800016b0 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800016b0:	1141                	addi	sp,sp,-16
    800016b2:	e406                	sd	ra,8(sp)
    800016b4:	e022                	sd	s0,0(sp)
    800016b6:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800016b8:	4601                	li	a2,0
    800016ba:	00000097          	auipc	ra,0x0
    800016be:	956080e7          	jalr	-1706(ra) # 80001010 <walk>
  if(pte == 0)
    800016c2:	c901                	beqz	a0,800016d2 <uvmclear+0x22>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800016c4:	611c                	ld	a5,0(a0)
    800016c6:	9bbd                	andi	a5,a5,-17
    800016c8:	e11c                	sd	a5,0(a0)
}
    800016ca:	60a2                	ld	ra,8(sp)
    800016cc:	6402                	ld	s0,0(sp)
    800016ce:	0141                	addi	sp,sp,16
    800016d0:	8082                	ret
    panic("uvmclear");
    800016d2:	00007517          	auipc	a0,0x7
    800016d6:	ae650513          	addi	a0,a0,-1306 # 800081b8 <etext+0x1b8>
    800016da:	fffff097          	auipc	ra,0xfffff
    800016de:	e86080e7          	jalr	-378(ra) # 80000560 <panic>

00000000800016e2 <copyout>:
int
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    800016e2:	c6bd                	beqz	a3,80001750 <copyout+0x6e>
{
    800016e4:	715d                	addi	sp,sp,-80
    800016e6:	e486                	sd	ra,72(sp)
    800016e8:	e0a2                	sd	s0,64(sp)
    800016ea:	fc26                	sd	s1,56(sp)
    800016ec:	f84a                	sd	s2,48(sp)
    800016ee:	f44e                	sd	s3,40(sp)
    800016f0:	f052                	sd	s4,32(sp)
    800016f2:	ec56                	sd	s5,24(sp)
    800016f4:	e85a                	sd	s6,16(sp)
    800016f6:	e45e                	sd	s7,8(sp)
    800016f8:	e062                	sd	s8,0(sp)
    800016fa:	0880                	addi	s0,sp,80
    800016fc:	8b2a                	mv	s6,a0
    800016fe:	8c2e                	mv	s8,a1
    80001700:	8a32                	mv	s4,a2
    80001702:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(dstva);
    80001704:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (dstva - va0);
    80001706:	6a85                	lui	s5,0x1
    80001708:	a015                	j	8000172c <copyout+0x4a>
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    8000170a:	9562                	add	a0,a0,s8
    8000170c:	0004861b          	sext.w	a2,s1
    80001710:	85d2                	mv	a1,s4
    80001712:	41250533          	sub	a0,a0,s2
    80001716:	fffff097          	auipc	ra,0xfffff
    8000171a:	67a080e7          	jalr	1658(ra) # 80000d90 <memmove>

    len -= n;
    8000171e:	409989b3          	sub	s3,s3,s1
    src += n;
    80001722:	9a26                	add	s4,s4,s1
    dstva = va0 + PGSIZE;
    80001724:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80001728:	02098263          	beqz	s3,8000174c <copyout+0x6a>
    va0 = PGROUNDDOWN(dstva);
    8000172c:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80001730:	85ca                	mv	a1,s2
    80001732:	855a                	mv	a0,s6
    80001734:	00000097          	auipc	ra,0x0
    80001738:	982080e7          	jalr	-1662(ra) # 800010b6 <walkaddr>
    if(pa0 == 0)
    8000173c:	cd01                	beqz	a0,80001754 <copyout+0x72>
    n = PGSIZE - (dstva - va0);
    8000173e:	418904b3          	sub	s1,s2,s8
    80001742:	94d6                	add	s1,s1,s5
    if(n > len)
    80001744:	fc99f3e3          	bgeu	s3,s1,8000170a <copyout+0x28>
    80001748:	84ce                	mv	s1,s3
    8000174a:	b7c1                	j	8000170a <copyout+0x28>
  }
  return 0;
    8000174c:	4501                	li	a0,0
    8000174e:	a021                	j	80001756 <copyout+0x74>
    80001750:	4501                	li	a0,0
}
    80001752:	8082                	ret
      return -1;
    80001754:	557d                	li	a0,-1
}
    80001756:	60a6                	ld	ra,72(sp)
    80001758:	6406                	ld	s0,64(sp)
    8000175a:	74e2                	ld	s1,56(sp)
    8000175c:	7942                	ld	s2,48(sp)
    8000175e:	79a2                	ld	s3,40(sp)
    80001760:	7a02                	ld	s4,32(sp)
    80001762:	6ae2                	ld	s5,24(sp)
    80001764:	6b42                	ld	s6,16(sp)
    80001766:	6ba2                	ld	s7,8(sp)
    80001768:	6c02                	ld	s8,0(sp)
    8000176a:	6161                	addi	sp,sp,80
    8000176c:	8082                	ret

000000008000176e <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    8000176e:	caa5                	beqz	a3,800017de <copyin+0x70>
{
    80001770:	715d                	addi	sp,sp,-80
    80001772:	e486                	sd	ra,72(sp)
    80001774:	e0a2                	sd	s0,64(sp)
    80001776:	fc26                	sd	s1,56(sp)
    80001778:	f84a                	sd	s2,48(sp)
    8000177a:	f44e                	sd	s3,40(sp)
    8000177c:	f052                	sd	s4,32(sp)
    8000177e:	ec56                	sd	s5,24(sp)
    80001780:	e85a                	sd	s6,16(sp)
    80001782:	e45e                	sd	s7,8(sp)
    80001784:	e062                	sd	s8,0(sp)
    80001786:	0880                	addi	s0,sp,80
    80001788:	8b2a                	mv	s6,a0
    8000178a:	8a2e                	mv	s4,a1
    8000178c:	8c32                	mv	s8,a2
    8000178e:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001790:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80001792:	6a85                	lui	s5,0x1
    80001794:	a01d                	j	800017ba <copyin+0x4c>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001796:	018505b3          	add	a1,a0,s8
    8000179a:	0004861b          	sext.w	a2,s1
    8000179e:	412585b3          	sub	a1,a1,s2
    800017a2:	8552                	mv	a0,s4
    800017a4:	fffff097          	auipc	ra,0xfffff
    800017a8:	5ec080e7          	jalr	1516(ra) # 80000d90 <memmove>

    len -= n;
    800017ac:	409989b3          	sub	s3,s3,s1
    dst += n;
    800017b0:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    800017b2:	01590c33          	add	s8,s2,s5
  while(len > 0){
    800017b6:	02098263          	beqz	s3,800017da <copyin+0x6c>
    va0 = PGROUNDDOWN(srcva);
    800017ba:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    800017be:	85ca                	mv	a1,s2
    800017c0:	855a                	mv	a0,s6
    800017c2:	00000097          	auipc	ra,0x0
    800017c6:	8f4080e7          	jalr	-1804(ra) # 800010b6 <walkaddr>
    if(pa0 == 0)
    800017ca:	cd01                	beqz	a0,800017e2 <copyin+0x74>
    n = PGSIZE - (srcva - va0);
    800017cc:	418904b3          	sub	s1,s2,s8
    800017d0:	94d6                	add	s1,s1,s5
    if(n > len)
    800017d2:	fc99f2e3          	bgeu	s3,s1,80001796 <copyin+0x28>
    800017d6:	84ce                	mv	s1,s3
    800017d8:	bf7d                	j	80001796 <copyin+0x28>
  }
  return 0;
    800017da:	4501                	li	a0,0
    800017dc:	a021                	j	800017e4 <copyin+0x76>
    800017de:	4501                	li	a0,0
}
    800017e0:	8082                	ret
      return -1;
    800017e2:	557d                	li	a0,-1
}
    800017e4:	60a6                	ld	ra,72(sp)
    800017e6:	6406                	ld	s0,64(sp)
    800017e8:	74e2                	ld	s1,56(sp)
    800017ea:	7942                	ld	s2,48(sp)
    800017ec:	79a2                	ld	s3,40(sp)
    800017ee:	7a02                	ld	s4,32(sp)
    800017f0:	6ae2                	ld	s5,24(sp)
    800017f2:	6b42                	ld	s6,16(sp)
    800017f4:	6ba2                	ld	s7,8(sp)
    800017f6:	6c02                	ld	s8,0(sp)
    800017f8:	6161                	addi	sp,sp,80
    800017fa:	8082                	ret

00000000800017fc <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800017fc:	cacd                	beqz	a3,800018ae <copyinstr+0xb2>
{
    800017fe:	715d                	addi	sp,sp,-80
    80001800:	e486                	sd	ra,72(sp)
    80001802:	e0a2                	sd	s0,64(sp)
    80001804:	fc26                	sd	s1,56(sp)
    80001806:	f84a                	sd	s2,48(sp)
    80001808:	f44e                	sd	s3,40(sp)
    8000180a:	f052                	sd	s4,32(sp)
    8000180c:	ec56                	sd	s5,24(sp)
    8000180e:	e85a                	sd	s6,16(sp)
    80001810:	e45e                	sd	s7,8(sp)
    80001812:	0880                	addi	s0,sp,80
    80001814:	8a2a                	mv	s4,a0
    80001816:	8b2e                	mv	s6,a1
    80001818:	8bb2                	mv	s7,a2
    8000181a:	8936                	mv	s2,a3
    va0 = PGROUNDDOWN(srcva);
    8000181c:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    8000181e:	6985                	lui	s3,0x1
    80001820:	a825                	j	80001858 <copyinstr+0x5c>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80001822:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    80001826:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80001828:	37fd                	addiw	a5,a5,-1
    8000182a:	0007851b          	sext.w	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    8000182e:	60a6                	ld	ra,72(sp)
    80001830:	6406                	ld	s0,64(sp)
    80001832:	74e2                	ld	s1,56(sp)
    80001834:	7942                	ld	s2,48(sp)
    80001836:	79a2                	ld	s3,40(sp)
    80001838:	7a02                	ld	s4,32(sp)
    8000183a:	6ae2                	ld	s5,24(sp)
    8000183c:	6b42                	ld	s6,16(sp)
    8000183e:	6ba2                	ld	s7,8(sp)
    80001840:	6161                	addi	sp,sp,80
    80001842:	8082                	ret
    80001844:	fff90713          	addi	a4,s2,-1 # fff <_entry-0x7ffff001>
    80001848:	9742                	add	a4,a4,a6
      --max;
    8000184a:	40b70933          	sub	s2,a4,a1
    srcva = va0 + PGSIZE;
    8000184e:	01348bb3          	add	s7,s1,s3
  while(got_null == 0 && max > 0){
    80001852:	04e58663          	beq	a1,a4,8000189e <copyinstr+0xa2>
{
    80001856:	8b3e                	mv	s6,a5
    va0 = PGROUNDDOWN(srcva);
    80001858:	015bf4b3          	and	s1,s7,s5
    pa0 = walkaddr(pagetable, va0);
    8000185c:	85a6                	mv	a1,s1
    8000185e:	8552                	mv	a0,s4
    80001860:	00000097          	auipc	ra,0x0
    80001864:	856080e7          	jalr	-1962(ra) # 800010b6 <walkaddr>
    if(pa0 == 0)
    80001868:	cd0d                	beqz	a0,800018a2 <copyinstr+0xa6>
    n = PGSIZE - (srcva - va0);
    8000186a:	417486b3          	sub	a3,s1,s7
    8000186e:	96ce                	add	a3,a3,s3
    if(n > max)
    80001870:	00d97363          	bgeu	s2,a3,80001876 <copyinstr+0x7a>
    80001874:	86ca                	mv	a3,s2
    char *p = (char *) (pa0 + (srcva - va0));
    80001876:	955e                	add	a0,a0,s7
    80001878:	8d05                	sub	a0,a0,s1
    while(n > 0){
    8000187a:	c695                	beqz	a3,800018a6 <copyinstr+0xaa>
    8000187c:	87da                	mv	a5,s6
    8000187e:	885a                	mv	a6,s6
      if(*p == '\0'){
    80001880:	41650633          	sub	a2,a0,s6
    while(n > 0){
    80001884:	96da                	add	a3,a3,s6
    80001886:	85be                	mv	a1,a5
      if(*p == '\0'){
    80001888:	00f60733          	add	a4,a2,a5
    8000188c:	00074703          	lbu	a4,0(a4) # fffffffffffff000 <end+0xffffffff7ffda918>
    80001890:	db49                	beqz	a4,80001822 <copyinstr+0x26>
        *dst = *p;
    80001892:	00e78023          	sb	a4,0(a5)
      dst++;
    80001896:	0785                	addi	a5,a5,1
    while(n > 0){
    80001898:	fed797e3          	bne	a5,a3,80001886 <copyinstr+0x8a>
    8000189c:	b765                	j	80001844 <copyinstr+0x48>
    8000189e:	4781                	li	a5,0
    800018a0:	b761                	j	80001828 <copyinstr+0x2c>
      return -1;
    800018a2:	557d                	li	a0,-1
    800018a4:	b769                	j	8000182e <copyinstr+0x32>
    srcva = va0 + PGSIZE;
    800018a6:	6b85                	lui	s7,0x1
    800018a8:	9ba6                	add	s7,s7,s1
    800018aa:	87da                	mv	a5,s6
    800018ac:	b76d                	j	80001856 <copyinstr+0x5a>
  int got_null = 0;
    800018ae:	4781                	li	a5,0
  if(got_null){
    800018b0:	37fd                	addiw	a5,a5,-1
    800018b2:	0007851b          	sext.w	a0,a5
}
    800018b6:	8082                	ret

00000000800018b8 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800018b8:	7139                	addi	sp,sp,-64
    800018ba:	fc06                	sd	ra,56(sp)
    800018bc:	f822                	sd	s0,48(sp)
    800018be:	f426                	sd	s1,40(sp)
    800018c0:	f04a                	sd	s2,32(sp)
    800018c2:	ec4e                	sd	s3,24(sp)
    800018c4:	e852                	sd	s4,16(sp)
    800018c6:	e456                	sd	s5,8(sp)
    800018c8:	e05a                	sd	s6,0(sp)
    800018ca:	0080                	addi	s0,sp,64
    800018cc:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    800018ce:	00012497          	auipc	s1,0x12
    800018d2:	fc248493          	addi	s1,s1,-62 # 80013890 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    800018d6:	8b26                	mv	s6,s1
    800018d8:	04fa5937          	lui	s2,0x4fa5
    800018dc:	fa590913          	addi	s2,s2,-91 # 4fa4fa5 <_entry-0x7b05b05b>
    800018e0:	0932                	slli	s2,s2,0xc
    800018e2:	fa590913          	addi	s2,s2,-91
    800018e6:	0932                	slli	s2,s2,0xc
    800018e8:	fa590913          	addi	s2,s2,-91
    800018ec:	0932                	slli	s2,s2,0xc
    800018ee:	fa590913          	addi	s2,s2,-91
    800018f2:	040009b7          	lui	s3,0x4000
    800018f6:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800018f8:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800018fa:	00018a97          	auipc	s5,0x18
    800018fe:	996a8a93          	addi	s5,s5,-1642 # 80019290 <tickslock>
    char *pa = kalloc();
    80001902:	fffff097          	auipc	ra,0xfffff
    80001906:	246080e7          	jalr	582(ra) # 80000b48 <kalloc>
    8000190a:	862a                	mv	a2,a0
    if(pa == 0)
    8000190c:	c121                	beqz	a0,8000194c <proc_mapstacks+0x94>
    uint64 va = KSTACK((int) (p - proc));
    8000190e:	416485b3          	sub	a1,s1,s6
    80001912:	858d                	srai	a1,a1,0x3
    80001914:	032585b3          	mul	a1,a1,s2
    80001918:	2585                	addiw	a1,a1,1
    8000191a:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    8000191e:	4719                	li	a4,6
    80001920:	6685                	lui	a3,0x1
    80001922:	40b985b3          	sub	a1,s3,a1
    80001926:	8552                	mv	a0,s4
    80001928:	00000097          	auipc	ra,0x0
    8000192c:	870080e7          	jalr	-1936(ra) # 80001198 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001930:	16848493          	addi	s1,s1,360
    80001934:	fd5497e3          	bne	s1,s5,80001902 <proc_mapstacks+0x4a>
  }
}
    80001938:	70e2                	ld	ra,56(sp)
    8000193a:	7442                	ld	s0,48(sp)
    8000193c:	74a2                	ld	s1,40(sp)
    8000193e:	7902                	ld	s2,32(sp)
    80001940:	69e2                	ld	s3,24(sp)
    80001942:	6a42                	ld	s4,16(sp)
    80001944:	6aa2                	ld	s5,8(sp)
    80001946:	6b02                	ld	s6,0(sp)
    80001948:	6121                	addi	sp,sp,64
    8000194a:	8082                	ret
      panic("kalloc");
    8000194c:	00007517          	auipc	a0,0x7
    80001950:	87c50513          	addi	a0,a0,-1924 # 800081c8 <etext+0x1c8>
    80001954:	fffff097          	auipc	ra,0xfffff
    80001958:	c0c080e7          	jalr	-1012(ra) # 80000560 <panic>

000000008000195c <procinit>:

// initialize the proc table.
void
procinit(void)
{
    8000195c:	7139                	addi	sp,sp,-64
    8000195e:	fc06                	sd	ra,56(sp)
    80001960:	f822                	sd	s0,48(sp)
    80001962:	f426                	sd	s1,40(sp)
    80001964:	f04a                	sd	s2,32(sp)
    80001966:	ec4e                	sd	s3,24(sp)
    80001968:	e852                	sd	s4,16(sp)
    8000196a:	e456                	sd	s5,8(sp)
    8000196c:	e05a                	sd	s6,0(sp)
    8000196e:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&count_lock, "count_lock");
    80001970:	00007597          	auipc	a1,0x7
    80001974:	86058593          	addi	a1,a1,-1952 # 800081d0 <etext+0x1d0>
    80001978:	00018517          	auipc	a0,0x18
    8000197c:	93050513          	addi	a0,a0,-1744 # 800192a8 <count_lock>
    80001980:	fffff097          	auipc	ra,0xfffff
    80001984:	228080e7          	jalr	552(ra) # 80000ba8 <initlock>
  initlock(&pid_lock, "nextpid");
    80001988:	00007597          	auipc	a1,0x7
    8000198c:	85858593          	addi	a1,a1,-1960 # 800081e0 <etext+0x1e0>
    80001990:	00012517          	auipc	a0,0x12
    80001994:	ad050513          	addi	a0,a0,-1328 # 80013460 <pid_lock>
    80001998:	fffff097          	auipc	ra,0xfffff
    8000199c:	210080e7          	jalr	528(ra) # 80000ba8 <initlock>
  initlock(&wait_lock, "wait_lock");
    800019a0:	00007597          	auipc	a1,0x7
    800019a4:	84858593          	addi	a1,a1,-1976 # 800081e8 <etext+0x1e8>
    800019a8:	00012517          	auipc	a0,0x12
    800019ac:	ad050513          	addi	a0,a0,-1328 # 80013478 <wait_lock>
    800019b0:	fffff097          	auipc	ra,0xfffff
    800019b4:	1f8080e7          	jalr	504(ra) # 80000ba8 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    800019b8:	00012497          	auipc	s1,0x12
    800019bc:	ed848493          	addi	s1,s1,-296 # 80013890 <proc>
      initlock(&p->lock, "proc");
    800019c0:	00007b17          	auipc	s6,0x7
    800019c4:	838b0b13          	addi	s6,s6,-1992 # 800081f8 <etext+0x1f8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    800019c8:	8aa6                	mv	s5,s1
    800019ca:	04fa5937          	lui	s2,0x4fa5
    800019ce:	fa590913          	addi	s2,s2,-91 # 4fa4fa5 <_entry-0x7b05b05b>
    800019d2:	0932                	slli	s2,s2,0xc
    800019d4:	fa590913          	addi	s2,s2,-91
    800019d8:	0932                	slli	s2,s2,0xc
    800019da:	fa590913          	addi	s2,s2,-91
    800019de:	0932                	slli	s2,s2,0xc
    800019e0:	fa590913          	addi	s2,s2,-91
    800019e4:	040009b7          	lui	s3,0x4000
    800019e8:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800019ea:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800019ec:	00018a17          	auipc	s4,0x18
    800019f0:	8a4a0a13          	addi	s4,s4,-1884 # 80019290 <tickslock>
      initlock(&p->lock, "proc");
    800019f4:	85da                	mv	a1,s6
    800019f6:	8526                	mv	a0,s1
    800019f8:	fffff097          	auipc	ra,0xfffff
    800019fc:	1b0080e7          	jalr	432(ra) # 80000ba8 <initlock>
      p->state = UNUSED;
    80001a00:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80001a04:	415487b3          	sub	a5,s1,s5
    80001a08:	878d                	srai	a5,a5,0x3
    80001a0a:	032787b3          	mul	a5,a5,s2
    80001a0e:	2785                	addiw	a5,a5,1
    80001a10:	00d7979b          	slliw	a5,a5,0xd
    80001a14:	40f987b3          	sub	a5,s3,a5
    80001a18:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80001a1a:	16848493          	addi	s1,s1,360
    80001a1e:	fd449be3          	bne	s1,s4,800019f4 <procinit+0x98>
  }
}
    80001a22:	70e2                	ld	ra,56(sp)
    80001a24:	7442                	ld	s0,48(sp)
    80001a26:	74a2                	ld	s1,40(sp)
    80001a28:	7902                	ld	s2,32(sp)
    80001a2a:	69e2                	ld	s3,24(sp)
    80001a2c:	6a42                	ld	s4,16(sp)
    80001a2e:	6aa2                	ld	s5,8(sp)
    80001a30:	6b02                	ld	s6,0(sp)
    80001a32:	6121                	addi	sp,sp,64
    80001a34:	8082                	ret

0000000080001a36 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001a36:	1141                	addi	sp,sp,-16
    80001a38:	e422                	sd	s0,8(sp)
    80001a3a:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80001a3c:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001a3e:	2501                	sext.w	a0,a0
    80001a40:	6422                	ld	s0,8(sp)
    80001a42:	0141                	addi	sp,sp,16
    80001a44:	8082                	ret

0000000080001a46 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80001a46:	1141                	addi	sp,sp,-16
    80001a48:	e422                	sd	s0,8(sp)
    80001a4a:	0800                	addi	s0,sp,16
    80001a4c:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001a4e:	2781                	sext.w	a5,a5
    80001a50:	079e                	slli	a5,a5,0x7
  return c;
}
    80001a52:	00012517          	auipc	a0,0x12
    80001a56:	a3e50513          	addi	a0,a0,-1474 # 80013490 <cpus>
    80001a5a:	953e                	add	a0,a0,a5
    80001a5c:	6422                	ld	s0,8(sp)
    80001a5e:	0141                	addi	sp,sp,16
    80001a60:	8082                	ret

0000000080001a62 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001a62:	1101                	addi	sp,sp,-32
    80001a64:	ec06                	sd	ra,24(sp)
    80001a66:	e822                	sd	s0,16(sp)
    80001a68:	e426                	sd	s1,8(sp)
    80001a6a:	1000                	addi	s0,sp,32
  push_off();
    80001a6c:	fffff097          	auipc	ra,0xfffff
    80001a70:	180080e7          	jalr	384(ra) # 80000bec <push_off>
    80001a74:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001a76:	2781                	sext.w	a5,a5
    80001a78:	079e                	slli	a5,a5,0x7
    80001a7a:	00012717          	auipc	a4,0x12
    80001a7e:	9e670713          	addi	a4,a4,-1562 # 80013460 <pid_lock>
    80001a82:	97ba                	add	a5,a5,a4
    80001a84:	7b84                	ld	s1,48(a5)
  pop_off();
    80001a86:	fffff097          	auipc	ra,0xfffff
    80001a8a:	206080e7          	jalr	518(ra) # 80000c8c <pop_off>
  return p;
}
    80001a8e:	8526                	mv	a0,s1
    80001a90:	60e2                	ld	ra,24(sp)
    80001a92:	6442                	ld	s0,16(sp)
    80001a94:	64a2                	ld	s1,8(sp)
    80001a96:	6105                	addi	sp,sp,32
    80001a98:	8082                	ret

0000000080001a9a <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001a9a:	1141                	addi	sp,sp,-16
    80001a9c:	e406                	sd	ra,8(sp)
    80001a9e:	e022                	sd	s0,0(sp)
    80001aa0:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80001aa2:	00000097          	auipc	ra,0x0
    80001aa6:	fc0080e7          	jalr	-64(ra) # 80001a62 <myproc>
    80001aaa:	fffff097          	auipc	ra,0xfffff
    80001aae:	242080e7          	jalr	578(ra) # 80000cec <release>

  if (first) {
    80001ab2:	00009797          	auipc	a5,0x9
    80001ab6:	69e7a783          	lw	a5,1694(a5) # 8000b150 <first.1>
    80001aba:	eb89                	bnez	a5,80001acc <forkret+0x32>
    // be run from main().
    first = 0;
    fsinit(ROOTDEV);
  }

  usertrapret();
    80001abc:	00001097          	auipc	ra,0x1
    80001ac0:	c5e080e7          	jalr	-930(ra) # 8000271a <usertrapret>
}
    80001ac4:	60a2                	ld	ra,8(sp)
    80001ac6:	6402                	ld	s0,0(sp)
    80001ac8:	0141                	addi	sp,sp,16
    80001aca:	8082                	ret
    first = 0;
    80001acc:	00009797          	auipc	a5,0x9
    80001ad0:	6807a223          	sw	zero,1668(a5) # 8000b150 <first.1>
    fsinit(ROOTDEV);
    80001ad4:	4505                	li	a0,1
    80001ad6:	00002097          	auipc	ra,0x2
    80001ada:	a56080e7          	jalr	-1450(ra) # 8000352c <fsinit>
    80001ade:	bff9                	j	80001abc <forkret+0x22>

0000000080001ae0 <allocpid>:
{
    80001ae0:	1101                	addi	sp,sp,-32
    80001ae2:	ec06                	sd	ra,24(sp)
    80001ae4:	e822                	sd	s0,16(sp)
    80001ae6:	e426                	sd	s1,8(sp)
    80001ae8:	e04a                	sd	s2,0(sp)
    80001aea:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001aec:	00012917          	auipc	s2,0x12
    80001af0:	97490913          	addi	s2,s2,-1676 # 80013460 <pid_lock>
    80001af4:	854a                	mv	a0,s2
    80001af6:	fffff097          	auipc	ra,0xfffff
    80001afa:	142080e7          	jalr	322(ra) # 80000c38 <acquire>
  pid = nextpid;
    80001afe:	00009797          	auipc	a5,0x9
    80001b02:	65678793          	addi	a5,a5,1622 # 8000b154 <nextpid>
    80001b06:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001b08:	0014871b          	addiw	a4,s1,1
    80001b0c:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001b0e:	854a                	mv	a0,s2
    80001b10:	fffff097          	auipc	ra,0xfffff
    80001b14:	1dc080e7          	jalr	476(ra) # 80000cec <release>
}
    80001b18:	8526                	mv	a0,s1
    80001b1a:	60e2                	ld	ra,24(sp)
    80001b1c:	6442                	ld	s0,16(sp)
    80001b1e:	64a2                	ld	s1,8(sp)
    80001b20:	6902                	ld	s2,0(sp)
    80001b22:	6105                	addi	sp,sp,32
    80001b24:	8082                	ret

0000000080001b26 <proc_pagetable>:
{
    80001b26:	1101                	addi	sp,sp,-32
    80001b28:	ec06                	sd	ra,24(sp)
    80001b2a:	e822                	sd	s0,16(sp)
    80001b2c:	e426                	sd	s1,8(sp)
    80001b2e:	e04a                	sd	s2,0(sp)
    80001b30:	1000                	addi	s0,sp,32
    80001b32:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001b34:	00000097          	auipc	ra,0x0
    80001b38:	85e080e7          	jalr	-1954(ra) # 80001392 <uvmcreate>
    80001b3c:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001b3e:	c121                	beqz	a0,80001b7e <proc_pagetable+0x58>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001b40:	4729                	li	a4,10
    80001b42:	00005697          	auipc	a3,0x5
    80001b46:	4be68693          	addi	a3,a3,1214 # 80007000 <_trampoline>
    80001b4a:	6605                	lui	a2,0x1
    80001b4c:	040005b7          	lui	a1,0x4000
    80001b50:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001b52:	05b2                	slli	a1,a1,0xc
    80001b54:	fffff097          	auipc	ra,0xfffff
    80001b58:	5a4080e7          	jalr	1444(ra) # 800010f8 <mappages>
    80001b5c:	02054863          	bltz	a0,80001b8c <proc_pagetable+0x66>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001b60:	4719                	li	a4,6
    80001b62:	05893683          	ld	a3,88(s2)
    80001b66:	6605                	lui	a2,0x1
    80001b68:	020005b7          	lui	a1,0x2000
    80001b6c:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001b6e:	05b6                	slli	a1,a1,0xd
    80001b70:	8526                	mv	a0,s1
    80001b72:	fffff097          	auipc	ra,0xfffff
    80001b76:	586080e7          	jalr	1414(ra) # 800010f8 <mappages>
    80001b7a:	02054163          	bltz	a0,80001b9c <proc_pagetable+0x76>
}
    80001b7e:	8526                	mv	a0,s1
    80001b80:	60e2                	ld	ra,24(sp)
    80001b82:	6442                	ld	s0,16(sp)
    80001b84:	64a2                	ld	s1,8(sp)
    80001b86:	6902                	ld	s2,0(sp)
    80001b88:	6105                	addi	sp,sp,32
    80001b8a:	8082                	ret
    uvmfree(pagetable, 0);
    80001b8c:	4581                	li	a1,0
    80001b8e:	8526                	mv	a0,s1
    80001b90:	00000097          	auipc	ra,0x0
    80001b94:	a14080e7          	jalr	-1516(ra) # 800015a4 <uvmfree>
    return 0;
    80001b98:	4481                	li	s1,0
    80001b9a:	b7d5                	j	80001b7e <proc_pagetable+0x58>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001b9c:	4681                	li	a3,0
    80001b9e:	4605                	li	a2,1
    80001ba0:	040005b7          	lui	a1,0x4000
    80001ba4:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001ba6:	05b2                	slli	a1,a1,0xc
    80001ba8:	8526                	mv	a0,s1
    80001baa:	fffff097          	auipc	ra,0xfffff
    80001bae:	714080e7          	jalr	1812(ra) # 800012be <uvmunmap>
    uvmfree(pagetable, 0);
    80001bb2:	4581                	li	a1,0
    80001bb4:	8526                	mv	a0,s1
    80001bb6:	00000097          	auipc	ra,0x0
    80001bba:	9ee080e7          	jalr	-1554(ra) # 800015a4 <uvmfree>
    return 0;
    80001bbe:	4481                	li	s1,0
    80001bc0:	bf7d                	j	80001b7e <proc_pagetable+0x58>

0000000080001bc2 <proc_freepagetable>:
{
    80001bc2:	1101                	addi	sp,sp,-32
    80001bc4:	ec06                	sd	ra,24(sp)
    80001bc6:	e822                	sd	s0,16(sp)
    80001bc8:	e426                	sd	s1,8(sp)
    80001bca:	e04a                	sd	s2,0(sp)
    80001bcc:	1000                	addi	s0,sp,32
    80001bce:	84aa                	mv	s1,a0
    80001bd0:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001bd2:	4681                	li	a3,0
    80001bd4:	4605                	li	a2,1
    80001bd6:	040005b7          	lui	a1,0x4000
    80001bda:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001bdc:	05b2                	slli	a1,a1,0xc
    80001bde:	fffff097          	auipc	ra,0xfffff
    80001be2:	6e0080e7          	jalr	1760(ra) # 800012be <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001be6:	4681                	li	a3,0
    80001be8:	4605                	li	a2,1
    80001bea:	020005b7          	lui	a1,0x2000
    80001bee:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001bf0:	05b6                	slli	a1,a1,0xd
    80001bf2:	8526                	mv	a0,s1
    80001bf4:	fffff097          	auipc	ra,0xfffff
    80001bf8:	6ca080e7          	jalr	1738(ra) # 800012be <uvmunmap>
  uvmfree(pagetable, sz);
    80001bfc:	85ca                	mv	a1,s2
    80001bfe:	8526                	mv	a0,s1
    80001c00:	00000097          	auipc	ra,0x0
    80001c04:	9a4080e7          	jalr	-1628(ra) # 800015a4 <uvmfree>
}
    80001c08:	60e2                	ld	ra,24(sp)
    80001c0a:	6442                	ld	s0,16(sp)
    80001c0c:	64a2                	ld	s1,8(sp)
    80001c0e:	6902                	ld	s2,0(sp)
    80001c10:	6105                	addi	sp,sp,32
    80001c12:	8082                	ret

0000000080001c14 <freeproc>:
{
    80001c14:	1101                	addi	sp,sp,-32
    80001c16:	ec06                	sd	ra,24(sp)
    80001c18:	e822                	sd	s0,16(sp)
    80001c1a:	e426                	sd	s1,8(sp)
    80001c1c:	1000                	addi	s0,sp,32
    80001c1e:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001c20:	6d28                	ld	a0,88(a0)
    80001c22:	c509                	beqz	a0,80001c2c <freeproc+0x18>
    kfree((void*)p->trapframe);
    80001c24:	fffff097          	auipc	ra,0xfffff
    80001c28:	e26080e7          	jalr	-474(ra) # 80000a4a <kfree>
  p->trapframe = 0;
    80001c2c:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001c30:	68a8                	ld	a0,80(s1)
    80001c32:	c511                	beqz	a0,80001c3e <freeproc+0x2a>
    proc_freepagetable(p->pagetable, p->sz);
    80001c34:	64ac                	ld	a1,72(s1)
    80001c36:	00000097          	auipc	ra,0x0
    80001c3a:	f8c080e7          	jalr	-116(ra) # 80001bc2 <proc_freepagetable>
  p->pagetable = 0;
    80001c3e:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001c42:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001c46:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001c4a:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001c4e:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001c52:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001c56:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001c5a:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001c5e:	0004ac23          	sw	zero,24(s1)
}
    80001c62:	60e2                	ld	ra,24(sp)
    80001c64:	6442                	ld	s0,16(sp)
    80001c66:	64a2                	ld	s1,8(sp)
    80001c68:	6105                	addi	sp,sp,32
    80001c6a:	8082                	ret

0000000080001c6c <allocproc>:
{
    80001c6c:	1101                	addi	sp,sp,-32
    80001c6e:	ec06                	sd	ra,24(sp)
    80001c70:	e822                	sd	s0,16(sp)
    80001c72:	e426                	sd	s1,8(sp)
    80001c74:	e04a                	sd	s2,0(sp)
    80001c76:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001c78:	00012497          	auipc	s1,0x12
    80001c7c:	c1848493          	addi	s1,s1,-1000 # 80013890 <proc>
    80001c80:	00017917          	auipc	s2,0x17
    80001c84:	61090913          	addi	s2,s2,1552 # 80019290 <tickslock>
    acquire(&p->lock);
    80001c88:	8526                	mv	a0,s1
    80001c8a:	fffff097          	auipc	ra,0xfffff
    80001c8e:	fae080e7          	jalr	-82(ra) # 80000c38 <acquire>
    if(p->state == UNUSED) {
    80001c92:	4c9c                	lw	a5,24(s1)
    80001c94:	cf81                	beqz	a5,80001cac <allocproc+0x40>
      release(&p->lock);
    80001c96:	8526                	mv	a0,s1
    80001c98:	fffff097          	auipc	ra,0xfffff
    80001c9c:	054080e7          	jalr	84(ra) # 80000cec <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001ca0:	16848493          	addi	s1,s1,360
    80001ca4:	ff2492e3          	bne	s1,s2,80001c88 <allocproc+0x1c>
  return 0;
    80001ca8:	4481                	li	s1,0
    80001caa:	a889                	j	80001cfc <allocproc+0x90>
  p->pid = allocpid();
    80001cac:	00000097          	auipc	ra,0x0
    80001cb0:	e34080e7          	jalr	-460(ra) # 80001ae0 <allocpid>
    80001cb4:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001cb6:	4785                	li	a5,1
    80001cb8:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001cba:	fffff097          	auipc	ra,0xfffff
    80001cbe:	e8e080e7          	jalr	-370(ra) # 80000b48 <kalloc>
    80001cc2:	892a                	mv	s2,a0
    80001cc4:	eca8                	sd	a0,88(s1)
    80001cc6:	c131                	beqz	a0,80001d0a <allocproc+0x9e>
  p->pagetable = proc_pagetable(p);
    80001cc8:	8526                	mv	a0,s1
    80001cca:	00000097          	auipc	ra,0x0
    80001cce:	e5c080e7          	jalr	-420(ra) # 80001b26 <proc_pagetable>
    80001cd2:	892a                	mv	s2,a0
    80001cd4:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001cd6:	c531                	beqz	a0,80001d22 <allocproc+0xb6>
  memset(&p->context, 0, sizeof(p->context));
    80001cd8:	07000613          	li	a2,112
    80001cdc:	4581                	li	a1,0
    80001cde:	06048513          	addi	a0,s1,96
    80001ce2:	fffff097          	auipc	ra,0xfffff
    80001ce6:	052080e7          	jalr	82(ra) # 80000d34 <memset>
  p->context.ra = (uint64)forkret;
    80001cea:	00000797          	auipc	a5,0x0
    80001cee:	db078793          	addi	a5,a5,-592 # 80001a9a <forkret>
    80001cf2:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001cf4:	60bc                	ld	a5,64(s1)
    80001cf6:	6705                	lui	a4,0x1
    80001cf8:	97ba                	add	a5,a5,a4
    80001cfa:	f4bc                	sd	a5,104(s1)
}
    80001cfc:	8526                	mv	a0,s1
    80001cfe:	60e2                	ld	ra,24(sp)
    80001d00:	6442                	ld	s0,16(sp)
    80001d02:	64a2                	ld	s1,8(sp)
    80001d04:	6902                	ld	s2,0(sp)
    80001d06:	6105                	addi	sp,sp,32
    80001d08:	8082                	ret
    freeproc(p);
    80001d0a:	8526                	mv	a0,s1
    80001d0c:	00000097          	auipc	ra,0x0
    80001d10:	f08080e7          	jalr	-248(ra) # 80001c14 <freeproc>
    release(&p->lock);
    80001d14:	8526                	mv	a0,s1
    80001d16:	fffff097          	auipc	ra,0xfffff
    80001d1a:	fd6080e7          	jalr	-42(ra) # 80000cec <release>
    return 0;
    80001d1e:	84ca                	mv	s1,s2
    80001d20:	bff1                	j	80001cfc <allocproc+0x90>
    freeproc(p);
    80001d22:	8526                	mv	a0,s1
    80001d24:	00000097          	auipc	ra,0x0
    80001d28:	ef0080e7          	jalr	-272(ra) # 80001c14 <freeproc>
    release(&p->lock);
    80001d2c:	8526                	mv	a0,s1
    80001d2e:	fffff097          	auipc	ra,0xfffff
    80001d32:	fbe080e7          	jalr	-66(ra) # 80000cec <release>
    return 0;
    80001d36:	84ca                	mv	s1,s2
    80001d38:	b7d1                	j	80001cfc <allocproc+0x90>

0000000080001d3a <userinit>:
{
    80001d3a:	1101                	addi	sp,sp,-32
    80001d3c:	ec06                	sd	ra,24(sp)
    80001d3e:	e822                	sd	s0,16(sp)
    80001d40:	e426                	sd	s1,8(sp)
    80001d42:	1000                	addi	s0,sp,32
  p = allocproc();
    80001d44:	00000097          	auipc	ra,0x0
    80001d48:	f28080e7          	jalr	-216(ra) # 80001c6c <allocproc>
    80001d4c:	84aa                	mv	s1,a0
  initproc = p;
    80001d4e:	00009797          	auipc	a5,0x9
    80001d52:	48a7bd23          	sd	a0,1178(a5) # 8000b1e8 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001d56:	03400613          	li	a2,52
    80001d5a:	00009597          	auipc	a1,0x9
    80001d5e:	40658593          	addi	a1,a1,1030 # 8000b160 <initcode>
    80001d62:	6928                	ld	a0,80(a0)
    80001d64:	fffff097          	auipc	ra,0xfffff
    80001d68:	65c080e7          	jalr	1628(ra) # 800013c0 <uvmfirst>
  p->sz = PGSIZE;
    80001d6c:	6785                	lui	a5,0x1
    80001d6e:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001d70:	6cb8                	ld	a4,88(s1)
    80001d72:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001d76:	6cb8                	ld	a4,88(s1)
    80001d78:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001d7a:	4641                	li	a2,16
    80001d7c:	00006597          	auipc	a1,0x6
    80001d80:	48458593          	addi	a1,a1,1156 # 80008200 <etext+0x200>
    80001d84:	15848513          	addi	a0,s1,344
    80001d88:	fffff097          	auipc	ra,0xfffff
    80001d8c:	0ee080e7          	jalr	238(ra) # 80000e76 <safestrcpy>
  p->cwd = namei("/");
    80001d90:	00006517          	auipc	a0,0x6
    80001d94:	48050513          	addi	a0,a0,1152 # 80008210 <etext+0x210>
    80001d98:	00002097          	auipc	ra,0x2
    80001d9c:	1e6080e7          	jalr	486(ra) # 80003f7e <namei>
    80001da0:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001da4:	478d                	li	a5,3
    80001da6:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001da8:	8526                	mv	a0,s1
    80001daa:	fffff097          	auipc	ra,0xfffff
    80001dae:	f42080e7          	jalr	-190(ra) # 80000cec <release>
}
    80001db2:	60e2                	ld	ra,24(sp)
    80001db4:	6442                	ld	s0,16(sp)
    80001db6:	64a2                	ld	s1,8(sp)
    80001db8:	6105                	addi	sp,sp,32
    80001dba:	8082                	ret

0000000080001dbc <growproc>:
{
    80001dbc:	1101                	addi	sp,sp,-32
    80001dbe:	ec06                	sd	ra,24(sp)
    80001dc0:	e822                	sd	s0,16(sp)
    80001dc2:	e426                	sd	s1,8(sp)
    80001dc4:	e04a                	sd	s2,0(sp)
    80001dc6:	1000                	addi	s0,sp,32
    80001dc8:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001dca:	00000097          	auipc	ra,0x0
    80001dce:	c98080e7          	jalr	-872(ra) # 80001a62 <myproc>
    80001dd2:	84aa                	mv	s1,a0
  sz = p->sz;
    80001dd4:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001dd6:	01204c63          	bgtz	s2,80001dee <growproc+0x32>
  } else if(n < 0){
    80001dda:	02094663          	bltz	s2,80001e06 <growproc+0x4a>
  p->sz = sz;
    80001dde:	e4ac                	sd	a1,72(s1)
  return 0;
    80001de0:	4501                	li	a0,0
}
    80001de2:	60e2                	ld	ra,24(sp)
    80001de4:	6442                	ld	s0,16(sp)
    80001de6:	64a2                	ld	s1,8(sp)
    80001de8:	6902                	ld	s2,0(sp)
    80001dea:	6105                	addi	sp,sp,32
    80001dec:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001dee:	4691                	li	a3,4
    80001df0:	00b90633          	add	a2,s2,a1
    80001df4:	6928                	ld	a0,80(a0)
    80001df6:	fffff097          	auipc	ra,0xfffff
    80001dfa:	684080e7          	jalr	1668(ra) # 8000147a <uvmalloc>
    80001dfe:	85aa                	mv	a1,a0
    80001e00:	fd79                	bnez	a0,80001dde <growproc+0x22>
      return -1;
    80001e02:	557d                	li	a0,-1
    80001e04:	bff9                	j	80001de2 <growproc+0x26>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001e06:	00b90633          	add	a2,s2,a1
    80001e0a:	6928                	ld	a0,80(a0)
    80001e0c:	fffff097          	auipc	ra,0xfffff
    80001e10:	626080e7          	jalr	1574(ra) # 80001432 <uvmdealloc>
    80001e14:	85aa                	mv	a1,a0
    80001e16:	b7e1                	j	80001dde <growproc+0x22>

0000000080001e18 <fork>:
{
    80001e18:	7139                	addi	sp,sp,-64
    80001e1a:	fc06                	sd	ra,56(sp)
    80001e1c:	f822                	sd	s0,48(sp)
    80001e1e:	f04a                	sd	s2,32(sp)
    80001e20:	e456                	sd	s5,8(sp)
    80001e22:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001e24:	00000097          	auipc	ra,0x0
    80001e28:	c3e080e7          	jalr	-962(ra) # 80001a62 <myproc>
    80001e2c:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001e2e:	00000097          	auipc	ra,0x0
    80001e32:	e3e080e7          	jalr	-450(ra) # 80001c6c <allocproc>
    80001e36:	12050063          	beqz	a0,80001f56 <fork+0x13e>
    80001e3a:	e852                	sd	s4,16(sp)
    80001e3c:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001e3e:	048ab603          	ld	a2,72(s5)
    80001e42:	692c                	ld	a1,80(a0)
    80001e44:	050ab503          	ld	a0,80(s5)
    80001e48:	fffff097          	auipc	ra,0xfffff
    80001e4c:	796080e7          	jalr	1942(ra) # 800015de <uvmcopy>
    80001e50:	04054a63          	bltz	a0,80001ea4 <fork+0x8c>
    80001e54:	f426                	sd	s1,40(sp)
    80001e56:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001e58:	048ab783          	ld	a5,72(s5)
    80001e5c:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001e60:	058ab683          	ld	a3,88(s5)
    80001e64:	87b6                	mv	a5,a3
    80001e66:	058a3703          	ld	a4,88(s4)
    80001e6a:	12068693          	addi	a3,a3,288
    80001e6e:	0007b803          	ld	a6,0(a5) # 1000 <_entry-0x7ffff000>
    80001e72:	6788                	ld	a0,8(a5)
    80001e74:	6b8c                	ld	a1,16(a5)
    80001e76:	6f90                	ld	a2,24(a5)
    80001e78:	01073023          	sd	a6,0(a4)
    80001e7c:	e708                	sd	a0,8(a4)
    80001e7e:	eb0c                	sd	a1,16(a4)
    80001e80:	ef10                	sd	a2,24(a4)
    80001e82:	02078793          	addi	a5,a5,32
    80001e86:	02070713          	addi	a4,a4,32
    80001e8a:	fed792e3          	bne	a5,a3,80001e6e <fork+0x56>
  np->trapframe->a0 = 0;
    80001e8e:	058a3783          	ld	a5,88(s4)
    80001e92:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001e96:	0d0a8493          	addi	s1,s5,208
    80001e9a:	0d0a0913          	addi	s2,s4,208
    80001e9e:	150a8993          	addi	s3,s5,336
    80001ea2:	a015                	j	80001ec6 <fork+0xae>
    freeproc(np);
    80001ea4:	8552                	mv	a0,s4
    80001ea6:	00000097          	auipc	ra,0x0
    80001eaa:	d6e080e7          	jalr	-658(ra) # 80001c14 <freeproc>
    release(&np->lock);
    80001eae:	8552                	mv	a0,s4
    80001eb0:	fffff097          	auipc	ra,0xfffff
    80001eb4:	e3c080e7          	jalr	-452(ra) # 80000cec <release>
    return -1;
    80001eb8:	597d                	li	s2,-1
    80001eba:	6a42                	ld	s4,16(sp)
    80001ebc:	a071                	j	80001f48 <fork+0x130>
  for(i = 0; i < NOFILE; i++)
    80001ebe:	04a1                	addi	s1,s1,8
    80001ec0:	0921                	addi	s2,s2,8
    80001ec2:	01348b63          	beq	s1,s3,80001ed8 <fork+0xc0>
    if(p->ofile[i])
    80001ec6:	6088                	ld	a0,0(s1)
    80001ec8:	d97d                	beqz	a0,80001ebe <fork+0xa6>
      np->ofile[i] = filedup(p->ofile[i]);
    80001eca:	00002097          	auipc	ra,0x2
    80001ece:	72c080e7          	jalr	1836(ra) # 800045f6 <filedup>
    80001ed2:	00a93023          	sd	a0,0(s2)
    80001ed6:	b7e5                	j	80001ebe <fork+0xa6>
  np->cwd = idup(p->cwd);
    80001ed8:	150ab503          	ld	a0,336(s5)
    80001edc:	00002097          	auipc	ra,0x2
    80001ee0:	896080e7          	jalr	-1898(ra) # 80003772 <idup>
    80001ee4:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001ee8:	4641                	li	a2,16
    80001eea:	158a8593          	addi	a1,s5,344
    80001eee:	158a0513          	addi	a0,s4,344
    80001ef2:	fffff097          	auipc	ra,0xfffff
    80001ef6:	f84080e7          	jalr	-124(ra) # 80000e76 <safestrcpy>
  pid = np->pid;
    80001efa:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001efe:	8552                	mv	a0,s4
    80001f00:	fffff097          	auipc	ra,0xfffff
    80001f04:	dec080e7          	jalr	-532(ra) # 80000cec <release>
  acquire(&wait_lock);
    80001f08:	00011497          	auipc	s1,0x11
    80001f0c:	57048493          	addi	s1,s1,1392 # 80013478 <wait_lock>
    80001f10:	8526                	mv	a0,s1
    80001f12:	fffff097          	auipc	ra,0xfffff
    80001f16:	d26080e7          	jalr	-730(ra) # 80000c38 <acquire>
  np->parent = p;
    80001f1a:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001f1e:	8526                	mv	a0,s1
    80001f20:	fffff097          	auipc	ra,0xfffff
    80001f24:	dcc080e7          	jalr	-564(ra) # 80000cec <release>
  acquire(&np->lock);
    80001f28:	8552                	mv	a0,s4
    80001f2a:	fffff097          	auipc	ra,0xfffff
    80001f2e:	d0e080e7          	jalr	-754(ra) # 80000c38 <acquire>
  np->state = RUNNABLE;
    80001f32:	478d                	li	a5,3
    80001f34:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001f38:	8552                	mv	a0,s4
    80001f3a:	fffff097          	auipc	ra,0xfffff
    80001f3e:	db2080e7          	jalr	-590(ra) # 80000cec <release>
  return pid;
    80001f42:	74a2                	ld	s1,40(sp)
    80001f44:	69e2                	ld	s3,24(sp)
    80001f46:	6a42                	ld	s4,16(sp)
}
    80001f48:	854a                	mv	a0,s2
    80001f4a:	70e2                	ld	ra,56(sp)
    80001f4c:	7442                	ld	s0,48(sp)
    80001f4e:	7902                	ld	s2,32(sp)
    80001f50:	6aa2                	ld	s5,8(sp)
    80001f52:	6121                	addi	sp,sp,64
    80001f54:	8082                	ret
    return -1;
    80001f56:	597d                	li	s2,-1
    80001f58:	bfc5                	j	80001f48 <fork+0x130>

0000000080001f5a <scheduler>:
{
    80001f5a:	7139                	addi	sp,sp,-64
    80001f5c:	fc06                	sd	ra,56(sp)
    80001f5e:	f822                	sd	s0,48(sp)
    80001f60:	f426                	sd	s1,40(sp)
    80001f62:	f04a                	sd	s2,32(sp)
    80001f64:	ec4e                	sd	s3,24(sp)
    80001f66:	e852                	sd	s4,16(sp)
    80001f68:	e456                	sd	s5,8(sp)
    80001f6a:	e05a                	sd	s6,0(sp)
    80001f6c:	0080                	addi	s0,sp,64
    80001f6e:	8792                	mv	a5,tp
  int id = r_tp();
    80001f70:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001f72:	00779a93          	slli	s5,a5,0x7
    80001f76:	00011717          	auipc	a4,0x11
    80001f7a:	4ea70713          	addi	a4,a4,1258 # 80013460 <pid_lock>
    80001f7e:	9756                	add	a4,a4,s5
    80001f80:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001f84:	00011717          	auipc	a4,0x11
    80001f88:	51470713          	addi	a4,a4,1300 # 80013498 <cpus+0x8>
    80001f8c:	9aba                	add	s5,s5,a4
      if(p->state == RUNNABLE) {
    80001f8e:	498d                	li	s3,3
        p->state = RUNNING;
    80001f90:	4b11                	li	s6,4
        c->proc = p;
    80001f92:	079e                	slli	a5,a5,0x7
    80001f94:	00011a17          	auipc	s4,0x11
    80001f98:	4cca0a13          	addi	s4,s4,1228 # 80013460 <pid_lock>
    80001f9c:	9a3e                	add	s4,s4,a5
    for(p = proc; p < &proc[NPROC]; p++) {
    80001f9e:	00017917          	auipc	s2,0x17
    80001fa2:	2f290913          	addi	s2,s2,754 # 80019290 <tickslock>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001fa6:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001faa:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001fae:	10079073          	csrw	sstatus,a5
    80001fb2:	00012497          	auipc	s1,0x12
    80001fb6:	8de48493          	addi	s1,s1,-1826 # 80013890 <proc>
    80001fba:	a811                	j	80001fce <scheduler+0x74>
      release(&p->lock);
    80001fbc:	8526                	mv	a0,s1
    80001fbe:	fffff097          	auipc	ra,0xfffff
    80001fc2:	d2e080e7          	jalr	-722(ra) # 80000cec <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001fc6:	16848493          	addi	s1,s1,360
    80001fca:	fd248ee3          	beq	s1,s2,80001fa6 <scheduler+0x4c>
      acquire(&p->lock);
    80001fce:	8526                	mv	a0,s1
    80001fd0:	fffff097          	auipc	ra,0xfffff
    80001fd4:	c68080e7          	jalr	-920(ra) # 80000c38 <acquire>
      if(p->state == RUNNABLE) {
    80001fd8:	4c9c                	lw	a5,24(s1)
    80001fda:	ff3791e3          	bne	a5,s3,80001fbc <scheduler+0x62>
        p->state = RUNNING;
    80001fde:	0164ac23          	sw	s6,24(s1)
        c->proc = p;
    80001fe2:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001fe6:	06048593          	addi	a1,s1,96
    80001fea:	8556                	mv	a0,s5
    80001fec:	00000097          	auipc	ra,0x0
    80001ff0:	684080e7          	jalr	1668(ra) # 80002670 <swtch>
        c->proc = 0;
    80001ff4:	020a3823          	sd	zero,48(s4)
    80001ff8:	b7d1                	j	80001fbc <scheduler+0x62>

0000000080001ffa <sched>:
{
    80001ffa:	7179                	addi	sp,sp,-48
    80001ffc:	f406                	sd	ra,40(sp)
    80001ffe:	f022                	sd	s0,32(sp)
    80002000:	ec26                	sd	s1,24(sp)
    80002002:	e84a                	sd	s2,16(sp)
    80002004:	e44e                	sd	s3,8(sp)
    80002006:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80002008:	00000097          	auipc	ra,0x0
    8000200c:	a5a080e7          	jalr	-1446(ra) # 80001a62 <myproc>
    80002010:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80002012:	fffff097          	auipc	ra,0xfffff
    80002016:	bac080e7          	jalr	-1108(ra) # 80000bbe <holding>
    8000201a:	c93d                	beqz	a0,80002090 <sched+0x96>
  asm volatile("mv %0, tp" : "=r" (x) );
    8000201c:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    8000201e:	2781                	sext.w	a5,a5
    80002020:	079e                	slli	a5,a5,0x7
    80002022:	00011717          	auipc	a4,0x11
    80002026:	43e70713          	addi	a4,a4,1086 # 80013460 <pid_lock>
    8000202a:	97ba                	add	a5,a5,a4
    8000202c:	0a87a703          	lw	a4,168(a5)
    80002030:	4785                	li	a5,1
    80002032:	06f71763          	bne	a4,a5,800020a0 <sched+0xa6>
  if(p->state == RUNNING)
    80002036:	4c98                	lw	a4,24(s1)
    80002038:	4791                	li	a5,4
    8000203a:	06f70b63          	beq	a4,a5,800020b0 <sched+0xb6>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000203e:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002042:	8b89                	andi	a5,a5,2
  if(intr_get())
    80002044:	efb5                	bnez	a5,800020c0 <sched+0xc6>
  asm volatile("mv %0, tp" : "=r" (x) );
    80002046:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80002048:	00011917          	auipc	s2,0x11
    8000204c:	41890913          	addi	s2,s2,1048 # 80013460 <pid_lock>
    80002050:	2781                	sext.w	a5,a5
    80002052:	079e                	slli	a5,a5,0x7
    80002054:	97ca                	add	a5,a5,s2
    80002056:	0ac7a983          	lw	s3,172(a5)
    8000205a:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    8000205c:	2781                	sext.w	a5,a5
    8000205e:	079e                	slli	a5,a5,0x7
    80002060:	00011597          	auipc	a1,0x11
    80002064:	43858593          	addi	a1,a1,1080 # 80013498 <cpus+0x8>
    80002068:	95be                	add	a1,a1,a5
    8000206a:	06048513          	addi	a0,s1,96
    8000206e:	00000097          	auipc	ra,0x0
    80002072:	602080e7          	jalr	1538(ra) # 80002670 <swtch>
    80002076:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80002078:	2781                	sext.w	a5,a5
    8000207a:	079e                	slli	a5,a5,0x7
    8000207c:	993e                	add	s2,s2,a5
    8000207e:	0b392623          	sw	s3,172(s2)
}
    80002082:	70a2                	ld	ra,40(sp)
    80002084:	7402                	ld	s0,32(sp)
    80002086:	64e2                	ld	s1,24(sp)
    80002088:	6942                	ld	s2,16(sp)
    8000208a:	69a2                	ld	s3,8(sp)
    8000208c:	6145                	addi	sp,sp,48
    8000208e:	8082                	ret
    panic("sched p->lock");
    80002090:	00006517          	auipc	a0,0x6
    80002094:	18850513          	addi	a0,a0,392 # 80008218 <etext+0x218>
    80002098:	ffffe097          	auipc	ra,0xffffe
    8000209c:	4c8080e7          	jalr	1224(ra) # 80000560 <panic>
    panic("sched locks");
    800020a0:	00006517          	auipc	a0,0x6
    800020a4:	18850513          	addi	a0,a0,392 # 80008228 <etext+0x228>
    800020a8:	ffffe097          	auipc	ra,0xffffe
    800020ac:	4b8080e7          	jalr	1208(ra) # 80000560 <panic>
    panic("sched running");
    800020b0:	00006517          	auipc	a0,0x6
    800020b4:	18850513          	addi	a0,a0,392 # 80008238 <etext+0x238>
    800020b8:	ffffe097          	auipc	ra,0xffffe
    800020bc:	4a8080e7          	jalr	1192(ra) # 80000560 <panic>
    panic("sched interruptible");
    800020c0:	00006517          	auipc	a0,0x6
    800020c4:	18850513          	addi	a0,a0,392 # 80008248 <etext+0x248>
    800020c8:	ffffe097          	auipc	ra,0xffffe
    800020cc:	498080e7          	jalr	1176(ra) # 80000560 <panic>

00000000800020d0 <yield>:
{
    800020d0:	1101                	addi	sp,sp,-32
    800020d2:	ec06                	sd	ra,24(sp)
    800020d4:	e822                	sd	s0,16(sp)
    800020d6:	e426                	sd	s1,8(sp)
    800020d8:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    800020da:	00000097          	auipc	ra,0x0
    800020de:	988080e7          	jalr	-1656(ra) # 80001a62 <myproc>
    800020e2:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800020e4:	fffff097          	auipc	ra,0xfffff
    800020e8:	b54080e7          	jalr	-1196(ra) # 80000c38 <acquire>
  p->state = RUNNABLE;
    800020ec:	478d                	li	a5,3
    800020ee:	cc9c                	sw	a5,24(s1)
  sched();
    800020f0:	00000097          	auipc	ra,0x0
    800020f4:	f0a080e7          	jalr	-246(ra) # 80001ffa <sched>
  release(&p->lock);
    800020f8:	8526                	mv	a0,s1
    800020fa:	fffff097          	auipc	ra,0xfffff
    800020fe:	bf2080e7          	jalr	-1038(ra) # 80000cec <release>
}
    80002102:	60e2                	ld	ra,24(sp)
    80002104:	6442                	ld	s0,16(sp)
    80002106:	64a2                	ld	s1,8(sp)
    80002108:	6105                	addi	sp,sp,32
    8000210a:	8082                	ret

000000008000210c <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    8000210c:	7179                	addi	sp,sp,-48
    8000210e:	f406                	sd	ra,40(sp)
    80002110:	f022                	sd	s0,32(sp)
    80002112:	ec26                	sd	s1,24(sp)
    80002114:	e84a                	sd	s2,16(sp)
    80002116:	e44e                	sd	s3,8(sp)
    80002118:	1800                	addi	s0,sp,48
    8000211a:	89aa                	mv	s3,a0
    8000211c:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000211e:	00000097          	auipc	ra,0x0
    80002122:	944080e7          	jalr	-1724(ra) # 80001a62 <myproc>
    80002126:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80002128:	fffff097          	auipc	ra,0xfffff
    8000212c:	b10080e7          	jalr	-1264(ra) # 80000c38 <acquire>
  release(lk);
    80002130:	854a                	mv	a0,s2
    80002132:	fffff097          	auipc	ra,0xfffff
    80002136:	bba080e7          	jalr	-1094(ra) # 80000cec <release>

  // Go to sleep.
  p->chan = chan;
    8000213a:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    8000213e:	4789                	li	a5,2
    80002140:	cc9c                	sw	a5,24(s1)

  sched();
    80002142:	00000097          	auipc	ra,0x0
    80002146:	eb8080e7          	jalr	-328(ra) # 80001ffa <sched>

  // Tidy up.
  p->chan = 0;
    8000214a:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    8000214e:	8526                	mv	a0,s1
    80002150:	fffff097          	auipc	ra,0xfffff
    80002154:	b9c080e7          	jalr	-1124(ra) # 80000cec <release>
  acquire(lk);
    80002158:	854a                	mv	a0,s2
    8000215a:	fffff097          	auipc	ra,0xfffff
    8000215e:	ade080e7          	jalr	-1314(ra) # 80000c38 <acquire>
}
    80002162:	70a2                	ld	ra,40(sp)
    80002164:	7402                	ld	s0,32(sp)
    80002166:	64e2                	ld	s1,24(sp)
    80002168:	6942                	ld	s2,16(sp)
    8000216a:	69a2                	ld	s3,8(sp)
    8000216c:	6145                	addi	sp,sp,48
    8000216e:	8082                	ret

0000000080002170 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    80002170:	7139                	addi	sp,sp,-64
    80002172:	fc06                	sd	ra,56(sp)
    80002174:	f822                	sd	s0,48(sp)
    80002176:	f426                	sd	s1,40(sp)
    80002178:	f04a                	sd	s2,32(sp)
    8000217a:	ec4e                	sd	s3,24(sp)
    8000217c:	e852                	sd	s4,16(sp)
    8000217e:	e456                	sd	s5,8(sp)
    80002180:	0080                	addi	s0,sp,64
    80002182:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80002184:	00011497          	auipc	s1,0x11
    80002188:	70c48493          	addi	s1,s1,1804 # 80013890 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    8000218c:	4989                	li	s3,2
        p->state = RUNNABLE;
    8000218e:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80002190:	00017917          	auipc	s2,0x17
    80002194:	10090913          	addi	s2,s2,256 # 80019290 <tickslock>
    80002198:	a811                	j	800021ac <wakeup+0x3c>
      }
      release(&p->lock);
    8000219a:	8526                	mv	a0,s1
    8000219c:	fffff097          	auipc	ra,0xfffff
    800021a0:	b50080e7          	jalr	-1200(ra) # 80000cec <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800021a4:	16848493          	addi	s1,s1,360
    800021a8:	03248663          	beq	s1,s2,800021d4 <wakeup+0x64>
    if(p != myproc()){
    800021ac:	00000097          	auipc	ra,0x0
    800021b0:	8b6080e7          	jalr	-1866(ra) # 80001a62 <myproc>
    800021b4:	fea488e3          	beq	s1,a0,800021a4 <wakeup+0x34>
      acquire(&p->lock);
    800021b8:	8526                	mv	a0,s1
    800021ba:	fffff097          	auipc	ra,0xfffff
    800021be:	a7e080e7          	jalr	-1410(ra) # 80000c38 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    800021c2:	4c9c                	lw	a5,24(s1)
    800021c4:	fd379be3          	bne	a5,s3,8000219a <wakeup+0x2a>
    800021c8:	709c                	ld	a5,32(s1)
    800021ca:	fd4798e3          	bne	a5,s4,8000219a <wakeup+0x2a>
        p->state = RUNNABLE;
    800021ce:	0154ac23          	sw	s5,24(s1)
    800021d2:	b7e1                	j	8000219a <wakeup+0x2a>
    }
  }
}
    800021d4:	70e2                	ld	ra,56(sp)
    800021d6:	7442                	ld	s0,48(sp)
    800021d8:	74a2                	ld	s1,40(sp)
    800021da:	7902                	ld	s2,32(sp)
    800021dc:	69e2                	ld	s3,24(sp)
    800021de:	6a42                	ld	s4,16(sp)
    800021e0:	6aa2                	ld	s5,8(sp)
    800021e2:	6121                	addi	sp,sp,64
    800021e4:	8082                	ret

00000000800021e6 <reparent>:
{
    800021e6:	7179                	addi	sp,sp,-48
    800021e8:	f406                	sd	ra,40(sp)
    800021ea:	f022                	sd	s0,32(sp)
    800021ec:	ec26                	sd	s1,24(sp)
    800021ee:	e84a                	sd	s2,16(sp)
    800021f0:	e44e                	sd	s3,8(sp)
    800021f2:	e052                	sd	s4,0(sp)
    800021f4:	1800                	addi	s0,sp,48
    800021f6:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800021f8:	00011497          	auipc	s1,0x11
    800021fc:	69848493          	addi	s1,s1,1688 # 80013890 <proc>
      pp->parent = initproc;
    80002200:	00009a17          	auipc	s4,0x9
    80002204:	fe8a0a13          	addi	s4,s4,-24 # 8000b1e8 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80002208:	00017997          	auipc	s3,0x17
    8000220c:	08898993          	addi	s3,s3,136 # 80019290 <tickslock>
    80002210:	a029                	j	8000221a <reparent+0x34>
    80002212:	16848493          	addi	s1,s1,360
    80002216:	01348d63          	beq	s1,s3,80002230 <reparent+0x4a>
    if(pp->parent == p){
    8000221a:	7c9c                	ld	a5,56(s1)
    8000221c:	ff279be3          	bne	a5,s2,80002212 <reparent+0x2c>
      pp->parent = initproc;
    80002220:	000a3503          	ld	a0,0(s4)
    80002224:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80002226:	00000097          	auipc	ra,0x0
    8000222a:	f4a080e7          	jalr	-182(ra) # 80002170 <wakeup>
    8000222e:	b7d5                	j	80002212 <reparent+0x2c>
}
    80002230:	70a2                	ld	ra,40(sp)
    80002232:	7402                	ld	s0,32(sp)
    80002234:	64e2                	ld	s1,24(sp)
    80002236:	6942                	ld	s2,16(sp)
    80002238:	69a2                	ld	s3,8(sp)
    8000223a:	6a02                	ld	s4,0(sp)
    8000223c:	6145                	addi	sp,sp,48
    8000223e:	8082                	ret

0000000080002240 <exit>:
{
    80002240:	7179                	addi	sp,sp,-48
    80002242:	f406                	sd	ra,40(sp)
    80002244:	f022                	sd	s0,32(sp)
    80002246:	ec26                	sd	s1,24(sp)
    80002248:	e84a                	sd	s2,16(sp)
    8000224a:	e44e                	sd	s3,8(sp)
    8000224c:	e052                	sd	s4,0(sp)
    8000224e:	1800                	addi	s0,sp,48
    80002250:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80002252:	00000097          	auipc	ra,0x0
    80002256:	810080e7          	jalr	-2032(ra) # 80001a62 <myproc>
    8000225a:	89aa                	mv	s3,a0
  if(p == initproc)
    8000225c:	00009797          	auipc	a5,0x9
    80002260:	f8c7b783          	ld	a5,-116(a5) # 8000b1e8 <initproc>
    80002264:	0d050493          	addi	s1,a0,208
    80002268:	15050913          	addi	s2,a0,336
    8000226c:	02a79363          	bne	a5,a0,80002292 <exit+0x52>
    panic("init exiting");
    80002270:	00006517          	auipc	a0,0x6
    80002274:	ff050513          	addi	a0,a0,-16 # 80008260 <etext+0x260>
    80002278:	ffffe097          	auipc	ra,0xffffe
    8000227c:	2e8080e7          	jalr	744(ra) # 80000560 <panic>
      fileclose(f);
    80002280:	00002097          	auipc	ra,0x2
    80002284:	3c8080e7          	jalr	968(ra) # 80004648 <fileclose>
      p->ofile[fd] = 0;
    80002288:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    8000228c:	04a1                	addi	s1,s1,8
    8000228e:	01248563          	beq	s1,s2,80002298 <exit+0x58>
    if(p->ofile[fd]){
    80002292:	6088                	ld	a0,0(s1)
    80002294:	f575                	bnez	a0,80002280 <exit+0x40>
    80002296:	bfdd                	j	8000228c <exit+0x4c>
  begin_op();
    80002298:	00002097          	auipc	ra,0x2
    8000229c:	ee6080e7          	jalr	-282(ra) # 8000417e <begin_op>
  iput(p->cwd);
    800022a0:	1509b503          	ld	a0,336(s3)
    800022a4:	00001097          	auipc	ra,0x1
    800022a8:	6ca080e7          	jalr	1738(ra) # 8000396e <iput>
  end_op();
    800022ac:	00002097          	auipc	ra,0x2
    800022b0:	f4c080e7          	jalr	-180(ra) # 800041f8 <end_op>
  p->cwd = 0;
    800022b4:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800022b8:	00011497          	auipc	s1,0x11
    800022bc:	1c048493          	addi	s1,s1,448 # 80013478 <wait_lock>
    800022c0:	8526                	mv	a0,s1
    800022c2:	fffff097          	auipc	ra,0xfffff
    800022c6:	976080e7          	jalr	-1674(ra) # 80000c38 <acquire>
  reparent(p);
    800022ca:	854e                	mv	a0,s3
    800022cc:	00000097          	auipc	ra,0x0
    800022d0:	f1a080e7          	jalr	-230(ra) # 800021e6 <reparent>
  wakeup(p->parent);
    800022d4:	0389b503          	ld	a0,56(s3)
    800022d8:	00000097          	auipc	ra,0x0
    800022dc:	e98080e7          	jalr	-360(ra) # 80002170 <wakeup>
  acquire(&p->lock);
    800022e0:	854e                	mv	a0,s3
    800022e2:	fffff097          	auipc	ra,0xfffff
    800022e6:	956080e7          	jalr	-1706(ra) # 80000c38 <acquire>
  p->xstate = status;
    800022ea:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800022ee:	4795                	li	a5,5
    800022f0:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800022f4:	8526                	mv	a0,s1
    800022f6:	fffff097          	auipc	ra,0xfffff
    800022fa:	9f6080e7          	jalr	-1546(ra) # 80000cec <release>
  sched();
    800022fe:	00000097          	auipc	ra,0x0
    80002302:	cfc080e7          	jalr	-772(ra) # 80001ffa <sched>
  panic("zombie exit");
    80002306:	00006517          	auipc	a0,0x6
    8000230a:	f6a50513          	addi	a0,a0,-150 # 80008270 <etext+0x270>
    8000230e:	ffffe097          	auipc	ra,0xffffe
    80002312:	252080e7          	jalr	594(ra) # 80000560 <panic>

0000000080002316 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80002316:	7179                	addi	sp,sp,-48
    80002318:	f406                	sd	ra,40(sp)
    8000231a:	f022                	sd	s0,32(sp)
    8000231c:	ec26                	sd	s1,24(sp)
    8000231e:	e84a                	sd	s2,16(sp)
    80002320:	e44e                	sd	s3,8(sp)
    80002322:	1800                	addi	s0,sp,48
    80002324:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80002326:	00011497          	auipc	s1,0x11
    8000232a:	56a48493          	addi	s1,s1,1386 # 80013890 <proc>
    8000232e:	00017997          	auipc	s3,0x17
    80002332:	f6298993          	addi	s3,s3,-158 # 80019290 <tickslock>
    acquire(&p->lock);
    80002336:	8526                	mv	a0,s1
    80002338:	fffff097          	auipc	ra,0xfffff
    8000233c:	900080e7          	jalr	-1792(ra) # 80000c38 <acquire>
    if(p->pid == pid){
    80002340:	589c                	lw	a5,48(s1)
    80002342:	01278d63          	beq	a5,s2,8000235c <kill+0x46>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002346:	8526                	mv	a0,s1
    80002348:	fffff097          	auipc	ra,0xfffff
    8000234c:	9a4080e7          	jalr	-1628(ra) # 80000cec <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80002350:	16848493          	addi	s1,s1,360
    80002354:	ff3491e3          	bne	s1,s3,80002336 <kill+0x20>
  }
  return -1;
    80002358:	557d                	li	a0,-1
    8000235a:	a829                	j	80002374 <kill+0x5e>
      p->killed = 1;
    8000235c:	4785                	li	a5,1
    8000235e:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80002360:	4c98                	lw	a4,24(s1)
    80002362:	4789                	li	a5,2
    80002364:	00f70f63          	beq	a4,a5,80002382 <kill+0x6c>
      release(&p->lock);
    80002368:	8526                	mv	a0,s1
    8000236a:	fffff097          	auipc	ra,0xfffff
    8000236e:	982080e7          	jalr	-1662(ra) # 80000cec <release>
      return 0;
    80002372:	4501                	li	a0,0
}
    80002374:	70a2                	ld	ra,40(sp)
    80002376:	7402                	ld	s0,32(sp)
    80002378:	64e2                	ld	s1,24(sp)
    8000237a:	6942                	ld	s2,16(sp)
    8000237c:	69a2                	ld	s3,8(sp)
    8000237e:	6145                	addi	sp,sp,48
    80002380:	8082                	ret
        p->state = RUNNABLE;
    80002382:	478d                	li	a5,3
    80002384:	cc9c                	sw	a5,24(s1)
    80002386:	b7cd                	j	80002368 <kill+0x52>

0000000080002388 <setkilled>:

void
setkilled(struct proc *p)
{
    80002388:	1101                	addi	sp,sp,-32
    8000238a:	ec06                	sd	ra,24(sp)
    8000238c:	e822                	sd	s0,16(sp)
    8000238e:	e426                	sd	s1,8(sp)
    80002390:	1000                	addi	s0,sp,32
    80002392:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002394:	fffff097          	auipc	ra,0xfffff
    80002398:	8a4080e7          	jalr	-1884(ra) # 80000c38 <acquire>
  p->killed = 1;
    8000239c:	4785                	li	a5,1
    8000239e:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800023a0:	8526                	mv	a0,s1
    800023a2:	fffff097          	auipc	ra,0xfffff
    800023a6:	94a080e7          	jalr	-1718(ra) # 80000cec <release>
}
    800023aa:	60e2                	ld	ra,24(sp)
    800023ac:	6442                	ld	s0,16(sp)
    800023ae:	64a2                	ld	s1,8(sp)
    800023b0:	6105                	addi	sp,sp,32
    800023b2:	8082                	ret

00000000800023b4 <killed>:

int
killed(struct proc *p)
{
    800023b4:	1101                	addi	sp,sp,-32
    800023b6:	ec06                	sd	ra,24(sp)
    800023b8:	e822                	sd	s0,16(sp)
    800023ba:	e426                	sd	s1,8(sp)
    800023bc:	e04a                	sd	s2,0(sp)
    800023be:	1000                	addi	s0,sp,32
    800023c0:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800023c2:	fffff097          	auipc	ra,0xfffff
    800023c6:	876080e7          	jalr	-1930(ra) # 80000c38 <acquire>
  k = p->killed;
    800023ca:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    800023ce:	8526                	mv	a0,s1
    800023d0:	fffff097          	auipc	ra,0xfffff
    800023d4:	91c080e7          	jalr	-1764(ra) # 80000cec <release>
  return k;
}
    800023d8:	854a                	mv	a0,s2
    800023da:	60e2                	ld	ra,24(sp)
    800023dc:	6442                	ld	s0,16(sp)
    800023de:	64a2                	ld	s1,8(sp)
    800023e0:	6902                	ld	s2,0(sp)
    800023e2:	6105                	addi	sp,sp,32
    800023e4:	8082                	ret

00000000800023e6 <wait>:
{
    800023e6:	715d                	addi	sp,sp,-80
    800023e8:	e486                	sd	ra,72(sp)
    800023ea:	e0a2                	sd	s0,64(sp)
    800023ec:	fc26                	sd	s1,56(sp)
    800023ee:	f84a                	sd	s2,48(sp)
    800023f0:	f44e                	sd	s3,40(sp)
    800023f2:	f052                	sd	s4,32(sp)
    800023f4:	ec56                	sd	s5,24(sp)
    800023f6:	e85a                	sd	s6,16(sp)
    800023f8:	e45e                	sd	s7,8(sp)
    800023fa:	e062                	sd	s8,0(sp)
    800023fc:	0880                	addi	s0,sp,80
    800023fe:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    80002400:	fffff097          	auipc	ra,0xfffff
    80002404:	662080e7          	jalr	1634(ra) # 80001a62 <myproc>
    80002408:	892a                	mv	s2,a0
  acquire(&wait_lock);
    8000240a:	00011517          	auipc	a0,0x11
    8000240e:	06e50513          	addi	a0,a0,110 # 80013478 <wait_lock>
    80002412:	fffff097          	auipc	ra,0xfffff
    80002416:	826080e7          	jalr	-2010(ra) # 80000c38 <acquire>
    havekids = 0;
    8000241a:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    8000241c:	4a15                	li	s4,5
        havekids = 1;
    8000241e:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002420:	00017997          	auipc	s3,0x17
    80002424:	e7098993          	addi	s3,s3,-400 # 80019290 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002428:	00011c17          	auipc	s8,0x11
    8000242c:	050c0c13          	addi	s8,s8,80 # 80013478 <wait_lock>
    80002430:	a0d1                	j	800024f4 <wait+0x10e>
          pid = pp->pid;
    80002432:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80002436:	000b0e63          	beqz	s6,80002452 <wait+0x6c>
    8000243a:	4691                	li	a3,4
    8000243c:	02c48613          	addi	a2,s1,44
    80002440:	85da                	mv	a1,s6
    80002442:	05093503          	ld	a0,80(s2)
    80002446:	fffff097          	auipc	ra,0xfffff
    8000244a:	29c080e7          	jalr	668(ra) # 800016e2 <copyout>
    8000244e:	04054163          	bltz	a0,80002490 <wait+0xaa>
          freeproc(pp);
    80002452:	8526                	mv	a0,s1
    80002454:	fffff097          	auipc	ra,0xfffff
    80002458:	7c0080e7          	jalr	1984(ra) # 80001c14 <freeproc>
          release(&pp->lock);
    8000245c:	8526                	mv	a0,s1
    8000245e:	fffff097          	auipc	ra,0xfffff
    80002462:	88e080e7          	jalr	-1906(ra) # 80000cec <release>
          release(&wait_lock);
    80002466:	00011517          	auipc	a0,0x11
    8000246a:	01250513          	addi	a0,a0,18 # 80013478 <wait_lock>
    8000246e:	fffff097          	auipc	ra,0xfffff
    80002472:	87e080e7          	jalr	-1922(ra) # 80000cec <release>
}
    80002476:	854e                	mv	a0,s3
    80002478:	60a6                	ld	ra,72(sp)
    8000247a:	6406                	ld	s0,64(sp)
    8000247c:	74e2                	ld	s1,56(sp)
    8000247e:	7942                	ld	s2,48(sp)
    80002480:	79a2                	ld	s3,40(sp)
    80002482:	7a02                	ld	s4,32(sp)
    80002484:	6ae2                	ld	s5,24(sp)
    80002486:	6b42                	ld	s6,16(sp)
    80002488:	6ba2                	ld	s7,8(sp)
    8000248a:	6c02                	ld	s8,0(sp)
    8000248c:	6161                	addi	sp,sp,80
    8000248e:	8082                	ret
            release(&pp->lock);
    80002490:	8526                	mv	a0,s1
    80002492:	fffff097          	auipc	ra,0xfffff
    80002496:	85a080e7          	jalr	-1958(ra) # 80000cec <release>
            release(&wait_lock);
    8000249a:	00011517          	auipc	a0,0x11
    8000249e:	fde50513          	addi	a0,a0,-34 # 80013478 <wait_lock>
    800024a2:	fffff097          	auipc	ra,0xfffff
    800024a6:	84a080e7          	jalr	-1974(ra) # 80000cec <release>
            return -1;
    800024aa:	59fd                	li	s3,-1
    800024ac:	b7e9                	j	80002476 <wait+0x90>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800024ae:	16848493          	addi	s1,s1,360
    800024b2:	03348463          	beq	s1,s3,800024da <wait+0xf4>
      if(pp->parent == p){
    800024b6:	7c9c                	ld	a5,56(s1)
    800024b8:	ff279be3          	bne	a5,s2,800024ae <wait+0xc8>
        acquire(&pp->lock);
    800024bc:	8526                	mv	a0,s1
    800024be:	ffffe097          	auipc	ra,0xffffe
    800024c2:	77a080e7          	jalr	1914(ra) # 80000c38 <acquire>
        if(pp->state == ZOMBIE){
    800024c6:	4c9c                	lw	a5,24(s1)
    800024c8:	f74785e3          	beq	a5,s4,80002432 <wait+0x4c>
        release(&pp->lock);
    800024cc:	8526                	mv	a0,s1
    800024ce:	fffff097          	auipc	ra,0xfffff
    800024d2:	81e080e7          	jalr	-2018(ra) # 80000cec <release>
        havekids = 1;
    800024d6:	8756                	mv	a4,s5
    800024d8:	bfd9                	j	800024ae <wait+0xc8>
    if(!havekids || killed(p)){
    800024da:	c31d                	beqz	a4,80002500 <wait+0x11a>
    800024dc:	854a                	mv	a0,s2
    800024de:	00000097          	auipc	ra,0x0
    800024e2:	ed6080e7          	jalr	-298(ra) # 800023b4 <killed>
    800024e6:	ed09                	bnez	a0,80002500 <wait+0x11a>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800024e8:	85e2                	mv	a1,s8
    800024ea:	854a                	mv	a0,s2
    800024ec:	00000097          	auipc	ra,0x0
    800024f0:	c20080e7          	jalr	-992(ra) # 8000210c <sleep>
    havekids = 0;
    800024f4:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800024f6:	00011497          	auipc	s1,0x11
    800024fa:	39a48493          	addi	s1,s1,922 # 80013890 <proc>
    800024fe:	bf65                	j	800024b6 <wait+0xd0>
      release(&wait_lock);
    80002500:	00011517          	auipc	a0,0x11
    80002504:	f7850513          	addi	a0,a0,-136 # 80013478 <wait_lock>
    80002508:	ffffe097          	auipc	ra,0xffffe
    8000250c:	7e4080e7          	jalr	2020(ra) # 80000cec <release>
      return -1;
    80002510:	59fd                	li	s3,-1
    80002512:	b795                	j	80002476 <wait+0x90>

0000000080002514 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002514:	7179                	addi	sp,sp,-48
    80002516:	f406                	sd	ra,40(sp)
    80002518:	f022                	sd	s0,32(sp)
    8000251a:	ec26                	sd	s1,24(sp)
    8000251c:	e84a                	sd	s2,16(sp)
    8000251e:	e44e                	sd	s3,8(sp)
    80002520:	e052                	sd	s4,0(sp)
    80002522:	1800                	addi	s0,sp,48
    80002524:	84aa                	mv	s1,a0
    80002526:	892e                	mv	s2,a1
    80002528:	89b2                	mv	s3,a2
    8000252a:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    8000252c:	fffff097          	auipc	ra,0xfffff
    80002530:	536080e7          	jalr	1334(ra) # 80001a62 <myproc>
  if(user_dst){
    80002534:	c08d                	beqz	s1,80002556 <either_copyout+0x42>
    return copyout(p->pagetable, dst, src, len);
    80002536:	86d2                	mv	a3,s4
    80002538:	864e                	mv	a2,s3
    8000253a:	85ca                	mv	a1,s2
    8000253c:	6928                	ld	a0,80(a0)
    8000253e:	fffff097          	auipc	ra,0xfffff
    80002542:	1a4080e7          	jalr	420(ra) # 800016e2 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002546:	70a2                	ld	ra,40(sp)
    80002548:	7402                	ld	s0,32(sp)
    8000254a:	64e2                	ld	s1,24(sp)
    8000254c:	6942                	ld	s2,16(sp)
    8000254e:	69a2                	ld	s3,8(sp)
    80002550:	6a02                	ld	s4,0(sp)
    80002552:	6145                	addi	sp,sp,48
    80002554:	8082                	ret
    memmove((char *)dst, src, len);
    80002556:	000a061b          	sext.w	a2,s4
    8000255a:	85ce                	mv	a1,s3
    8000255c:	854a                	mv	a0,s2
    8000255e:	fffff097          	auipc	ra,0xfffff
    80002562:	832080e7          	jalr	-1998(ra) # 80000d90 <memmove>
    return 0;
    80002566:	8526                	mv	a0,s1
    80002568:	bff9                	j	80002546 <either_copyout+0x32>

000000008000256a <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    8000256a:	7179                	addi	sp,sp,-48
    8000256c:	f406                	sd	ra,40(sp)
    8000256e:	f022                	sd	s0,32(sp)
    80002570:	ec26                	sd	s1,24(sp)
    80002572:	e84a                	sd	s2,16(sp)
    80002574:	e44e                	sd	s3,8(sp)
    80002576:	e052                	sd	s4,0(sp)
    80002578:	1800                	addi	s0,sp,48
    8000257a:	892a                	mv	s2,a0
    8000257c:	84ae                	mv	s1,a1
    8000257e:	89b2                	mv	s3,a2
    80002580:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002582:	fffff097          	auipc	ra,0xfffff
    80002586:	4e0080e7          	jalr	1248(ra) # 80001a62 <myproc>
  if(user_src){
    8000258a:	c08d                	beqz	s1,800025ac <either_copyin+0x42>
    return copyin(p->pagetable, dst, src, len);
    8000258c:	86d2                	mv	a3,s4
    8000258e:	864e                	mv	a2,s3
    80002590:	85ca                	mv	a1,s2
    80002592:	6928                	ld	a0,80(a0)
    80002594:	fffff097          	auipc	ra,0xfffff
    80002598:	1da080e7          	jalr	474(ra) # 8000176e <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    8000259c:	70a2                	ld	ra,40(sp)
    8000259e:	7402                	ld	s0,32(sp)
    800025a0:	64e2                	ld	s1,24(sp)
    800025a2:	6942                	ld	s2,16(sp)
    800025a4:	69a2                	ld	s3,8(sp)
    800025a6:	6a02                	ld	s4,0(sp)
    800025a8:	6145                	addi	sp,sp,48
    800025aa:	8082                	ret
    memmove(dst, (char*)src, len);
    800025ac:	000a061b          	sext.w	a2,s4
    800025b0:	85ce                	mv	a1,s3
    800025b2:	854a                	mv	a0,s2
    800025b4:	ffffe097          	auipc	ra,0xffffe
    800025b8:	7dc080e7          	jalr	2012(ra) # 80000d90 <memmove>
    return 0;
    800025bc:	8526                	mv	a0,s1
    800025be:	bff9                	j	8000259c <either_copyin+0x32>

00000000800025c0 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800025c0:	715d                	addi	sp,sp,-80
    800025c2:	e486                	sd	ra,72(sp)
    800025c4:	e0a2                	sd	s0,64(sp)
    800025c6:	fc26                	sd	s1,56(sp)
    800025c8:	f84a                	sd	s2,48(sp)
    800025ca:	f44e                	sd	s3,40(sp)
    800025cc:	f052                	sd	s4,32(sp)
    800025ce:	ec56                	sd	s5,24(sp)
    800025d0:	e85a                	sd	s6,16(sp)
    800025d2:	e45e                	sd	s7,8(sp)
    800025d4:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800025d6:	00006517          	auipc	a0,0x6
    800025da:	a4a50513          	addi	a0,a0,-1462 # 80008020 <etext+0x20>
    800025de:	ffffe097          	auipc	ra,0xffffe
    800025e2:	fcc080e7          	jalr	-52(ra) # 800005aa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800025e6:	00011497          	auipc	s1,0x11
    800025ea:	40248493          	addi	s1,s1,1026 # 800139e8 <proc+0x158>
    800025ee:	00017917          	auipc	s2,0x17
    800025f2:	dfa90913          	addi	s2,s2,-518 # 800193e8 <bcache+0xc8>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800025f6:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800025f8:	00006997          	auipc	s3,0x6
    800025fc:	c8898993          	addi	s3,s3,-888 # 80008280 <etext+0x280>
    printf("%d %s %s", p->pid, state, p->name);
    80002600:	00006a97          	auipc	s5,0x6
    80002604:	c88a8a93          	addi	s5,s5,-888 # 80008288 <etext+0x288>
    printf("\n");
    80002608:	00006a17          	auipc	s4,0x6
    8000260c:	a18a0a13          	addi	s4,s4,-1512 # 80008020 <etext+0x20>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002610:	00006b97          	auipc	s7,0x6
    80002614:	150b8b93          	addi	s7,s7,336 # 80008760 <states.0>
    80002618:	a00d                	j	8000263a <procdump+0x7a>
    printf("%d %s %s", p->pid, state, p->name);
    8000261a:	ed86a583          	lw	a1,-296(a3)
    8000261e:	8556                	mv	a0,s5
    80002620:	ffffe097          	auipc	ra,0xffffe
    80002624:	f8a080e7          	jalr	-118(ra) # 800005aa <printf>
    printf("\n");
    80002628:	8552                	mv	a0,s4
    8000262a:	ffffe097          	auipc	ra,0xffffe
    8000262e:	f80080e7          	jalr	-128(ra) # 800005aa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002632:	16848493          	addi	s1,s1,360
    80002636:	03248263          	beq	s1,s2,8000265a <procdump+0x9a>
    if(p->state == UNUSED)
    8000263a:	86a6                	mv	a3,s1
    8000263c:	ec04a783          	lw	a5,-320(s1)
    80002640:	dbed                	beqz	a5,80002632 <procdump+0x72>
      state = "???";
    80002642:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002644:	fcfb6be3          	bltu	s6,a5,8000261a <procdump+0x5a>
    80002648:	02079713          	slli	a4,a5,0x20
    8000264c:	01d75793          	srli	a5,a4,0x1d
    80002650:	97de                	add	a5,a5,s7
    80002652:	6390                	ld	a2,0(a5)
    80002654:	f279                	bnez	a2,8000261a <procdump+0x5a>
      state = "???";
    80002656:	864e                	mv	a2,s3
    80002658:	b7c9                	j	8000261a <procdump+0x5a>
  }
}
    8000265a:	60a6                	ld	ra,72(sp)
    8000265c:	6406                	ld	s0,64(sp)
    8000265e:	74e2                	ld	s1,56(sp)
    80002660:	7942                	ld	s2,48(sp)
    80002662:	79a2                	ld	s3,40(sp)
    80002664:	7a02                	ld	s4,32(sp)
    80002666:	6ae2                	ld	s5,24(sp)
    80002668:	6b42                	ld	s6,16(sp)
    8000266a:	6ba2                	ld	s7,8(sp)
    8000266c:	6161                	addi	sp,sp,80
    8000266e:	8082                	ret

0000000080002670 <swtch>:
    80002670:	00153023          	sd	ra,0(a0)
    80002674:	00253423          	sd	sp,8(a0)
    80002678:	e900                	sd	s0,16(a0)
    8000267a:	ed04                	sd	s1,24(a0)
    8000267c:	03253023          	sd	s2,32(a0)
    80002680:	03353423          	sd	s3,40(a0)
    80002684:	03453823          	sd	s4,48(a0)
    80002688:	03553c23          	sd	s5,56(a0)
    8000268c:	05653023          	sd	s6,64(a0)
    80002690:	05753423          	sd	s7,72(a0)
    80002694:	05853823          	sd	s8,80(a0)
    80002698:	05953c23          	sd	s9,88(a0)
    8000269c:	07a53023          	sd	s10,96(a0)
    800026a0:	07b53423          	sd	s11,104(a0)
    800026a4:	0005b083          	ld	ra,0(a1)
    800026a8:	0085b103          	ld	sp,8(a1)
    800026ac:	6980                	ld	s0,16(a1)
    800026ae:	6d84                	ld	s1,24(a1)
    800026b0:	0205b903          	ld	s2,32(a1)
    800026b4:	0285b983          	ld	s3,40(a1)
    800026b8:	0305ba03          	ld	s4,48(a1)
    800026bc:	0385ba83          	ld	s5,56(a1)
    800026c0:	0405bb03          	ld	s6,64(a1)
    800026c4:	0485bb83          	ld	s7,72(a1)
    800026c8:	0505bc03          	ld	s8,80(a1)
    800026cc:	0585bc83          	ld	s9,88(a1)
    800026d0:	0605bd03          	ld	s10,96(a1)
    800026d4:	0685bd83          	ld	s11,104(a1)
    800026d8:	8082                	ret

00000000800026da <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800026da:	1141                	addi	sp,sp,-16
    800026dc:	e406                	sd	ra,8(sp)
    800026de:	e022                	sd	s0,0(sp)
    800026e0:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800026e2:	00006597          	auipc	a1,0x6
    800026e6:	be658593          	addi	a1,a1,-1050 # 800082c8 <etext+0x2c8>
    800026ea:	00017517          	auipc	a0,0x17
    800026ee:	ba650513          	addi	a0,a0,-1114 # 80019290 <tickslock>
    800026f2:	ffffe097          	auipc	ra,0xffffe
    800026f6:	4b6080e7          	jalr	1206(ra) # 80000ba8 <initlock>
}
    800026fa:	60a2                	ld	ra,8(sp)
    800026fc:	6402                	ld	s0,0(sp)
    800026fe:	0141                	addi	sp,sp,16
    80002700:	8082                	ret

0000000080002702 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002702:	1141                	addi	sp,sp,-16
    80002704:	e422                	sd	s0,8(sp)
    80002706:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002708:	00003797          	auipc	a5,0x3
    8000270c:	64878793          	addi	a5,a5,1608 # 80005d50 <kernelvec>
    80002710:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002714:	6422                	ld	s0,8(sp)
    80002716:	0141                	addi	sp,sp,16
    80002718:	8082                	ret

000000008000271a <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    8000271a:	1141                	addi	sp,sp,-16
    8000271c:	e406                	sd	ra,8(sp)
    8000271e:	e022                	sd	s0,0(sp)
    80002720:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002722:	fffff097          	auipc	ra,0xfffff
    80002726:	340080e7          	jalr	832(ra) # 80001a62 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000272a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000272e:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002730:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002734:	00005697          	auipc	a3,0x5
    80002738:	8cc68693          	addi	a3,a3,-1844 # 80007000 <_trampoline>
    8000273c:	00005717          	auipc	a4,0x5
    80002740:	8c470713          	addi	a4,a4,-1852 # 80007000 <_trampoline>
    80002744:	8f15                	sub	a4,a4,a3
    80002746:	040007b7          	lui	a5,0x4000
    8000274a:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    8000274c:	07b2                	slli	a5,a5,0xc
    8000274e:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002750:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002754:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80002756:	18002673          	csrr	a2,satp
    8000275a:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000275c:	6d30                	ld	a2,88(a0)
    8000275e:	6138                	ld	a4,64(a0)
    80002760:	6585                	lui	a1,0x1
    80002762:	972e                	add	a4,a4,a1
    80002764:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002766:	6d38                	ld	a4,88(a0)
    80002768:	00000617          	auipc	a2,0x0
    8000276c:	13860613          	addi	a2,a2,312 # 800028a0 <usertrap>
    80002770:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80002772:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80002774:	8612                	mv	a2,tp
    80002776:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002778:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000277c:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002780:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002784:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002788:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000278a:	6f18                	ld	a4,24(a4)
    8000278c:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80002790:	6928                	ld	a0,80(a0)
    80002792:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80002794:	00005717          	auipc	a4,0x5
    80002798:	90870713          	addi	a4,a4,-1784 # 8000709c <userret>
    8000279c:	8f15                	sub	a4,a4,a3
    8000279e:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800027a0:	577d                	li	a4,-1
    800027a2:	177e                	slli	a4,a4,0x3f
    800027a4:	8d59                	or	a0,a0,a4
    800027a6:	9782                	jalr	a5
}
    800027a8:	60a2                	ld	ra,8(sp)
    800027aa:	6402                	ld	s0,0(sp)
    800027ac:	0141                	addi	sp,sp,16
    800027ae:	8082                	ret

00000000800027b0 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800027b0:	1101                	addi	sp,sp,-32
    800027b2:	ec06                	sd	ra,24(sp)
    800027b4:	e822                	sd	s0,16(sp)
    800027b6:	e426                	sd	s1,8(sp)
    800027b8:	1000                	addi	s0,sp,32
  acquire(&tickslock);
    800027ba:	00017497          	auipc	s1,0x17
    800027be:	ad648493          	addi	s1,s1,-1322 # 80019290 <tickslock>
    800027c2:	8526                	mv	a0,s1
    800027c4:	ffffe097          	auipc	ra,0xffffe
    800027c8:	474080e7          	jalr	1140(ra) # 80000c38 <acquire>
  ticks++;
    800027cc:	00009517          	auipc	a0,0x9
    800027d0:	a2450513          	addi	a0,a0,-1500 # 8000b1f0 <ticks>
    800027d4:	411c                	lw	a5,0(a0)
    800027d6:	2785                	addiw	a5,a5,1
    800027d8:	c11c                	sw	a5,0(a0)
  wakeup(&ticks);
    800027da:	00000097          	auipc	ra,0x0
    800027de:	996080e7          	jalr	-1642(ra) # 80002170 <wakeup>
  release(&tickslock);
    800027e2:	8526                	mv	a0,s1
    800027e4:	ffffe097          	auipc	ra,0xffffe
    800027e8:	508080e7          	jalr	1288(ra) # 80000cec <release>
}
    800027ec:	60e2                	ld	ra,24(sp)
    800027ee:	6442                	ld	s0,16(sp)
    800027f0:	64a2                	ld	s1,8(sp)
    800027f2:	6105                	addi	sp,sp,32
    800027f4:	8082                	ret

00000000800027f6 <devintr>:
  asm volatile("csrr %0, scause" : "=r" (x) );
    800027f6:	142027f3          	csrr	a5,scause
    // the SSIP bit in sip.
    w_sip(r_sip() & ~2);

    return 2;
  } else {
    return 0;
    800027fa:	4501                	li	a0,0
  if((scause & 0x8000000000000000L) &&
    800027fc:	0a07d163          	bgez	a5,8000289e <devintr+0xa8>
{
    80002800:	1101                	addi	sp,sp,-32
    80002802:	ec06                	sd	ra,24(sp)
    80002804:	e822                	sd	s0,16(sp)
    80002806:	1000                	addi	s0,sp,32
     (scause & 0xff) == 9){
    80002808:	0ff7f713          	zext.b	a4,a5
  if((scause & 0x8000000000000000L) &&
    8000280c:	46a5                	li	a3,9
    8000280e:	00d70c63          	beq	a4,a3,80002826 <devintr+0x30>
  } else if(scause == 0x8000000000000001L){
    80002812:	577d                	li	a4,-1
    80002814:	177e                	slli	a4,a4,0x3f
    80002816:	0705                	addi	a4,a4,1
    return 0;
    80002818:	4501                	li	a0,0
  } else if(scause == 0x8000000000000001L){
    8000281a:	06e78163          	beq	a5,a4,8000287c <devintr+0x86>
  }
}
    8000281e:	60e2                	ld	ra,24(sp)
    80002820:	6442                	ld	s0,16(sp)
    80002822:	6105                	addi	sp,sp,32
    80002824:	8082                	ret
    80002826:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80002828:	00003097          	auipc	ra,0x3
    8000282c:	634080e7          	jalr	1588(ra) # 80005e5c <plic_claim>
    80002830:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002832:	47a9                	li	a5,10
    80002834:	00f50963          	beq	a0,a5,80002846 <devintr+0x50>
    } else if(irq == VIRTIO0_IRQ){
    80002838:	4785                	li	a5,1
    8000283a:	00f50b63          	beq	a0,a5,80002850 <devintr+0x5a>
    return 1;
    8000283e:	4505                	li	a0,1
    } else if(irq){
    80002840:	ec89                	bnez	s1,8000285a <devintr+0x64>
    80002842:	64a2                	ld	s1,8(sp)
    80002844:	bfe9                	j	8000281e <devintr+0x28>
      uartintr();
    80002846:	ffffe097          	auipc	ra,0xffffe
    8000284a:	1b4080e7          	jalr	436(ra) # 800009fa <uartintr>
    if(irq)
    8000284e:	a839                	j	8000286c <devintr+0x76>
      virtio_disk_intr();
    80002850:	00004097          	auipc	ra,0x4
    80002854:	b36080e7          	jalr	-1226(ra) # 80006386 <virtio_disk_intr>
    if(irq)
    80002858:	a811                	j	8000286c <devintr+0x76>
      printf("unexpected interrupt irq=%d\n", irq);
    8000285a:	85a6                	mv	a1,s1
    8000285c:	00006517          	auipc	a0,0x6
    80002860:	a7450513          	addi	a0,a0,-1420 # 800082d0 <etext+0x2d0>
    80002864:	ffffe097          	auipc	ra,0xffffe
    80002868:	d46080e7          	jalr	-698(ra) # 800005aa <printf>
      plic_complete(irq);
    8000286c:	8526                	mv	a0,s1
    8000286e:	00003097          	auipc	ra,0x3
    80002872:	612080e7          	jalr	1554(ra) # 80005e80 <plic_complete>
    return 1;
    80002876:	4505                	li	a0,1
    80002878:	64a2                	ld	s1,8(sp)
    8000287a:	b755                	j	8000281e <devintr+0x28>
    if(cpuid() == 0){
    8000287c:	fffff097          	auipc	ra,0xfffff
    80002880:	1ba080e7          	jalr	442(ra) # 80001a36 <cpuid>
    80002884:	c901                	beqz	a0,80002894 <devintr+0x9e>
  asm volatile("csrr %0, sip" : "=r" (x) );
    80002886:	144027f3          	csrr	a5,sip
    w_sip(r_sip() & ~2);
    8000288a:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sip, %0" : : "r" (x));
    8000288c:	14479073          	csrw	sip,a5
    return 2;
    80002890:	4509                	li	a0,2
    80002892:	b771                	j	8000281e <devintr+0x28>
      clockintr();
    80002894:	00000097          	auipc	ra,0x0
    80002898:	f1c080e7          	jalr	-228(ra) # 800027b0 <clockintr>
    8000289c:	b7ed                	j	80002886 <devintr+0x90>
}
    8000289e:	8082                	ret

00000000800028a0 <usertrap>:
{
    800028a0:	1101                	addi	sp,sp,-32
    800028a2:	ec06                	sd	ra,24(sp)
    800028a4:	e822                	sd	s0,16(sp)
    800028a6:	e426                	sd	s1,8(sp)
    800028a8:	e04a                	sd	s2,0(sp)
    800028aa:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800028ac:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    800028b0:	1007f793          	andi	a5,a5,256
    800028b4:	e3b1                	bnez	a5,800028f8 <usertrap+0x58>
  asm volatile("csrw stvec, %0" : : "r" (x));
    800028b6:	00003797          	auipc	a5,0x3
    800028ba:	49a78793          	addi	a5,a5,1178 # 80005d50 <kernelvec>
    800028be:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800028c2:	fffff097          	auipc	ra,0xfffff
    800028c6:	1a0080e7          	jalr	416(ra) # 80001a62 <myproc>
    800028ca:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800028cc:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800028ce:	14102773          	csrr	a4,sepc
    800028d2:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    800028d4:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800028d8:	47a1                	li	a5,8
    800028da:	02f70763          	beq	a4,a5,80002908 <usertrap+0x68>
  } else if((which_dev = devintr()) != 0){
    800028de:	00000097          	auipc	ra,0x0
    800028e2:	f18080e7          	jalr	-232(ra) # 800027f6 <devintr>
    800028e6:	892a                	mv	s2,a0
    800028e8:	c151                	beqz	a0,8000296c <usertrap+0xcc>
  if(killed(p))
    800028ea:	8526                	mv	a0,s1
    800028ec:	00000097          	auipc	ra,0x0
    800028f0:	ac8080e7          	jalr	-1336(ra) # 800023b4 <killed>
    800028f4:	c929                	beqz	a0,80002946 <usertrap+0xa6>
    800028f6:	a099                	j	8000293c <usertrap+0x9c>
    panic("usertrap: not from user mode");
    800028f8:	00006517          	auipc	a0,0x6
    800028fc:	9f850513          	addi	a0,a0,-1544 # 800082f0 <etext+0x2f0>
    80002900:	ffffe097          	auipc	ra,0xffffe
    80002904:	c60080e7          	jalr	-928(ra) # 80000560 <panic>
    if(killed(p))
    80002908:	00000097          	auipc	ra,0x0
    8000290c:	aac080e7          	jalr	-1364(ra) # 800023b4 <killed>
    80002910:	e921                	bnez	a0,80002960 <usertrap+0xc0>
    p->trapframe->epc += 4;
    80002912:	6cb8                	ld	a4,88(s1)
    80002914:	6f1c                	ld	a5,24(a4)
    80002916:	0791                	addi	a5,a5,4
    80002918:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000291a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000291e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002922:	10079073          	csrw	sstatus,a5
    syscall();
    80002926:	00000097          	auipc	ra,0x0
    8000292a:	2d4080e7          	jalr	724(ra) # 80002bfa <syscall>
  if(killed(p))
    8000292e:	8526                	mv	a0,s1
    80002930:	00000097          	auipc	ra,0x0
    80002934:	a84080e7          	jalr	-1404(ra) # 800023b4 <killed>
    80002938:	c911                	beqz	a0,8000294c <usertrap+0xac>
    8000293a:	4901                	li	s2,0
    exit(-1);
    8000293c:	557d                	li	a0,-1
    8000293e:	00000097          	auipc	ra,0x0
    80002942:	902080e7          	jalr	-1790(ra) # 80002240 <exit>
  if(which_dev == 2)
    80002946:	4789                	li	a5,2
    80002948:	04f90f63          	beq	s2,a5,800029a6 <usertrap+0x106>
  usertrapret();
    8000294c:	00000097          	auipc	ra,0x0
    80002950:	dce080e7          	jalr	-562(ra) # 8000271a <usertrapret>
}
    80002954:	60e2                	ld	ra,24(sp)
    80002956:	6442                	ld	s0,16(sp)
    80002958:	64a2                	ld	s1,8(sp)
    8000295a:	6902                	ld	s2,0(sp)
    8000295c:	6105                	addi	sp,sp,32
    8000295e:	8082                	ret
      exit(-1);
    80002960:	557d                	li	a0,-1
    80002962:	00000097          	auipc	ra,0x0
    80002966:	8de080e7          	jalr	-1826(ra) # 80002240 <exit>
    8000296a:	b765                	j	80002912 <usertrap+0x72>
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000296c:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause %p pid=%d\n", r_scause(), p->pid);
    80002970:	5890                	lw	a2,48(s1)
    80002972:	00006517          	auipc	a0,0x6
    80002976:	99e50513          	addi	a0,a0,-1634 # 80008310 <etext+0x310>
    8000297a:	ffffe097          	auipc	ra,0xffffe
    8000297e:	c30080e7          	jalr	-976(ra) # 800005aa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002982:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002986:	14302673          	csrr	a2,stval
    printf("            sepc=%p stval=%p\n", r_sepc(), r_stval());
    8000298a:	00006517          	auipc	a0,0x6
    8000298e:	9b650513          	addi	a0,a0,-1610 # 80008340 <etext+0x340>
    80002992:	ffffe097          	auipc	ra,0xffffe
    80002996:	c18080e7          	jalr	-1000(ra) # 800005aa <printf>
    setkilled(p);
    8000299a:	8526                	mv	a0,s1
    8000299c:	00000097          	auipc	ra,0x0
    800029a0:	9ec080e7          	jalr	-1556(ra) # 80002388 <setkilled>
    800029a4:	b769                	j	8000292e <usertrap+0x8e>
    yield();
    800029a6:	fffff097          	auipc	ra,0xfffff
    800029aa:	72a080e7          	jalr	1834(ra) # 800020d0 <yield>
    800029ae:	bf79                	j	8000294c <usertrap+0xac>

00000000800029b0 <kerneltrap>:
{
    800029b0:	7179                	addi	sp,sp,-48
    800029b2:	f406                	sd	ra,40(sp)
    800029b4:	f022                	sd	s0,32(sp)
    800029b6:	ec26                	sd	s1,24(sp)
    800029b8:	e84a                	sd	s2,16(sp)
    800029ba:	e44e                	sd	s3,8(sp)
    800029bc:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800029be:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800029c2:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    800029c6:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    800029ca:	1004f793          	andi	a5,s1,256
    800029ce:	cb85                	beqz	a5,800029fe <kerneltrap+0x4e>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800029d0:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800029d4:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    800029d6:	ef85                	bnez	a5,80002a0e <kerneltrap+0x5e>
  if((which_dev = devintr()) == 0){
    800029d8:	00000097          	auipc	ra,0x0
    800029dc:	e1e080e7          	jalr	-482(ra) # 800027f6 <devintr>
    800029e0:	cd1d                	beqz	a0,80002a1e <kerneltrap+0x6e>
  if(which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING)
    800029e2:	4789                	li	a5,2
    800029e4:	06f50a63          	beq	a0,a5,80002a58 <kerneltrap+0xa8>
  asm volatile("csrw sepc, %0" : : "r" (x));
    800029e8:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800029ec:	10049073          	csrw	sstatus,s1
}
    800029f0:	70a2                	ld	ra,40(sp)
    800029f2:	7402                	ld	s0,32(sp)
    800029f4:	64e2                	ld	s1,24(sp)
    800029f6:	6942                	ld	s2,16(sp)
    800029f8:	69a2                	ld	s3,8(sp)
    800029fa:	6145                	addi	sp,sp,48
    800029fc:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800029fe:	00006517          	auipc	a0,0x6
    80002a02:	96250513          	addi	a0,a0,-1694 # 80008360 <etext+0x360>
    80002a06:	ffffe097          	auipc	ra,0xffffe
    80002a0a:	b5a080e7          	jalr	-1190(ra) # 80000560 <panic>
    panic("kerneltrap: interrupts enabled");
    80002a0e:	00006517          	auipc	a0,0x6
    80002a12:	97a50513          	addi	a0,a0,-1670 # 80008388 <etext+0x388>
    80002a16:	ffffe097          	auipc	ra,0xffffe
    80002a1a:	b4a080e7          	jalr	-1206(ra) # 80000560 <panic>
    printf("scause %p\n", scause);
    80002a1e:	85ce                	mv	a1,s3
    80002a20:	00006517          	auipc	a0,0x6
    80002a24:	98850513          	addi	a0,a0,-1656 # 800083a8 <etext+0x3a8>
    80002a28:	ffffe097          	auipc	ra,0xffffe
    80002a2c:	b82080e7          	jalr	-1150(ra) # 800005aa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002a30:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002a34:	14302673          	csrr	a2,stval
    printf("sepc=%p stval=%p\n", r_sepc(), r_stval());
    80002a38:	00006517          	auipc	a0,0x6
    80002a3c:	98050513          	addi	a0,a0,-1664 # 800083b8 <etext+0x3b8>
    80002a40:	ffffe097          	auipc	ra,0xffffe
    80002a44:	b6a080e7          	jalr	-1174(ra) # 800005aa <printf>
    panic("kerneltrap");
    80002a48:	00006517          	auipc	a0,0x6
    80002a4c:	98850513          	addi	a0,a0,-1656 # 800083d0 <etext+0x3d0>
    80002a50:	ffffe097          	auipc	ra,0xffffe
    80002a54:	b10080e7          	jalr	-1264(ra) # 80000560 <panic>
  if(which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING)
    80002a58:	fffff097          	auipc	ra,0xfffff
    80002a5c:	00a080e7          	jalr	10(ra) # 80001a62 <myproc>
    80002a60:	d541                	beqz	a0,800029e8 <kerneltrap+0x38>
    80002a62:	fffff097          	auipc	ra,0xfffff
    80002a66:	000080e7          	jalr	ra # 80001a62 <myproc>
    80002a6a:	4d18                	lw	a4,24(a0)
    80002a6c:	4791                	li	a5,4
    80002a6e:	f6f71de3          	bne	a4,a5,800029e8 <kerneltrap+0x38>
    yield();
    80002a72:	fffff097          	auipc	ra,0xfffff
    80002a76:	65e080e7          	jalr	1630(ra) # 800020d0 <yield>
    80002a7a:	b7bd                	j	800029e8 <kerneltrap+0x38>

0000000080002a7c <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002a7c:	1101                	addi	sp,sp,-32
    80002a7e:	ec06                	sd	ra,24(sp)
    80002a80:	e822                	sd	s0,16(sp)
    80002a82:	e426                	sd	s1,8(sp)
    80002a84:	1000                	addi	s0,sp,32
    80002a86:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002a88:	fffff097          	auipc	ra,0xfffff
    80002a8c:	fda080e7          	jalr	-38(ra) # 80001a62 <myproc>
  switch (n) {
    80002a90:	4795                	li	a5,5
    80002a92:	0497e163          	bltu	a5,s1,80002ad4 <argraw+0x58>
    80002a96:	048a                	slli	s1,s1,0x2
    80002a98:	00006717          	auipc	a4,0x6
    80002a9c:	cf870713          	addi	a4,a4,-776 # 80008790 <states.0+0x30>
    80002aa0:	94ba                	add	s1,s1,a4
    80002aa2:	409c                	lw	a5,0(s1)
    80002aa4:	97ba                	add	a5,a5,a4
    80002aa6:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002aa8:	6d3c                	ld	a5,88(a0)
    80002aaa:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002aac:	60e2                	ld	ra,24(sp)
    80002aae:	6442                	ld	s0,16(sp)
    80002ab0:	64a2                	ld	s1,8(sp)
    80002ab2:	6105                	addi	sp,sp,32
    80002ab4:	8082                	ret
    return p->trapframe->a1;
    80002ab6:	6d3c                	ld	a5,88(a0)
    80002ab8:	7fa8                	ld	a0,120(a5)
    80002aba:	bfcd                	j	80002aac <argraw+0x30>
    return p->trapframe->a2;
    80002abc:	6d3c                	ld	a5,88(a0)
    80002abe:	63c8                	ld	a0,128(a5)
    80002ac0:	b7f5                	j	80002aac <argraw+0x30>
    return p->trapframe->a3;
    80002ac2:	6d3c                	ld	a5,88(a0)
    80002ac4:	67c8                	ld	a0,136(a5)
    80002ac6:	b7dd                	j	80002aac <argraw+0x30>
    return p->trapframe->a4;
    80002ac8:	6d3c                	ld	a5,88(a0)
    80002aca:	6bc8                	ld	a0,144(a5)
    80002acc:	b7c5                	j	80002aac <argraw+0x30>
    return p->trapframe->a5;
    80002ace:	6d3c                	ld	a5,88(a0)
    80002ad0:	6fc8                	ld	a0,152(a5)
    80002ad2:	bfe9                	j	80002aac <argraw+0x30>
  panic("argraw");
    80002ad4:	00006517          	auipc	a0,0x6
    80002ad8:	90c50513          	addi	a0,a0,-1780 # 800083e0 <etext+0x3e0>
    80002adc:	ffffe097          	auipc	ra,0xffffe
    80002ae0:	a84080e7          	jalr	-1404(ra) # 80000560 <panic>

0000000080002ae4 <fetchaddr>:
{
    80002ae4:	1101                	addi	sp,sp,-32
    80002ae6:	ec06                	sd	ra,24(sp)
    80002ae8:	e822                	sd	s0,16(sp)
    80002aea:	e426                	sd	s1,8(sp)
    80002aec:	e04a                	sd	s2,0(sp)
    80002aee:	1000                	addi	s0,sp,32
    80002af0:	84aa                	mv	s1,a0
    80002af2:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002af4:	fffff097          	auipc	ra,0xfffff
    80002af8:	f6e080e7          	jalr	-146(ra) # 80001a62 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002afc:	653c                	ld	a5,72(a0)
    80002afe:	02f4f863          	bgeu	s1,a5,80002b2e <fetchaddr+0x4a>
    80002b02:	00848713          	addi	a4,s1,8
    80002b06:	02e7e663          	bltu	a5,a4,80002b32 <fetchaddr+0x4e>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002b0a:	46a1                	li	a3,8
    80002b0c:	8626                	mv	a2,s1
    80002b0e:	85ca                	mv	a1,s2
    80002b10:	6928                	ld	a0,80(a0)
    80002b12:	fffff097          	auipc	ra,0xfffff
    80002b16:	c5c080e7          	jalr	-932(ra) # 8000176e <copyin>
    80002b1a:	00a03533          	snez	a0,a0
    80002b1e:	40a00533          	neg	a0,a0
}
    80002b22:	60e2                	ld	ra,24(sp)
    80002b24:	6442                	ld	s0,16(sp)
    80002b26:	64a2                	ld	s1,8(sp)
    80002b28:	6902                	ld	s2,0(sp)
    80002b2a:	6105                	addi	sp,sp,32
    80002b2c:	8082                	ret
    return -1;
    80002b2e:	557d                	li	a0,-1
    80002b30:	bfcd                	j	80002b22 <fetchaddr+0x3e>
    80002b32:	557d                	li	a0,-1
    80002b34:	b7fd                	j	80002b22 <fetchaddr+0x3e>

0000000080002b36 <fetchstr>:
{
    80002b36:	7179                	addi	sp,sp,-48
    80002b38:	f406                	sd	ra,40(sp)
    80002b3a:	f022                	sd	s0,32(sp)
    80002b3c:	ec26                	sd	s1,24(sp)
    80002b3e:	e84a                	sd	s2,16(sp)
    80002b40:	e44e                	sd	s3,8(sp)
    80002b42:	1800                	addi	s0,sp,48
    80002b44:	892a                	mv	s2,a0
    80002b46:	84ae                	mv	s1,a1
    80002b48:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80002b4a:	fffff097          	auipc	ra,0xfffff
    80002b4e:	f18080e7          	jalr	-232(ra) # 80001a62 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002b52:	86ce                	mv	a3,s3
    80002b54:	864a                	mv	a2,s2
    80002b56:	85a6                	mv	a1,s1
    80002b58:	6928                	ld	a0,80(a0)
    80002b5a:	fffff097          	auipc	ra,0xfffff
    80002b5e:	ca2080e7          	jalr	-862(ra) # 800017fc <copyinstr>
    80002b62:	00054e63          	bltz	a0,80002b7e <fetchstr+0x48>
  return strlen(buf);
    80002b66:	8526                	mv	a0,s1
    80002b68:	ffffe097          	auipc	ra,0xffffe
    80002b6c:	340080e7          	jalr	832(ra) # 80000ea8 <strlen>
}
    80002b70:	70a2                	ld	ra,40(sp)
    80002b72:	7402                	ld	s0,32(sp)
    80002b74:	64e2                	ld	s1,24(sp)
    80002b76:	6942                	ld	s2,16(sp)
    80002b78:	69a2                	ld	s3,8(sp)
    80002b7a:	6145                	addi	sp,sp,48
    80002b7c:	8082                	ret
    return -1;
    80002b7e:	557d                	li	a0,-1
    80002b80:	bfc5                	j	80002b70 <fetchstr+0x3a>

0000000080002b82 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002b82:	1101                	addi	sp,sp,-32
    80002b84:	ec06                	sd	ra,24(sp)
    80002b86:	e822                	sd	s0,16(sp)
    80002b88:	e426                	sd	s1,8(sp)
    80002b8a:	1000                	addi	s0,sp,32
    80002b8c:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002b8e:	00000097          	auipc	ra,0x0
    80002b92:	eee080e7          	jalr	-274(ra) # 80002a7c <argraw>
    80002b96:	c088                	sw	a0,0(s1)
}
    80002b98:	60e2                	ld	ra,24(sp)
    80002b9a:	6442                	ld	s0,16(sp)
    80002b9c:	64a2                	ld	s1,8(sp)
    80002b9e:	6105                	addi	sp,sp,32
    80002ba0:	8082                	ret

0000000080002ba2 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002ba2:	1101                	addi	sp,sp,-32
    80002ba4:	ec06                	sd	ra,24(sp)
    80002ba6:	e822                	sd	s0,16(sp)
    80002ba8:	e426                	sd	s1,8(sp)
    80002baa:	1000                	addi	s0,sp,32
    80002bac:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002bae:	00000097          	auipc	ra,0x0
    80002bb2:	ece080e7          	jalr	-306(ra) # 80002a7c <argraw>
    80002bb6:	e088                	sd	a0,0(s1)
}
    80002bb8:	60e2                	ld	ra,24(sp)
    80002bba:	6442                	ld	s0,16(sp)
    80002bbc:	64a2                	ld	s1,8(sp)
    80002bbe:	6105                	addi	sp,sp,32
    80002bc0:	8082                	ret

0000000080002bc2 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002bc2:	7179                	addi	sp,sp,-48
    80002bc4:	f406                	sd	ra,40(sp)
    80002bc6:	f022                	sd	s0,32(sp)
    80002bc8:	ec26                	sd	s1,24(sp)
    80002bca:	e84a                	sd	s2,16(sp)
    80002bcc:	1800                	addi	s0,sp,48
    80002bce:	84ae                	mv	s1,a1
    80002bd0:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002bd2:	fd840593          	addi	a1,s0,-40
    80002bd6:	00000097          	auipc	ra,0x0
    80002bda:	fcc080e7          	jalr	-52(ra) # 80002ba2 <argaddr>
  return fetchstr(addr, buf, max);
    80002bde:	864a                	mv	a2,s2
    80002be0:	85a6                	mv	a1,s1
    80002be2:	fd843503          	ld	a0,-40(s0)
    80002be6:	00000097          	auipc	ra,0x0
    80002bea:	f50080e7          	jalr	-176(ra) # 80002b36 <fetchstr>
}
    80002bee:	70a2                	ld	ra,40(sp)
    80002bf0:	7402                	ld	s0,32(sp)
    80002bf2:	64e2                	ld	s1,24(sp)
    80002bf4:	6942                	ld	s2,16(sp)
    80002bf6:	6145                	addi	sp,sp,48
    80002bf8:	8082                	ret

0000000080002bfa <syscall>:
// Lock to correctly count concurrent syscalls
struct spinlock count_lock;

void
syscall(void)
{
    80002bfa:	7179                	addi	sp,sp,-48
    80002bfc:	f406                	sd	ra,40(sp)
    80002bfe:	f022                	sd	s0,32(sp)
    80002c00:	ec26                	sd	s1,24(sp)
    80002c02:	e84a                	sd	s2,16(sp)
    80002c04:	1800                	addi	s0,sp,48
  int num;
  struct proc *p = myproc();
    80002c06:	fffff097          	auipc	ra,0xfffff
    80002c0a:	e5c080e7          	jalr	-420(ra) # 80001a62 <myproc>
    80002c0e:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002c10:	6d3c                	ld	a5,88(a0)
    80002c12:	77dc                	ld	a5,168(a5)
    80002c14:	0007891b          	sext.w	s2,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002c18:	37fd                	addiw	a5,a5,-1
    80002c1a:	4755                	li	a4,21
    80002c1c:	04f76b63          	bltu	a4,a5,80002c72 <syscall+0x78>
    80002c20:	e44e                	sd	s3,8(sp)
    80002c22:	00391713          	slli	a4,s2,0x3
    80002c26:	00006797          	auipc	a5,0x6
    80002c2a:	b8278793          	addi	a5,a5,-1150 # 800087a8 <syscalls>
    80002c2e:	97ba                	add	a5,a5,a4
    80002c30:	0007b983          	ld	s3,0(a5)
    80002c34:	02098e63          	beqz	s3,80002c70 <syscall+0x76>
    80002c38:	e052                	sd	s4,0(sp)
    // Count syscall
    acquire(&count_lock);
    80002c3a:	00016a17          	auipc	s4,0x16
    80002c3e:	66ea0a13          	addi	s4,s4,1646 # 800192a8 <count_lock>
    80002c42:	8552                	mv	a0,s4
    80002c44:	ffffe097          	auipc	ra,0xffffe
    80002c48:	ff4080e7          	jalr	-12(ra) # 80000c38 <acquire>
    syscall_count[num]++;
    80002c4c:	090a                	slli	s2,s2,0x2
    80002c4e:	9952                	add	s2,s2,s4
    80002c50:	01892783          	lw	a5,24(s2)
    80002c54:	2785                	addiw	a5,a5,1
    80002c56:	00f92c23          	sw	a5,24(s2)
    release(&count_lock);
    80002c5a:	8552                	mv	a0,s4
    80002c5c:	ffffe097          	auipc	ra,0xffffe
    80002c60:	090080e7          	jalr	144(ra) # 80000cec <release>

    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002c64:	6ca4                	ld	s1,88(s1)
    80002c66:	9982                	jalr	s3
    80002c68:	f8a8                	sd	a0,112(s1)
    80002c6a:	69a2                	ld	s3,8(sp)
    80002c6c:	6a02                	ld	s4,0(sp)
    80002c6e:	a00d                	j	80002c90 <syscall+0x96>
    80002c70:	69a2                	ld	s3,8(sp)
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002c72:	86ca                	mv	a3,s2
    80002c74:	15848613          	addi	a2,s1,344
    80002c78:	588c                	lw	a1,48(s1)
    80002c7a:	00005517          	auipc	a0,0x5
    80002c7e:	76e50513          	addi	a0,a0,1902 # 800083e8 <etext+0x3e8>
    80002c82:	ffffe097          	auipc	ra,0xffffe
    80002c86:	928080e7          	jalr	-1752(ra) # 800005aa <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002c8a:	6cbc                	ld	a5,88(s1)
    80002c8c:	577d                	li	a4,-1
    80002c8e:	fbb8                	sd	a4,112(a5)
  }
}
    80002c90:	70a2                	ld	ra,40(sp)
    80002c92:	7402                	ld	s0,32(sp)
    80002c94:	64e2                	ld	s1,24(sp)
    80002c96:	6942                	ld	s2,16(sp)
    80002c98:	6145                	addi	sp,sp,48
    80002c9a:	8082                	ret

0000000080002c9c <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80002c9c:	1101                	addi	sp,sp,-32
    80002c9e:	ec06                	sd	ra,24(sp)
    80002ca0:	e822                	sd	s0,16(sp)
    80002ca2:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002ca4:	fec40593          	addi	a1,s0,-20
    80002ca8:	4501                	li	a0,0
    80002caa:	00000097          	auipc	ra,0x0
    80002cae:	ed8080e7          	jalr	-296(ra) # 80002b82 <argint>
  exit(n);
    80002cb2:	fec42503          	lw	a0,-20(s0)
    80002cb6:	fffff097          	auipc	ra,0xfffff
    80002cba:	58a080e7          	jalr	1418(ra) # 80002240 <exit>
  return 0;  // not reached
}
    80002cbe:	4501                	li	a0,0
    80002cc0:	60e2                	ld	ra,24(sp)
    80002cc2:	6442                	ld	s0,16(sp)
    80002cc4:	6105                	addi	sp,sp,32
    80002cc6:	8082                	ret

0000000080002cc8 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002cc8:	1141                	addi	sp,sp,-16
    80002cca:	e406                	sd	ra,8(sp)
    80002ccc:	e022                	sd	s0,0(sp)
    80002cce:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002cd0:	fffff097          	auipc	ra,0xfffff
    80002cd4:	d92080e7          	jalr	-622(ra) # 80001a62 <myproc>
}
    80002cd8:	5908                	lw	a0,48(a0)
    80002cda:	60a2                	ld	ra,8(sp)
    80002cdc:	6402                	ld	s0,0(sp)
    80002cde:	0141                	addi	sp,sp,16
    80002ce0:	8082                	ret

0000000080002ce2 <sys_fork>:

uint64
sys_fork(void)
{
    80002ce2:	1141                	addi	sp,sp,-16
    80002ce4:	e406                	sd	ra,8(sp)
    80002ce6:	e022                	sd	s0,0(sp)
    80002ce8:	0800                	addi	s0,sp,16
  return fork();
    80002cea:	fffff097          	auipc	ra,0xfffff
    80002cee:	12e080e7          	jalr	302(ra) # 80001e18 <fork>
}
    80002cf2:	60a2                	ld	ra,8(sp)
    80002cf4:	6402                	ld	s0,0(sp)
    80002cf6:	0141                	addi	sp,sp,16
    80002cf8:	8082                	ret

0000000080002cfa <sys_wait>:

uint64
sys_wait(void)
{
    80002cfa:	1101                	addi	sp,sp,-32
    80002cfc:	ec06                	sd	ra,24(sp)
    80002cfe:	e822                	sd	s0,16(sp)
    80002d00:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002d02:	fe840593          	addi	a1,s0,-24
    80002d06:	4501                	li	a0,0
    80002d08:	00000097          	auipc	ra,0x0
    80002d0c:	e9a080e7          	jalr	-358(ra) # 80002ba2 <argaddr>
  return wait(p);
    80002d10:	fe843503          	ld	a0,-24(s0)
    80002d14:	fffff097          	auipc	ra,0xfffff
    80002d18:	6d2080e7          	jalr	1746(ra) # 800023e6 <wait>
}
    80002d1c:	60e2                	ld	ra,24(sp)
    80002d1e:	6442                	ld	s0,16(sp)
    80002d20:	6105                	addi	sp,sp,32
    80002d22:	8082                	ret

0000000080002d24 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002d24:	7179                	addi	sp,sp,-48
    80002d26:	f406                	sd	ra,40(sp)
    80002d28:	f022                	sd	s0,32(sp)
    80002d2a:	ec26                	sd	s1,24(sp)
    80002d2c:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80002d2e:	fdc40593          	addi	a1,s0,-36
    80002d32:	4501                	li	a0,0
    80002d34:	00000097          	auipc	ra,0x0
    80002d38:	e4e080e7          	jalr	-434(ra) # 80002b82 <argint>
  addr = myproc()->sz;
    80002d3c:	fffff097          	auipc	ra,0xfffff
    80002d40:	d26080e7          	jalr	-730(ra) # 80001a62 <myproc>
    80002d44:	6524                	ld	s1,72(a0)
  if(growproc(n) < 0)
    80002d46:	fdc42503          	lw	a0,-36(s0)
    80002d4a:	fffff097          	auipc	ra,0xfffff
    80002d4e:	072080e7          	jalr	114(ra) # 80001dbc <growproc>
    80002d52:	00054863          	bltz	a0,80002d62 <sys_sbrk+0x3e>
    return -1;
  return addr;
}
    80002d56:	8526                	mv	a0,s1
    80002d58:	70a2                	ld	ra,40(sp)
    80002d5a:	7402                	ld	s0,32(sp)
    80002d5c:	64e2                	ld	s1,24(sp)
    80002d5e:	6145                	addi	sp,sp,48
    80002d60:	8082                	ret
    return -1;
    80002d62:	54fd                	li	s1,-1
    80002d64:	bfcd                	j	80002d56 <sys_sbrk+0x32>

0000000080002d66 <sys_sleep>:

uint64
sys_sleep(void)
{
    80002d66:	7139                	addi	sp,sp,-64
    80002d68:	fc06                	sd	ra,56(sp)
    80002d6a:	f822                	sd	s0,48(sp)
    80002d6c:	f04a                	sd	s2,32(sp)
    80002d6e:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002d70:	fcc40593          	addi	a1,s0,-52
    80002d74:	4501                	li	a0,0
    80002d76:	00000097          	auipc	ra,0x0
    80002d7a:	e0c080e7          	jalr	-500(ra) # 80002b82 <argint>
  acquire(&tickslock);
    80002d7e:	00016517          	auipc	a0,0x16
    80002d82:	51250513          	addi	a0,a0,1298 # 80019290 <tickslock>
    80002d86:	ffffe097          	auipc	ra,0xffffe
    80002d8a:	eb2080e7          	jalr	-334(ra) # 80000c38 <acquire>
  ticks0 = ticks;
    80002d8e:	00008917          	auipc	s2,0x8
    80002d92:	46292903          	lw	s2,1122(s2) # 8000b1f0 <ticks>
  while(ticks - ticks0 < n){
    80002d96:	fcc42783          	lw	a5,-52(s0)
    80002d9a:	c3b9                	beqz	a5,80002de0 <sys_sleep+0x7a>
    80002d9c:	f426                	sd	s1,40(sp)
    80002d9e:	ec4e                	sd	s3,24(sp)
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002da0:	00016997          	auipc	s3,0x16
    80002da4:	4f098993          	addi	s3,s3,1264 # 80019290 <tickslock>
    80002da8:	00008497          	auipc	s1,0x8
    80002dac:	44848493          	addi	s1,s1,1096 # 8000b1f0 <ticks>
    if(killed(myproc())){
    80002db0:	fffff097          	auipc	ra,0xfffff
    80002db4:	cb2080e7          	jalr	-846(ra) # 80001a62 <myproc>
    80002db8:	fffff097          	auipc	ra,0xfffff
    80002dbc:	5fc080e7          	jalr	1532(ra) # 800023b4 <killed>
    80002dc0:	ed15                	bnez	a0,80002dfc <sys_sleep+0x96>
    sleep(&ticks, &tickslock);
    80002dc2:	85ce                	mv	a1,s3
    80002dc4:	8526                	mv	a0,s1
    80002dc6:	fffff097          	auipc	ra,0xfffff
    80002dca:	346080e7          	jalr	838(ra) # 8000210c <sleep>
  while(ticks - ticks0 < n){
    80002dce:	409c                	lw	a5,0(s1)
    80002dd0:	412787bb          	subw	a5,a5,s2
    80002dd4:	fcc42703          	lw	a4,-52(s0)
    80002dd8:	fce7ece3          	bltu	a5,a4,80002db0 <sys_sleep+0x4a>
    80002ddc:	74a2                	ld	s1,40(sp)
    80002dde:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002de0:	00016517          	auipc	a0,0x16
    80002de4:	4b050513          	addi	a0,a0,1200 # 80019290 <tickslock>
    80002de8:	ffffe097          	auipc	ra,0xffffe
    80002dec:	f04080e7          	jalr	-252(ra) # 80000cec <release>
  return 0;
    80002df0:	4501                	li	a0,0
}
    80002df2:	70e2                	ld	ra,56(sp)
    80002df4:	7442                	ld	s0,48(sp)
    80002df6:	7902                	ld	s2,32(sp)
    80002df8:	6121                	addi	sp,sp,64
    80002dfa:	8082                	ret
      release(&tickslock);
    80002dfc:	00016517          	auipc	a0,0x16
    80002e00:	49450513          	addi	a0,a0,1172 # 80019290 <tickslock>
    80002e04:	ffffe097          	auipc	ra,0xffffe
    80002e08:	ee8080e7          	jalr	-280(ra) # 80000cec <release>
      return -1;
    80002e0c:	557d                	li	a0,-1
    80002e0e:	74a2                	ld	s1,40(sp)
    80002e10:	69e2                	ld	s3,24(sp)
    80002e12:	b7c5                	j	80002df2 <sys_sleep+0x8c>

0000000080002e14 <sys_kill>:

uint64
sys_kill(void)
{
    80002e14:	1101                	addi	sp,sp,-32
    80002e16:	ec06                	sd	ra,24(sp)
    80002e18:	e822                	sd	s0,16(sp)
    80002e1a:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002e1c:	fec40593          	addi	a1,s0,-20
    80002e20:	4501                	li	a0,0
    80002e22:	00000097          	auipc	ra,0x0
    80002e26:	d60080e7          	jalr	-672(ra) # 80002b82 <argint>
  return kill(pid);
    80002e2a:	fec42503          	lw	a0,-20(s0)
    80002e2e:	fffff097          	auipc	ra,0xfffff
    80002e32:	4e8080e7          	jalr	1256(ra) # 80002316 <kill>
}
    80002e36:	60e2                	ld	ra,24(sp)
    80002e38:	6442                	ld	s0,16(sp)
    80002e3a:	6105                	addi	sp,sp,32
    80002e3c:	8082                	ret

0000000080002e3e <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002e3e:	1101                	addi	sp,sp,-32
    80002e40:	ec06                	sd	ra,24(sp)
    80002e42:	e822                	sd	s0,16(sp)
    80002e44:	e426                	sd	s1,8(sp)
    80002e46:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002e48:	00016517          	auipc	a0,0x16
    80002e4c:	44850513          	addi	a0,a0,1096 # 80019290 <tickslock>
    80002e50:	ffffe097          	auipc	ra,0xffffe
    80002e54:	de8080e7          	jalr	-536(ra) # 80000c38 <acquire>
  xticks = ticks;
    80002e58:	00008497          	auipc	s1,0x8
    80002e5c:	3984a483          	lw	s1,920(s1) # 8000b1f0 <ticks>
  release(&tickslock);
    80002e60:	00016517          	auipc	a0,0x16
    80002e64:	43050513          	addi	a0,a0,1072 # 80019290 <tickslock>
    80002e68:	ffffe097          	auipc	ra,0xffffe
    80002e6c:	e84080e7          	jalr	-380(ra) # 80000cec <release>
  return xticks;
}
    80002e70:	02049513          	slli	a0,s1,0x20
    80002e74:	9101                	srli	a0,a0,0x20
    80002e76:	60e2                	ld	ra,24(sp)
    80002e78:	6442                	ld	s0,16(sp)
    80002e7a:	64a2                	ld	s1,8(sp)
    80002e7c:	6105                	addi	sp,sp,32
    80002e7e:	8082                	ret

0000000080002e80 <sys_getcnt>:

extern int syscall_count[];
extern const int NELEM_SYSCALLS;
extern struct spinlock count_lock;

uint64 sys_getcnt(void) {
    80002e80:	7179                	addi	sp,sp,-48
    80002e82:	f406                	sd	ra,40(sp)
    80002e84:	f022                	sd	s0,32(sp)
    80002e86:	1800                	addi	s0,sp,48
  int num, cnt;

  argint(0, &num);
    80002e88:	fdc40593          	addi	a1,s0,-36
    80002e8c:	4501                	li	a0,0
    80002e8e:	00000097          	auipc	ra,0x0
    80002e92:	cf4080e7          	jalr	-780(ra) # 80002b82 <argint>

  if (num > 0 && num < NELEM_SYSCALLS) {
    80002e96:	fdc42703          	lw	a4,-36(s0)
    release(&count_lock);

    return cnt;
  }

  return -1;
    80002e9a:	557d                	li	a0,-1
  if (num > 0 && num < NELEM_SYSCALLS) {
    80002e9c:	00e05863          	blez	a4,80002eac <sys_getcnt+0x2c>
    80002ea0:	00005797          	auipc	a5,0x5
    80002ea4:	1607a783          	lw	a5,352(a5) # 80008000 <etext>
    80002ea8:	00f74663          	blt	a4,a5,80002eb4 <sys_getcnt+0x34>
}
    80002eac:	70a2                	ld	ra,40(sp)
    80002eae:	7402                	ld	s0,32(sp)
    80002eb0:	6145                	addi	sp,sp,48
    80002eb2:	8082                	ret
    80002eb4:	ec26                	sd	s1,24(sp)
    acquire(&count_lock);
    80002eb6:	00016517          	auipc	a0,0x16
    80002eba:	3f250513          	addi	a0,a0,1010 # 800192a8 <count_lock>
    80002ebe:	ffffe097          	auipc	ra,0xffffe
    80002ec2:	d7a080e7          	jalr	-646(ra) # 80000c38 <acquire>
    cnt = syscall_count[num];
    80002ec6:	fdc42703          	lw	a4,-36(s0)
    80002eca:	070a                	slli	a4,a4,0x2
    80002ecc:	00016797          	auipc	a5,0x16
    80002ed0:	3f478793          	addi	a5,a5,1012 # 800192c0 <syscall_count>
    80002ed4:	97ba                	add	a5,a5,a4
    80002ed6:	4384                	lw	s1,0(a5)
    release(&count_lock);
    80002ed8:	00016517          	auipc	a0,0x16
    80002edc:	3d050513          	addi	a0,a0,976 # 800192a8 <count_lock>
    80002ee0:	ffffe097          	auipc	ra,0xffffe
    80002ee4:	e0c080e7          	jalr	-500(ra) # 80000cec <release>
    return cnt;
    80002ee8:	8526                	mv	a0,s1
    80002eea:	64e2                	ld	s1,24(sp)
    80002eec:	b7c1                	j	80002eac <sys_getcnt+0x2c>

0000000080002eee <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002eee:	7179                	addi	sp,sp,-48
    80002ef0:	f406                	sd	ra,40(sp)
    80002ef2:	f022                	sd	s0,32(sp)
    80002ef4:	ec26                	sd	s1,24(sp)
    80002ef6:	e84a                	sd	s2,16(sp)
    80002ef8:	e44e                	sd	s3,8(sp)
    80002efa:	e052                	sd	s4,0(sp)
    80002efc:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002efe:	00005597          	auipc	a1,0x5
    80002f02:	50a58593          	addi	a1,a1,1290 # 80008408 <etext+0x408>
    80002f06:	00016517          	auipc	a0,0x16
    80002f0a:	41a50513          	addi	a0,a0,1050 # 80019320 <bcache>
    80002f0e:	ffffe097          	auipc	ra,0xffffe
    80002f12:	c9a080e7          	jalr	-870(ra) # 80000ba8 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002f16:	0001e797          	auipc	a5,0x1e
    80002f1a:	40a78793          	addi	a5,a5,1034 # 80021320 <bcache+0x8000>
    80002f1e:	0001e717          	auipc	a4,0x1e
    80002f22:	66a70713          	addi	a4,a4,1642 # 80021588 <bcache+0x8268>
    80002f26:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002f2a:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002f2e:	00016497          	auipc	s1,0x16
    80002f32:	40a48493          	addi	s1,s1,1034 # 80019338 <bcache+0x18>
    b->next = bcache.head.next;
    80002f36:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002f38:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002f3a:	00005a17          	auipc	s4,0x5
    80002f3e:	4d6a0a13          	addi	s4,s4,1238 # 80008410 <etext+0x410>
    b->next = bcache.head.next;
    80002f42:	2b893783          	ld	a5,696(s2)
    80002f46:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002f48:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002f4c:	85d2                	mv	a1,s4
    80002f4e:	01048513          	addi	a0,s1,16
    80002f52:	00001097          	auipc	ra,0x1
    80002f56:	4e8080e7          	jalr	1256(ra) # 8000443a <initsleeplock>
    bcache.head.next->prev = b;
    80002f5a:	2b893783          	ld	a5,696(s2)
    80002f5e:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002f60:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002f64:	45848493          	addi	s1,s1,1112
    80002f68:	fd349de3          	bne	s1,s3,80002f42 <binit+0x54>
  }
}
    80002f6c:	70a2                	ld	ra,40(sp)
    80002f6e:	7402                	ld	s0,32(sp)
    80002f70:	64e2                	ld	s1,24(sp)
    80002f72:	6942                	ld	s2,16(sp)
    80002f74:	69a2                	ld	s3,8(sp)
    80002f76:	6a02                	ld	s4,0(sp)
    80002f78:	6145                	addi	sp,sp,48
    80002f7a:	8082                	ret

0000000080002f7c <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002f7c:	7179                	addi	sp,sp,-48
    80002f7e:	f406                	sd	ra,40(sp)
    80002f80:	f022                	sd	s0,32(sp)
    80002f82:	ec26                	sd	s1,24(sp)
    80002f84:	e84a                	sd	s2,16(sp)
    80002f86:	e44e                	sd	s3,8(sp)
    80002f88:	1800                	addi	s0,sp,48
    80002f8a:	892a                	mv	s2,a0
    80002f8c:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002f8e:	00016517          	auipc	a0,0x16
    80002f92:	39250513          	addi	a0,a0,914 # 80019320 <bcache>
    80002f96:	ffffe097          	auipc	ra,0xffffe
    80002f9a:	ca2080e7          	jalr	-862(ra) # 80000c38 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002f9e:	0001e497          	auipc	s1,0x1e
    80002fa2:	63a4b483          	ld	s1,1594(s1) # 800215d8 <bcache+0x82b8>
    80002fa6:	0001e797          	auipc	a5,0x1e
    80002faa:	5e278793          	addi	a5,a5,1506 # 80021588 <bcache+0x8268>
    80002fae:	02f48f63          	beq	s1,a5,80002fec <bread+0x70>
    80002fb2:	873e                	mv	a4,a5
    80002fb4:	a021                	j	80002fbc <bread+0x40>
    80002fb6:	68a4                	ld	s1,80(s1)
    80002fb8:	02e48a63          	beq	s1,a4,80002fec <bread+0x70>
    if(b->dev == dev && b->blockno == blockno){
    80002fbc:	449c                	lw	a5,8(s1)
    80002fbe:	ff279ce3          	bne	a5,s2,80002fb6 <bread+0x3a>
    80002fc2:	44dc                	lw	a5,12(s1)
    80002fc4:	ff3799e3          	bne	a5,s3,80002fb6 <bread+0x3a>
      b->refcnt++;
    80002fc8:	40bc                	lw	a5,64(s1)
    80002fca:	2785                	addiw	a5,a5,1
    80002fcc:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002fce:	00016517          	auipc	a0,0x16
    80002fd2:	35250513          	addi	a0,a0,850 # 80019320 <bcache>
    80002fd6:	ffffe097          	auipc	ra,0xffffe
    80002fda:	d16080e7          	jalr	-746(ra) # 80000cec <release>
      acquiresleep(&b->lock);
    80002fde:	01048513          	addi	a0,s1,16
    80002fe2:	00001097          	auipc	ra,0x1
    80002fe6:	492080e7          	jalr	1170(ra) # 80004474 <acquiresleep>
      return b;
    80002fea:	a8b9                	j	80003048 <bread+0xcc>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002fec:	0001e497          	auipc	s1,0x1e
    80002ff0:	5e44b483          	ld	s1,1508(s1) # 800215d0 <bcache+0x82b0>
    80002ff4:	0001e797          	auipc	a5,0x1e
    80002ff8:	59478793          	addi	a5,a5,1428 # 80021588 <bcache+0x8268>
    80002ffc:	00f48863          	beq	s1,a5,8000300c <bread+0x90>
    80003000:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80003002:	40bc                	lw	a5,64(s1)
    80003004:	cf81                	beqz	a5,8000301c <bread+0xa0>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80003006:	64a4                	ld	s1,72(s1)
    80003008:	fee49de3          	bne	s1,a4,80003002 <bread+0x86>
  panic("bget: no buffers");
    8000300c:	00005517          	auipc	a0,0x5
    80003010:	40c50513          	addi	a0,a0,1036 # 80008418 <etext+0x418>
    80003014:	ffffd097          	auipc	ra,0xffffd
    80003018:	54c080e7          	jalr	1356(ra) # 80000560 <panic>
      b->dev = dev;
    8000301c:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80003020:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80003024:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80003028:	4785                	li	a5,1
    8000302a:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    8000302c:	00016517          	auipc	a0,0x16
    80003030:	2f450513          	addi	a0,a0,756 # 80019320 <bcache>
    80003034:	ffffe097          	auipc	ra,0xffffe
    80003038:	cb8080e7          	jalr	-840(ra) # 80000cec <release>
      acquiresleep(&b->lock);
    8000303c:	01048513          	addi	a0,s1,16
    80003040:	00001097          	auipc	ra,0x1
    80003044:	434080e7          	jalr	1076(ra) # 80004474 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80003048:	409c                	lw	a5,0(s1)
    8000304a:	cb89                	beqz	a5,8000305c <bread+0xe0>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    8000304c:	8526                	mv	a0,s1
    8000304e:	70a2                	ld	ra,40(sp)
    80003050:	7402                	ld	s0,32(sp)
    80003052:	64e2                	ld	s1,24(sp)
    80003054:	6942                	ld	s2,16(sp)
    80003056:	69a2                	ld	s3,8(sp)
    80003058:	6145                	addi	sp,sp,48
    8000305a:	8082                	ret
    virtio_disk_rw(b, 0);
    8000305c:	4581                	li	a1,0
    8000305e:	8526                	mv	a0,s1
    80003060:	00003097          	auipc	ra,0x3
    80003064:	0f8080e7          	jalr	248(ra) # 80006158 <virtio_disk_rw>
    b->valid = 1;
    80003068:	4785                	li	a5,1
    8000306a:	c09c                	sw	a5,0(s1)
  return b;
    8000306c:	b7c5                	j	8000304c <bread+0xd0>

000000008000306e <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    8000306e:	1101                	addi	sp,sp,-32
    80003070:	ec06                	sd	ra,24(sp)
    80003072:	e822                	sd	s0,16(sp)
    80003074:	e426                	sd	s1,8(sp)
    80003076:	1000                	addi	s0,sp,32
    80003078:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    8000307a:	0541                	addi	a0,a0,16
    8000307c:	00001097          	auipc	ra,0x1
    80003080:	492080e7          	jalr	1170(ra) # 8000450e <holdingsleep>
    80003084:	cd01                	beqz	a0,8000309c <bwrite+0x2e>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80003086:	4585                	li	a1,1
    80003088:	8526                	mv	a0,s1
    8000308a:	00003097          	auipc	ra,0x3
    8000308e:	0ce080e7          	jalr	206(ra) # 80006158 <virtio_disk_rw>
}
    80003092:	60e2                	ld	ra,24(sp)
    80003094:	6442                	ld	s0,16(sp)
    80003096:	64a2                	ld	s1,8(sp)
    80003098:	6105                	addi	sp,sp,32
    8000309a:	8082                	ret
    panic("bwrite");
    8000309c:	00005517          	auipc	a0,0x5
    800030a0:	39450513          	addi	a0,a0,916 # 80008430 <etext+0x430>
    800030a4:	ffffd097          	auipc	ra,0xffffd
    800030a8:	4bc080e7          	jalr	1212(ra) # 80000560 <panic>

00000000800030ac <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    800030ac:	1101                	addi	sp,sp,-32
    800030ae:	ec06                	sd	ra,24(sp)
    800030b0:	e822                	sd	s0,16(sp)
    800030b2:	e426                	sd	s1,8(sp)
    800030b4:	e04a                	sd	s2,0(sp)
    800030b6:	1000                	addi	s0,sp,32
    800030b8:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    800030ba:	01050913          	addi	s2,a0,16
    800030be:	854a                	mv	a0,s2
    800030c0:	00001097          	auipc	ra,0x1
    800030c4:	44e080e7          	jalr	1102(ra) # 8000450e <holdingsleep>
    800030c8:	c925                	beqz	a0,80003138 <brelse+0x8c>
    panic("brelse");

  releasesleep(&b->lock);
    800030ca:	854a                	mv	a0,s2
    800030cc:	00001097          	auipc	ra,0x1
    800030d0:	3fe080e7          	jalr	1022(ra) # 800044ca <releasesleep>

  acquire(&bcache.lock);
    800030d4:	00016517          	auipc	a0,0x16
    800030d8:	24c50513          	addi	a0,a0,588 # 80019320 <bcache>
    800030dc:	ffffe097          	auipc	ra,0xffffe
    800030e0:	b5c080e7          	jalr	-1188(ra) # 80000c38 <acquire>
  b->refcnt--;
    800030e4:	40bc                	lw	a5,64(s1)
    800030e6:	37fd                	addiw	a5,a5,-1
    800030e8:	0007871b          	sext.w	a4,a5
    800030ec:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    800030ee:	e71d                	bnez	a4,8000311c <brelse+0x70>
    // no one is waiting for it.
    b->next->prev = b->prev;
    800030f0:	68b8                	ld	a4,80(s1)
    800030f2:	64bc                	ld	a5,72(s1)
    800030f4:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    800030f6:	68b8                	ld	a4,80(s1)
    800030f8:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    800030fa:	0001e797          	auipc	a5,0x1e
    800030fe:	22678793          	addi	a5,a5,550 # 80021320 <bcache+0x8000>
    80003102:	2b87b703          	ld	a4,696(a5)
    80003106:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80003108:	0001e717          	auipc	a4,0x1e
    8000310c:	48070713          	addi	a4,a4,1152 # 80021588 <bcache+0x8268>
    80003110:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80003112:	2b87b703          	ld	a4,696(a5)
    80003116:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80003118:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    8000311c:	00016517          	auipc	a0,0x16
    80003120:	20450513          	addi	a0,a0,516 # 80019320 <bcache>
    80003124:	ffffe097          	auipc	ra,0xffffe
    80003128:	bc8080e7          	jalr	-1080(ra) # 80000cec <release>
}
    8000312c:	60e2                	ld	ra,24(sp)
    8000312e:	6442                	ld	s0,16(sp)
    80003130:	64a2                	ld	s1,8(sp)
    80003132:	6902                	ld	s2,0(sp)
    80003134:	6105                	addi	sp,sp,32
    80003136:	8082                	ret
    panic("brelse");
    80003138:	00005517          	auipc	a0,0x5
    8000313c:	30050513          	addi	a0,a0,768 # 80008438 <etext+0x438>
    80003140:	ffffd097          	auipc	ra,0xffffd
    80003144:	420080e7          	jalr	1056(ra) # 80000560 <panic>

0000000080003148 <bpin>:

void
bpin(struct buf *b) {
    80003148:	1101                	addi	sp,sp,-32
    8000314a:	ec06                	sd	ra,24(sp)
    8000314c:	e822                	sd	s0,16(sp)
    8000314e:	e426                	sd	s1,8(sp)
    80003150:	1000                	addi	s0,sp,32
    80003152:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80003154:	00016517          	auipc	a0,0x16
    80003158:	1cc50513          	addi	a0,a0,460 # 80019320 <bcache>
    8000315c:	ffffe097          	auipc	ra,0xffffe
    80003160:	adc080e7          	jalr	-1316(ra) # 80000c38 <acquire>
  b->refcnt++;
    80003164:	40bc                	lw	a5,64(s1)
    80003166:	2785                	addiw	a5,a5,1
    80003168:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000316a:	00016517          	auipc	a0,0x16
    8000316e:	1b650513          	addi	a0,a0,438 # 80019320 <bcache>
    80003172:	ffffe097          	auipc	ra,0xffffe
    80003176:	b7a080e7          	jalr	-1158(ra) # 80000cec <release>
}
    8000317a:	60e2                	ld	ra,24(sp)
    8000317c:	6442                	ld	s0,16(sp)
    8000317e:	64a2                	ld	s1,8(sp)
    80003180:	6105                	addi	sp,sp,32
    80003182:	8082                	ret

0000000080003184 <bunpin>:

void
bunpin(struct buf *b) {
    80003184:	1101                	addi	sp,sp,-32
    80003186:	ec06                	sd	ra,24(sp)
    80003188:	e822                	sd	s0,16(sp)
    8000318a:	e426                	sd	s1,8(sp)
    8000318c:	1000                	addi	s0,sp,32
    8000318e:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80003190:	00016517          	auipc	a0,0x16
    80003194:	19050513          	addi	a0,a0,400 # 80019320 <bcache>
    80003198:	ffffe097          	auipc	ra,0xffffe
    8000319c:	aa0080e7          	jalr	-1376(ra) # 80000c38 <acquire>
  b->refcnt--;
    800031a0:	40bc                	lw	a5,64(s1)
    800031a2:	37fd                	addiw	a5,a5,-1
    800031a4:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800031a6:	00016517          	auipc	a0,0x16
    800031aa:	17a50513          	addi	a0,a0,378 # 80019320 <bcache>
    800031ae:	ffffe097          	auipc	ra,0xffffe
    800031b2:	b3e080e7          	jalr	-1218(ra) # 80000cec <release>
}
    800031b6:	60e2                	ld	ra,24(sp)
    800031b8:	6442                	ld	s0,16(sp)
    800031ba:	64a2                	ld	s1,8(sp)
    800031bc:	6105                	addi	sp,sp,32
    800031be:	8082                	ret

00000000800031c0 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    800031c0:	1101                	addi	sp,sp,-32
    800031c2:	ec06                	sd	ra,24(sp)
    800031c4:	e822                	sd	s0,16(sp)
    800031c6:	e426                	sd	s1,8(sp)
    800031c8:	e04a                	sd	s2,0(sp)
    800031ca:	1000                	addi	s0,sp,32
    800031cc:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    800031ce:	00d5d59b          	srliw	a1,a1,0xd
    800031d2:	0001f797          	auipc	a5,0x1f
    800031d6:	82a7a783          	lw	a5,-2006(a5) # 800219fc <sb+0x1c>
    800031da:	9dbd                	addw	a1,a1,a5
    800031dc:	00000097          	auipc	ra,0x0
    800031e0:	da0080e7          	jalr	-608(ra) # 80002f7c <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    800031e4:	0074f713          	andi	a4,s1,7
    800031e8:	4785                	li	a5,1
    800031ea:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    800031ee:	14ce                	slli	s1,s1,0x33
    800031f0:	90d9                	srli	s1,s1,0x36
    800031f2:	00950733          	add	a4,a0,s1
    800031f6:	05874703          	lbu	a4,88(a4)
    800031fa:	00e7f6b3          	and	a3,a5,a4
    800031fe:	c69d                	beqz	a3,8000322c <bfree+0x6c>
    80003200:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80003202:	94aa                	add	s1,s1,a0
    80003204:	fff7c793          	not	a5,a5
    80003208:	8f7d                	and	a4,a4,a5
    8000320a:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    8000320e:	00001097          	auipc	ra,0x1
    80003212:	148080e7          	jalr	328(ra) # 80004356 <log_write>
  brelse(bp);
    80003216:	854a                	mv	a0,s2
    80003218:	00000097          	auipc	ra,0x0
    8000321c:	e94080e7          	jalr	-364(ra) # 800030ac <brelse>
}
    80003220:	60e2                	ld	ra,24(sp)
    80003222:	6442                	ld	s0,16(sp)
    80003224:	64a2                	ld	s1,8(sp)
    80003226:	6902                	ld	s2,0(sp)
    80003228:	6105                	addi	sp,sp,32
    8000322a:	8082                	ret
    panic("freeing free block");
    8000322c:	00005517          	auipc	a0,0x5
    80003230:	21450513          	addi	a0,a0,532 # 80008440 <etext+0x440>
    80003234:	ffffd097          	auipc	ra,0xffffd
    80003238:	32c080e7          	jalr	812(ra) # 80000560 <panic>

000000008000323c <balloc>:
{
    8000323c:	711d                	addi	sp,sp,-96
    8000323e:	ec86                	sd	ra,88(sp)
    80003240:	e8a2                	sd	s0,80(sp)
    80003242:	e4a6                	sd	s1,72(sp)
    80003244:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    80003246:	0001e797          	auipc	a5,0x1e
    8000324a:	79e7a783          	lw	a5,1950(a5) # 800219e4 <sb+0x4>
    8000324e:	10078f63          	beqz	a5,8000336c <balloc+0x130>
    80003252:	e0ca                	sd	s2,64(sp)
    80003254:	fc4e                	sd	s3,56(sp)
    80003256:	f852                	sd	s4,48(sp)
    80003258:	f456                	sd	s5,40(sp)
    8000325a:	f05a                	sd	s6,32(sp)
    8000325c:	ec5e                	sd	s7,24(sp)
    8000325e:	e862                	sd	s8,16(sp)
    80003260:	e466                	sd	s9,8(sp)
    80003262:	8baa                	mv	s7,a0
    80003264:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80003266:	0001eb17          	auipc	s6,0x1e
    8000326a:	77ab0b13          	addi	s6,s6,1914 # 800219e0 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000326e:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    80003270:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003272:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80003274:	6c89                	lui	s9,0x2
    80003276:	a061                	j	800032fe <balloc+0xc2>
        bp->data[bi/8] |= m;  // Mark block in use.
    80003278:	97ca                	add	a5,a5,s2
    8000327a:	8e55                	or	a2,a2,a3
    8000327c:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80003280:	854a                	mv	a0,s2
    80003282:	00001097          	auipc	ra,0x1
    80003286:	0d4080e7          	jalr	212(ra) # 80004356 <log_write>
        brelse(bp);
    8000328a:	854a                	mv	a0,s2
    8000328c:	00000097          	auipc	ra,0x0
    80003290:	e20080e7          	jalr	-480(ra) # 800030ac <brelse>
  bp = bread(dev, bno);
    80003294:	85a6                	mv	a1,s1
    80003296:	855e                	mv	a0,s7
    80003298:	00000097          	auipc	ra,0x0
    8000329c:	ce4080e7          	jalr	-796(ra) # 80002f7c <bread>
    800032a0:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    800032a2:	40000613          	li	a2,1024
    800032a6:	4581                	li	a1,0
    800032a8:	05850513          	addi	a0,a0,88
    800032ac:	ffffe097          	auipc	ra,0xffffe
    800032b0:	a88080e7          	jalr	-1400(ra) # 80000d34 <memset>
  log_write(bp);
    800032b4:	854a                	mv	a0,s2
    800032b6:	00001097          	auipc	ra,0x1
    800032ba:	0a0080e7          	jalr	160(ra) # 80004356 <log_write>
  brelse(bp);
    800032be:	854a                	mv	a0,s2
    800032c0:	00000097          	auipc	ra,0x0
    800032c4:	dec080e7          	jalr	-532(ra) # 800030ac <brelse>
}
    800032c8:	6906                	ld	s2,64(sp)
    800032ca:	79e2                	ld	s3,56(sp)
    800032cc:	7a42                	ld	s4,48(sp)
    800032ce:	7aa2                	ld	s5,40(sp)
    800032d0:	7b02                	ld	s6,32(sp)
    800032d2:	6be2                	ld	s7,24(sp)
    800032d4:	6c42                	ld	s8,16(sp)
    800032d6:	6ca2                	ld	s9,8(sp)
}
    800032d8:	8526                	mv	a0,s1
    800032da:	60e6                	ld	ra,88(sp)
    800032dc:	6446                	ld	s0,80(sp)
    800032de:	64a6                	ld	s1,72(sp)
    800032e0:	6125                	addi	sp,sp,96
    800032e2:	8082                	ret
    brelse(bp);
    800032e4:	854a                	mv	a0,s2
    800032e6:	00000097          	auipc	ra,0x0
    800032ea:	dc6080e7          	jalr	-570(ra) # 800030ac <brelse>
  for(b = 0; b < sb.size; b += BPB){
    800032ee:	015c87bb          	addw	a5,s9,s5
    800032f2:	00078a9b          	sext.w	s5,a5
    800032f6:	004b2703          	lw	a4,4(s6)
    800032fa:	06eaf163          	bgeu	s5,a4,8000335c <balloc+0x120>
    bp = bread(dev, BBLOCK(b, sb));
    800032fe:	41fad79b          	sraiw	a5,s5,0x1f
    80003302:	0137d79b          	srliw	a5,a5,0x13
    80003306:	015787bb          	addw	a5,a5,s5
    8000330a:	40d7d79b          	sraiw	a5,a5,0xd
    8000330e:	01cb2583          	lw	a1,28(s6)
    80003312:	9dbd                	addw	a1,a1,a5
    80003314:	855e                	mv	a0,s7
    80003316:	00000097          	auipc	ra,0x0
    8000331a:	c66080e7          	jalr	-922(ra) # 80002f7c <bread>
    8000331e:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003320:	004b2503          	lw	a0,4(s6)
    80003324:	000a849b          	sext.w	s1,s5
    80003328:	8762                	mv	a4,s8
    8000332a:	faa4fde3          	bgeu	s1,a0,800032e4 <balloc+0xa8>
      m = 1 << (bi % 8);
    8000332e:	00777693          	andi	a3,a4,7
    80003332:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80003336:	41f7579b          	sraiw	a5,a4,0x1f
    8000333a:	01d7d79b          	srliw	a5,a5,0x1d
    8000333e:	9fb9                	addw	a5,a5,a4
    80003340:	4037d79b          	sraiw	a5,a5,0x3
    80003344:	00f90633          	add	a2,s2,a5
    80003348:	05864603          	lbu	a2,88(a2)
    8000334c:	00c6f5b3          	and	a1,a3,a2
    80003350:	d585                	beqz	a1,80003278 <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003352:	2705                	addiw	a4,a4,1
    80003354:	2485                	addiw	s1,s1,1
    80003356:	fd471ae3          	bne	a4,s4,8000332a <balloc+0xee>
    8000335a:	b769                	j	800032e4 <balloc+0xa8>
    8000335c:	6906                	ld	s2,64(sp)
    8000335e:	79e2                	ld	s3,56(sp)
    80003360:	7a42                	ld	s4,48(sp)
    80003362:	7aa2                	ld	s5,40(sp)
    80003364:	7b02                	ld	s6,32(sp)
    80003366:	6be2                	ld	s7,24(sp)
    80003368:	6c42                	ld	s8,16(sp)
    8000336a:	6ca2                	ld	s9,8(sp)
  printf("balloc: out of blocks\n");
    8000336c:	00005517          	auipc	a0,0x5
    80003370:	0ec50513          	addi	a0,a0,236 # 80008458 <etext+0x458>
    80003374:	ffffd097          	auipc	ra,0xffffd
    80003378:	236080e7          	jalr	566(ra) # 800005aa <printf>
  return 0;
    8000337c:	4481                	li	s1,0
    8000337e:	bfa9                	j	800032d8 <balloc+0x9c>

0000000080003380 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80003380:	7179                	addi	sp,sp,-48
    80003382:	f406                	sd	ra,40(sp)
    80003384:	f022                	sd	s0,32(sp)
    80003386:	ec26                	sd	s1,24(sp)
    80003388:	e84a                	sd	s2,16(sp)
    8000338a:	e44e                	sd	s3,8(sp)
    8000338c:	1800                	addi	s0,sp,48
    8000338e:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80003390:	47ad                	li	a5,11
    80003392:	02b7e863          	bltu	a5,a1,800033c2 <bmap+0x42>
    if((addr = ip->addrs[bn]) == 0){
    80003396:	02059793          	slli	a5,a1,0x20
    8000339a:	01e7d593          	srli	a1,a5,0x1e
    8000339e:	00b504b3          	add	s1,a0,a1
    800033a2:	0504a903          	lw	s2,80(s1)
    800033a6:	08091263          	bnez	s2,8000342a <bmap+0xaa>
      addr = balloc(ip->dev);
    800033aa:	4108                	lw	a0,0(a0)
    800033ac:	00000097          	auipc	ra,0x0
    800033b0:	e90080e7          	jalr	-368(ra) # 8000323c <balloc>
    800033b4:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    800033b8:	06090963          	beqz	s2,8000342a <bmap+0xaa>
        return 0;
      ip->addrs[bn] = addr;
    800033bc:	0524a823          	sw	s2,80(s1)
    800033c0:	a0ad                	j	8000342a <bmap+0xaa>
    }
    return addr;
  }
  bn -= NDIRECT;
    800033c2:	ff45849b          	addiw	s1,a1,-12
    800033c6:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    800033ca:	0ff00793          	li	a5,255
    800033ce:	08e7e863          	bltu	a5,a4,8000345e <bmap+0xde>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    800033d2:	08052903          	lw	s2,128(a0)
    800033d6:	00091f63          	bnez	s2,800033f4 <bmap+0x74>
      addr = balloc(ip->dev);
    800033da:	4108                	lw	a0,0(a0)
    800033dc:	00000097          	auipc	ra,0x0
    800033e0:	e60080e7          	jalr	-416(ra) # 8000323c <balloc>
    800033e4:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    800033e8:	04090163          	beqz	s2,8000342a <bmap+0xaa>
    800033ec:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    800033ee:	0929a023          	sw	s2,128(s3)
    800033f2:	a011                	j	800033f6 <bmap+0x76>
    800033f4:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    800033f6:	85ca                	mv	a1,s2
    800033f8:	0009a503          	lw	a0,0(s3)
    800033fc:	00000097          	auipc	ra,0x0
    80003400:	b80080e7          	jalr	-1152(ra) # 80002f7c <bread>
    80003404:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80003406:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    8000340a:	02049713          	slli	a4,s1,0x20
    8000340e:	01e75593          	srli	a1,a4,0x1e
    80003412:	00b784b3          	add	s1,a5,a1
    80003416:	0004a903          	lw	s2,0(s1)
    8000341a:	02090063          	beqz	s2,8000343a <bmap+0xba>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000341e:	8552                	mv	a0,s4
    80003420:	00000097          	auipc	ra,0x0
    80003424:	c8c080e7          	jalr	-884(ra) # 800030ac <brelse>
    return addr;
    80003428:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    8000342a:	854a                	mv	a0,s2
    8000342c:	70a2                	ld	ra,40(sp)
    8000342e:	7402                	ld	s0,32(sp)
    80003430:	64e2                	ld	s1,24(sp)
    80003432:	6942                	ld	s2,16(sp)
    80003434:	69a2                	ld	s3,8(sp)
    80003436:	6145                	addi	sp,sp,48
    80003438:	8082                	ret
      addr = balloc(ip->dev);
    8000343a:	0009a503          	lw	a0,0(s3)
    8000343e:	00000097          	auipc	ra,0x0
    80003442:	dfe080e7          	jalr	-514(ra) # 8000323c <balloc>
    80003446:	0005091b          	sext.w	s2,a0
      if(addr){
    8000344a:	fc090ae3          	beqz	s2,8000341e <bmap+0x9e>
        a[bn] = addr;
    8000344e:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    80003452:	8552                	mv	a0,s4
    80003454:	00001097          	auipc	ra,0x1
    80003458:	f02080e7          	jalr	-254(ra) # 80004356 <log_write>
    8000345c:	b7c9                	j	8000341e <bmap+0x9e>
    8000345e:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80003460:	00005517          	auipc	a0,0x5
    80003464:	01050513          	addi	a0,a0,16 # 80008470 <etext+0x470>
    80003468:	ffffd097          	auipc	ra,0xffffd
    8000346c:	0f8080e7          	jalr	248(ra) # 80000560 <panic>

0000000080003470 <iget>:
{
    80003470:	7179                	addi	sp,sp,-48
    80003472:	f406                	sd	ra,40(sp)
    80003474:	f022                	sd	s0,32(sp)
    80003476:	ec26                	sd	s1,24(sp)
    80003478:	e84a                	sd	s2,16(sp)
    8000347a:	e44e                	sd	s3,8(sp)
    8000347c:	e052                	sd	s4,0(sp)
    8000347e:	1800                	addi	s0,sp,48
    80003480:	89aa                	mv	s3,a0
    80003482:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80003484:	0001e517          	auipc	a0,0x1e
    80003488:	57c50513          	addi	a0,a0,1404 # 80021a00 <itable>
    8000348c:	ffffd097          	auipc	ra,0xffffd
    80003490:	7ac080e7          	jalr	1964(ra) # 80000c38 <acquire>
  empty = 0;
    80003494:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003496:	0001e497          	auipc	s1,0x1e
    8000349a:	58248493          	addi	s1,s1,1410 # 80021a18 <itable+0x18>
    8000349e:	00020697          	auipc	a3,0x20
    800034a2:	00a68693          	addi	a3,a3,10 # 800234a8 <log>
    800034a6:	a039                	j	800034b4 <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800034a8:	02090b63          	beqz	s2,800034de <iget+0x6e>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800034ac:	08848493          	addi	s1,s1,136
    800034b0:	02d48a63          	beq	s1,a3,800034e4 <iget+0x74>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800034b4:	449c                	lw	a5,8(s1)
    800034b6:	fef059e3          	blez	a5,800034a8 <iget+0x38>
    800034ba:	4098                	lw	a4,0(s1)
    800034bc:	ff3716e3          	bne	a4,s3,800034a8 <iget+0x38>
    800034c0:	40d8                	lw	a4,4(s1)
    800034c2:	ff4713e3          	bne	a4,s4,800034a8 <iget+0x38>
      ip->ref++;
    800034c6:	2785                	addiw	a5,a5,1
    800034c8:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800034ca:	0001e517          	auipc	a0,0x1e
    800034ce:	53650513          	addi	a0,a0,1334 # 80021a00 <itable>
    800034d2:	ffffe097          	auipc	ra,0xffffe
    800034d6:	81a080e7          	jalr	-2022(ra) # 80000cec <release>
      return ip;
    800034da:	8926                	mv	s2,s1
    800034dc:	a03d                	j	8000350a <iget+0x9a>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800034de:	f7f9                	bnez	a5,800034ac <iget+0x3c>
      empty = ip;
    800034e0:	8926                	mv	s2,s1
    800034e2:	b7e9                	j	800034ac <iget+0x3c>
  if(empty == 0)
    800034e4:	02090c63          	beqz	s2,8000351c <iget+0xac>
  ip->dev = dev;
    800034e8:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    800034ec:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    800034f0:	4785                	li	a5,1
    800034f2:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    800034f6:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    800034fa:	0001e517          	auipc	a0,0x1e
    800034fe:	50650513          	addi	a0,a0,1286 # 80021a00 <itable>
    80003502:	ffffd097          	auipc	ra,0xffffd
    80003506:	7ea080e7          	jalr	2026(ra) # 80000cec <release>
}
    8000350a:	854a                	mv	a0,s2
    8000350c:	70a2                	ld	ra,40(sp)
    8000350e:	7402                	ld	s0,32(sp)
    80003510:	64e2                	ld	s1,24(sp)
    80003512:	6942                	ld	s2,16(sp)
    80003514:	69a2                	ld	s3,8(sp)
    80003516:	6a02                	ld	s4,0(sp)
    80003518:	6145                	addi	sp,sp,48
    8000351a:	8082                	ret
    panic("iget: no inodes");
    8000351c:	00005517          	auipc	a0,0x5
    80003520:	f6c50513          	addi	a0,a0,-148 # 80008488 <etext+0x488>
    80003524:	ffffd097          	auipc	ra,0xffffd
    80003528:	03c080e7          	jalr	60(ra) # 80000560 <panic>

000000008000352c <fsinit>:
fsinit(int dev) {
    8000352c:	7179                	addi	sp,sp,-48
    8000352e:	f406                	sd	ra,40(sp)
    80003530:	f022                	sd	s0,32(sp)
    80003532:	ec26                	sd	s1,24(sp)
    80003534:	e84a                	sd	s2,16(sp)
    80003536:	e44e                	sd	s3,8(sp)
    80003538:	1800                	addi	s0,sp,48
    8000353a:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    8000353c:	4585                	li	a1,1
    8000353e:	00000097          	auipc	ra,0x0
    80003542:	a3e080e7          	jalr	-1474(ra) # 80002f7c <bread>
    80003546:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003548:	0001e997          	auipc	s3,0x1e
    8000354c:	49898993          	addi	s3,s3,1176 # 800219e0 <sb>
    80003550:	02000613          	li	a2,32
    80003554:	05850593          	addi	a1,a0,88
    80003558:	854e                	mv	a0,s3
    8000355a:	ffffe097          	auipc	ra,0xffffe
    8000355e:	836080e7          	jalr	-1994(ra) # 80000d90 <memmove>
  brelse(bp);
    80003562:	8526                	mv	a0,s1
    80003564:	00000097          	auipc	ra,0x0
    80003568:	b48080e7          	jalr	-1208(ra) # 800030ac <brelse>
  if(sb.magic != FSMAGIC)
    8000356c:	0009a703          	lw	a4,0(s3)
    80003570:	102037b7          	lui	a5,0x10203
    80003574:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003578:	02f71263          	bne	a4,a5,8000359c <fsinit+0x70>
  initlog(dev, &sb);
    8000357c:	0001e597          	auipc	a1,0x1e
    80003580:	46458593          	addi	a1,a1,1124 # 800219e0 <sb>
    80003584:	854a                	mv	a0,s2
    80003586:	00001097          	auipc	ra,0x1
    8000358a:	b60080e7          	jalr	-1184(ra) # 800040e6 <initlog>
}
    8000358e:	70a2                	ld	ra,40(sp)
    80003590:	7402                	ld	s0,32(sp)
    80003592:	64e2                	ld	s1,24(sp)
    80003594:	6942                	ld	s2,16(sp)
    80003596:	69a2                	ld	s3,8(sp)
    80003598:	6145                	addi	sp,sp,48
    8000359a:	8082                	ret
    panic("invalid file system");
    8000359c:	00005517          	auipc	a0,0x5
    800035a0:	efc50513          	addi	a0,a0,-260 # 80008498 <etext+0x498>
    800035a4:	ffffd097          	auipc	ra,0xffffd
    800035a8:	fbc080e7          	jalr	-68(ra) # 80000560 <panic>

00000000800035ac <iinit>:
{
    800035ac:	7179                	addi	sp,sp,-48
    800035ae:	f406                	sd	ra,40(sp)
    800035b0:	f022                	sd	s0,32(sp)
    800035b2:	ec26                	sd	s1,24(sp)
    800035b4:	e84a                	sd	s2,16(sp)
    800035b6:	e44e                	sd	s3,8(sp)
    800035b8:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800035ba:	00005597          	auipc	a1,0x5
    800035be:	ef658593          	addi	a1,a1,-266 # 800084b0 <etext+0x4b0>
    800035c2:	0001e517          	auipc	a0,0x1e
    800035c6:	43e50513          	addi	a0,a0,1086 # 80021a00 <itable>
    800035ca:	ffffd097          	auipc	ra,0xffffd
    800035ce:	5de080e7          	jalr	1502(ra) # 80000ba8 <initlock>
  for(i = 0; i < NINODE; i++) {
    800035d2:	0001e497          	auipc	s1,0x1e
    800035d6:	45648493          	addi	s1,s1,1110 # 80021a28 <itable+0x28>
    800035da:	00020997          	auipc	s3,0x20
    800035de:	ede98993          	addi	s3,s3,-290 # 800234b8 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800035e2:	00005917          	auipc	s2,0x5
    800035e6:	ed690913          	addi	s2,s2,-298 # 800084b8 <etext+0x4b8>
    800035ea:	85ca                	mv	a1,s2
    800035ec:	8526                	mv	a0,s1
    800035ee:	00001097          	auipc	ra,0x1
    800035f2:	e4c080e7          	jalr	-436(ra) # 8000443a <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800035f6:	08848493          	addi	s1,s1,136
    800035fa:	ff3498e3          	bne	s1,s3,800035ea <iinit+0x3e>
}
    800035fe:	70a2                	ld	ra,40(sp)
    80003600:	7402                	ld	s0,32(sp)
    80003602:	64e2                	ld	s1,24(sp)
    80003604:	6942                	ld	s2,16(sp)
    80003606:	69a2                	ld	s3,8(sp)
    80003608:	6145                	addi	sp,sp,48
    8000360a:	8082                	ret

000000008000360c <ialloc>:
{
    8000360c:	7139                	addi	sp,sp,-64
    8000360e:	fc06                	sd	ra,56(sp)
    80003610:	f822                	sd	s0,48(sp)
    80003612:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80003614:	0001e717          	auipc	a4,0x1e
    80003618:	3d872703          	lw	a4,984(a4) # 800219ec <sb+0xc>
    8000361c:	4785                	li	a5,1
    8000361e:	06e7f463          	bgeu	a5,a4,80003686 <ialloc+0x7a>
    80003622:	f426                	sd	s1,40(sp)
    80003624:	f04a                	sd	s2,32(sp)
    80003626:	ec4e                	sd	s3,24(sp)
    80003628:	e852                	sd	s4,16(sp)
    8000362a:	e456                	sd	s5,8(sp)
    8000362c:	e05a                	sd	s6,0(sp)
    8000362e:	8aaa                	mv	s5,a0
    80003630:	8b2e                	mv	s6,a1
    80003632:	4905                	li	s2,1
    bp = bread(dev, IBLOCK(inum, sb));
    80003634:	0001ea17          	auipc	s4,0x1e
    80003638:	3aca0a13          	addi	s4,s4,940 # 800219e0 <sb>
    8000363c:	00495593          	srli	a1,s2,0x4
    80003640:	018a2783          	lw	a5,24(s4)
    80003644:	9dbd                	addw	a1,a1,a5
    80003646:	8556                	mv	a0,s5
    80003648:	00000097          	auipc	ra,0x0
    8000364c:	934080e7          	jalr	-1740(ra) # 80002f7c <bread>
    80003650:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80003652:	05850993          	addi	s3,a0,88
    80003656:	00f97793          	andi	a5,s2,15
    8000365a:	079a                	slli	a5,a5,0x6
    8000365c:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    8000365e:	00099783          	lh	a5,0(s3)
    80003662:	cf9d                	beqz	a5,800036a0 <ialloc+0x94>
    brelse(bp);
    80003664:	00000097          	auipc	ra,0x0
    80003668:	a48080e7          	jalr	-1464(ra) # 800030ac <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    8000366c:	0905                	addi	s2,s2,1
    8000366e:	00ca2703          	lw	a4,12(s4)
    80003672:	0009079b          	sext.w	a5,s2
    80003676:	fce7e3e3          	bltu	a5,a4,8000363c <ialloc+0x30>
    8000367a:	74a2                	ld	s1,40(sp)
    8000367c:	7902                	ld	s2,32(sp)
    8000367e:	69e2                	ld	s3,24(sp)
    80003680:	6a42                	ld	s4,16(sp)
    80003682:	6aa2                	ld	s5,8(sp)
    80003684:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    80003686:	00005517          	auipc	a0,0x5
    8000368a:	e3a50513          	addi	a0,a0,-454 # 800084c0 <etext+0x4c0>
    8000368e:	ffffd097          	auipc	ra,0xffffd
    80003692:	f1c080e7          	jalr	-228(ra) # 800005aa <printf>
  return 0;
    80003696:	4501                	li	a0,0
}
    80003698:	70e2                	ld	ra,56(sp)
    8000369a:	7442                	ld	s0,48(sp)
    8000369c:	6121                	addi	sp,sp,64
    8000369e:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800036a0:	04000613          	li	a2,64
    800036a4:	4581                	li	a1,0
    800036a6:	854e                	mv	a0,s3
    800036a8:	ffffd097          	auipc	ra,0xffffd
    800036ac:	68c080e7          	jalr	1676(ra) # 80000d34 <memset>
      dip->type = type;
    800036b0:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    800036b4:	8526                	mv	a0,s1
    800036b6:	00001097          	auipc	ra,0x1
    800036ba:	ca0080e7          	jalr	-864(ra) # 80004356 <log_write>
      brelse(bp);
    800036be:	8526                	mv	a0,s1
    800036c0:	00000097          	auipc	ra,0x0
    800036c4:	9ec080e7          	jalr	-1556(ra) # 800030ac <brelse>
      return iget(dev, inum);
    800036c8:	0009059b          	sext.w	a1,s2
    800036cc:	8556                	mv	a0,s5
    800036ce:	00000097          	auipc	ra,0x0
    800036d2:	da2080e7          	jalr	-606(ra) # 80003470 <iget>
    800036d6:	74a2                	ld	s1,40(sp)
    800036d8:	7902                	ld	s2,32(sp)
    800036da:	69e2                	ld	s3,24(sp)
    800036dc:	6a42                	ld	s4,16(sp)
    800036de:	6aa2                	ld	s5,8(sp)
    800036e0:	6b02                	ld	s6,0(sp)
    800036e2:	bf5d                	j	80003698 <ialloc+0x8c>

00000000800036e4 <iupdate>:
{
    800036e4:	1101                	addi	sp,sp,-32
    800036e6:	ec06                	sd	ra,24(sp)
    800036e8:	e822                	sd	s0,16(sp)
    800036ea:	e426                	sd	s1,8(sp)
    800036ec:	e04a                	sd	s2,0(sp)
    800036ee:	1000                	addi	s0,sp,32
    800036f0:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800036f2:	415c                	lw	a5,4(a0)
    800036f4:	0047d79b          	srliw	a5,a5,0x4
    800036f8:	0001e597          	auipc	a1,0x1e
    800036fc:	3005a583          	lw	a1,768(a1) # 800219f8 <sb+0x18>
    80003700:	9dbd                	addw	a1,a1,a5
    80003702:	4108                	lw	a0,0(a0)
    80003704:	00000097          	auipc	ra,0x0
    80003708:	878080e7          	jalr	-1928(ra) # 80002f7c <bread>
    8000370c:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000370e:	05850793          	addi	a5,a0,88
    80003712:	40d8                	lw	a4,4(s1)
    80003714:	8b3d                	andi	a4,a4,15
    80003716:	071a                	slli	a4,a4,0x6
    80003718:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    8000371a:	04449703          	lh	a4,68(s1)
    8000371e:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80003722:	04649703          	lh	a4,70(s1)
    80003726:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    8000372a:	04849703          	lh	a4,72(s1)
    8000372e:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80003732:	04a49703          	lh	a4,74(s1)
    80003736:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    8000373a:	44f8                	lw	a4,76(s1)
    8000373c:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8000373e:	03400613          	li	a2,52
    80003742:	05048593          	addi	a1,s1,80
    80003746:	00c78513          	addi	a0,a5,12
    8000374a:	ffffd097          	auipc	ra,0xffffd
    8000374e:	646080e7          	jalr	1606(ra) # 80000d90 <memmove>
  log_write(bp);
    80003752:	854a                	mv	a0,s2
    80003754:	00001097          	auipc	ra,0x1
    80003758:	c02080e7          	jalr	-1022(ra) # 80004356 <log_write>
  brelse(bp);
    8000375c:	854a                	mv	a0,s2
    8000375e:	00000097          	auipc	ra,0x0
    80003762:	94e080e7          	jalr	-1714(ra) # 800030ac <brelse>
}
    80003766:	60e2                	ld	ra,24(sp)
    80003768:	6442                	ld	s0,16(sp)
    8000376a:	64a2                	ld	s1,8(sp)
    8000376c:	6902                	ld	s2,0(sp)
    8000376e:	6105                	addi	sp,sp,32
    80003770:	8082                	ret

0000000080003772 <idup>:
{
    80003772:	1101                	addi	sp,sp,-32
    80003774:	ec06                	sd	ra,24(sp)
    80003776:	e822                	sd	s0,16(sp)
    80003778:	e426                	sd	s1,8(sp)
    8000377a:	1000                	addi	s0,sp,32
    8000377c:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000377e:	0001e517          	auipc	a0,0x1e
    80003782:	28250513          	addi	a0,a0,642 # 80021a00 <itable>
    80003786:	ffffd097          	auipc	ra,0xffffd
    8000378a:	4b2080e7          	jalr	1202(ra) # 80000c38 <acquire>
  ip->ref++;
    8000378e:	449c                	lw	a5,8(s1)
    80003790:	2785                	addiw	a5,a5,1
    80003792:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003794:	0001e517          	auipc	a0,0x1e
    80003798:	26c50513          	addi	a0,a0,620 # 80021a00 <itable>
    8000379c:	ffffd097          	auipc	ra,0xffffd
    800037a0:	550080e7          	jalr	1360(ra) # 80000cec <release>
}
    800037a4:	8526                	mv	a0,s1
    800037a6:	60e2                	ld	ra,24(sp)
    800037a8:	6442                	ld	s0,16(sp)
    800037aa:	64a2                	ld	s1,8(sp)
    800037ac:	6105                	addi	sp,sp,32
    800037ae:	8082                	ret

00000000800037b0 <ilock>:
{
    800037b0:	1101                	addi	sp,sp,-32
    800037b2:	ec06                	sd	ra,24(sp)
    800037b4:	e822                	sd	s0,16(sp)
    800037b6:	e426                	sd	s1,8(sp)
    800037b8:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    800037ba:	c10d                	beqz	a0,800037dc <ilock+0x2c>
    800037bc:	84aa                	mv	s1,a0
    800037be:	451c                	lw	a5,8(a0)
    800037c0:	00f05e63          	blez	a5,800037dc <ilock+0x2c>
  acquiresleep(&ip->lock);
    800037c4:	0541                	addi	a0,a0,16
    800037c6:	00001097          	auipc	ra,0x1
    800037ca:	cae080e7          	jalr	-850(ra) # 80004474 <acquiresleep>
  if(ip->valid == 0){
    800037ce:	40bc                	lw	a5,64(s1)
    800037d0:	cf99                	beqz	a5,800037ee <ilock+0x3e>
}
    800037d2:	60e2                	ld	ra,24(sp)
    800037d4:	6442                	ld	s0,16(sp)
    800037d6:	64a2                	ld	s1,8(sp)
    800037d8:	6105                	addi	sp,sp,32
    800037da:	8082                	ret
    800037dc:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800037de:	00005517          	auipc	a0,0x5
    800037e2:	cfa50513          	addi	a0,a0,-774 # 800084d8 <etext+0x4d8>
    800037e6:	ffffd097          	auipc	ra,0xffffd
    800037ea:	d7a080e7          	jalr	-646(ra) # 80000560 <panic>
    800037ee:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800037f0:	40dc                	lw	a5,4(s1)
    800037f2:	0047d79b          	srliw	a5,a5,0x4
    800037f6:	0001e597          	auipc	a1,0x1e
    800037fa:	2025a583          	lw	a1,514(a1) # 800219f8 <sb+0x18>
    800037fe:	9dbd                	addw	a1,a1,a5
    80003800:	4088                	lw	a0,0(s1)
    80003802:	fffff097          	auipc	ra,0xfffff
    80003806:	77a080e7          	jalr	1914(ra) # 80002f7c <bread>
    8000380a:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000380c:	05850593          	addi	a1,a0,88
    80003810:	40dc                	lw	a5,4(s1)
    80003812:	8bbd                	andi	a5,a5,15
    80003814:	079a                	slli	a5,a5,0x6
    80003816:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003818:	00059783          	lh	a5,0(a1)
    8000381c:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80003820:	00259783          	lh	a5,2(a1)
    80003824:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003828:	00459783          	lh	a5,4(a1)
    8000382c:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80003830:	00659783          	lh	a5,6(a1)
    80003834:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003838:	459c                	lw	a5,8(a1)
    8000383a:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    8000383c:	03400613          	li	a2,52
    80003840:	05b1                	addi	a1,a1,12
    80003842:	05048513          	addi	a0,s1,80
    80003846:	ffffd097          	auipc	ra,0xffffd
    8000384a:	54a080e7          	jalr	1354(ra) # 80000d90 <memmove>
    brelse(bp);
    8000384e:	854a                	mv	a0,s2
    80003850:	00000097          	auipc	ra,0x0
    80003854:	85c080e7          	jalr	-1956(ra) # 800030ac <brelse>
    ip->valid = 1;
    80003858:	4785                	li	a5,1
    8000385a:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    8000385c:	04449783          	lh	a5,68(s1)
    80003860:	c399                	beqz	a5,80003866 <ilock+0xb6>
    80003862:	6902                	ld	s2,0(sp)
    80003864:	b7bd                	j	800037d2 <ilock+0x22>
      panic("ilock: no type");
    80003866:	00005517          	auipc	a0,0x5
    8000386a:	c7a50513          	addi	a0,a0,-902 # 800084e0 <etext+0x4e0>
    8000386e:	ffffd097          	auipc	ra,0xffffd
    80003872:	cf2080e7          	jalr	-782(ra) # 80000560 <panic>

0000000080003876 <iunlock>:
{
    80003876:	1101                	addi	sp,sp,-32
    80003878:	ec06                	sd	ra,24(sp)
    8000387a:	e822                	sd	s0,16(sp)
    8000387c:	e426                	sd	s1,8(sp)
    8000387e:	e04a                	sd	s2,0(sp)
    80003880:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003882:	c905                	beqz	a0,800038b2 <iunlock+0x3c>
    80003884:	84aa                	mv	s1,a0
    80003886:	01050913          	addi	s2,a0,16
    8000388a:	854a                	mv	a0,s2
    8000388c:	00001097          	auipc	ra,0x1
    80003890:	c82080e7          	jalr	-894(ra) # 8000450e <holdingsleep>
    80003894:	cd19                	beqz	a0,800038b2 <iunlock+0x3c>
    80003896:	449c                	lw	a5,8(s1)
    80003898:	00f05d63          	blez	a5,800038b2 <iunlock+0x3c>
  releasesleep(&ip->lock);
    8000389c:	854a                	mv	a0,s2
    8000389e:	00001097          	auipc	ra,0x1
    800038a2:	c2c080e7          	jalr	-980(ra) # 800044ca <releasesleep>
}
    800038a6:	60e2                	ld	ra,24(sp)
    800038a8:	6442                	ld	s0,16(sp)
    800038aa:	64a2                	ld	s1,8(sp)
    800038ac:	6902                	ld	s2,0(sp)
    800038ae:	6105                	addi	sp,sp,32
    800038b0:	8082                	ret
    panic("iunlock");
    800038b2:	00005517          	auipc	a0,0x5
    800038b6:	c3e50513          	addi	a0,a0,-962 # 800084f0 <etext+0x4f0>
    800038ba:	ffffd097          	auipc	ra,0xffffd
    800038be:	ca6080e7          	jalr	-858(ra) # 80000560 <panic>

00000000800038c2 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800038c2:	7179                	addi	sp,sp,-48
    800038c4:	f406                	sd	ra,40(sp)
    800038c6:	f022                	sd	s0,32(sp)
    800038c8:	ec26                	sd	s1,24(sp)
    800038ca:	e84a                	sd	s2,16(sp)
    800038cc:	e44e                	sd	s3,8(sp)
    800038ce:	1800                	addi	s0,sp,48
    800038d0:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    800038d2:	05050493          	addi	s1,a0,80
    800038d6:	08050913          	addi	s2,a0,128
    800038da:	a021                	j	800038e2 <itrunc+0x20>
    800038dc:	0491                	addi	s1,s1,4
    800038de:	01248d63          	beq	s1,s2,800038f8 <itrunc+0x36>
    if(ip->addrs[i]){
    800038e2:	408c                	lw	a1,0(s1)
    800038e4:	dde5                	beqz	a1,800038dc <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    800038e6:	0009a503          	lw	a0,0(s3)
    800038ea:	00000097          	auipc	ra,0x0
    800038ee:	8d6080e7          	jalr	-1834(ra) # 800031c0 <bfree>
      ip->addrs[i] = 0;
    800038f2:	0004a023          	sw	zero,0(s1)
    800038f6:	b7dd                	j	800038dc <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    800038f8:	0809a583          	lw	a1,128(s3)
    800038fc:	ed99                	bnez	a1,8000391a <itrunc+0x58>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800038fe:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003902:	854e                	mv	a0,s3
    80003904:	00000097          	auipc	ra,0x0
    80003908:	de0080e7          	jalr	-544(ra) # 800036e4 <iupdate>
}
    8000390c:	70a2                	ld	ra,40(sp)
    8000390e:	7402                	ld	s0,32(sp)
    80003910:	64e2                	ld	s1,24(sp)
    80003912:	6942                	ld	s2,16(sp)
    80003914:	69a2                	ld	s3,8(sp)
    80003916:	6145                	addi	sp,sp,48
    80003918:	8082                	ret
    8000391a:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    8000391c:	0009a503          	lw	a0,0(s3)
    80003920:	fffff097          	auipc	ra,0xfffff
    80003924:	65c080e7          	jalr	1628(ra) # 80002f7c <bread>
    80003928:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    8000392a:	05850493          	addi	s1,a0,88
    8000392e:	45850913          	addi	s2,a0,1112
    80003932:	a021                	j	8000393a <itrunc+0x78>
    80003934:	0491                	addi	s1,s1,4
    80003936:	01248b63          	beq	s1,s2,8000394c <itrunc+0x8a>
      if(a[j])
    8000393a:	408c                	lw	a1,0(s1)
    8000393c:	dde5                	beqz	a1,80003934 <itrunc+0x72>
        bfree(ip->dev, a[j]);
    8000393e:	0009a503          	lw	a0,0(s3)
    80003942:	00000097          	auipc	ra,0x0
    80003946:	87e080e7          	jalr	-1922(ra) # 800031c0 <bfree>
    8000394a:	b7ed                	j	80003934 <itrunc+0x72>
    brelse(bp);
    8000394c:	8552                	mv	a0,s4
    8000394e:	fffff097          	auipc	ra,0xfffff
    80003952:	75e080e7          	jalr	1886(ra) # 800030ac <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003956:	0809a583          	lw	a1,128(s3)
    8000395a:	0009a503          	lw	a0,0(s3)
    8000395e:	00000097          	auipc	ra,0x0
    80003962:	862080e7          	jalr	-1950(ra) # 800031c0 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003966:	0809a023          	sw	zero,128(s3)
    8000396a:	6a02                	ld	s4,0(sp)
    8000396c:	bf49                	j	800038fe <itrunc+0x3c>

000000008000396e <iput>:
{
    8000396e:	1101                	addi	sp,sp,-32
    80003970:	ec06                	sd	ra,24(sp)
    80003972:	e822                	sd	s0,16(sp)
    80003974:	e426                	sd	s1,8(sp)
    80003976:	1000                	addi	s0,sp,32
    80003978:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000397a:	0001e517          	auipc	a0,0x1e
    8000397e:	08650513          	addi	a0,a0,134 # 80021a00 <itable>
    80003982:	ffffd097          	auipc	ra,0xffffd
    80003986:	2b6080e7          	jalr	694(ra) # 80000c38 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    8000398a:	4498                	lw	a4,8(s1)
    8000398c:	4785                	li	a5,1
    8000398e:	02f70263          	beq	a4,a5,800039b2 <iput+0x44>
  ip->ref--;
    80003992:	449c                	lw	a5,8(s1)
    80003994:	37fd                	addiw	a5,a5,-1
    80003996:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003998:	0001e517          	auipc	a0,0x1e
    8000399c:	06850513          	addi	a0,a0,104 # 80021a00 <itable>
    800039a0:	ffffd097          	auipc	ra,0xffffd
    800039a4:	34c080e7          	jalr	844(ra) # 80000cec <release>
}
    800039a8:	60e2                	ld	ra,24(sp)
    800039aa:	6442                	ld	s0,16(sp)
    800039ac:	64a2                	ld	s1,8(sp)
    800039ae:	6105                	addi	sp,sp,32
    800039b0:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800039b2:	40bc                	lw	a5,64(s1)
    800039b4:	dff9                	beqz	a5,80003992 <iput+0x24>
    800039b6:	04a49783          	lh	a5,74(s1)
    800039ba:	ffe1                	bnez	a5,80003992 <iput+0x24>
    800039bc:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    800039be:	01048913          	addi	s2,s1,16
    800039c2:	854a                	mv	a0,s2
    800039c4:	00001097          	auipc	ra,0x1
    800039c8:	ab0080e7          	jalr	-1360(ra) # 80004474 <acquiresleep>
    release(&itable.lock);
    800039cc:	0001e517          	auipc	a0,0x1e
    800039d0:	03450513          	addi	a0,a0,52 # 80021a00 <itable>
    800039d4:	ffffd097          	auipc	ra,0xffffd
    800039d8:	318080e7          	jalr	792(ra) # 80000cec <release>
    itrunc(ip);
    800039dc:	8526                	mv	a0,s1
    800039de:	00000097          	auipc	ra,0x0
    800039e2:	ee4080e7          	jalr	-284(ra) # 800038c2 <itrunc>
    ip->type = 0;
    800039e6:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    800039ea:	8526                	mv	a0,s1
    800039ec:	00000097          	auipc	ra,0x0
    800039f0:	cf8080e7          	jalr	-776(ra) # 800036e4 <iupdate>
    ip->valid = 0;
    800039f4:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    800039f8:	854a                	mv	a0,s2
    800039fa:	00001097          	auipc	ra,0x1
    800039fe:	ad0080e7          	jalr	-1328(ra) # 800044ca <releasesleep>
    acquire(&itable.lock);
    80003a02:	0001e517          	auipc	a0,0x1e
    80003a06:	ffe50513          	addi	a0,a0,-2 # 80021a00 <itable>
    80003a0a:	ffffd097          	auipc	ra,0xffffd
    80003a0e:	22e080e7          	jalr	558(ra) # 80000c38 <acquire>
    80003a12:	6902                	ld	s2,0(sp)
    80003a14:	bfbd                	j	80003992 <iput+0x24>

0000000080003a16 <iunlockput>:
{
    80003a16:	1101                	addi	sp,sp,-32
    80003a18:	ec06                	sd	ra,24(sp)
    80003a1a:	e822                	sd	s0,16(sp)
    80003a1c:	e426                	sd	s1,8(sp)
    80003a1e:	1000                	addi	s0,sp,32
    80003a20:	84aa                	mv	s1,a0
  iunlock(ip);
    80003a22:	00000097          	auipc	ra,0x0
    80003a26:	e54080e7          	jalr	-428(ra) # 80003876 <iunlock>
  iput(ip);
    80003a2a:	8526                	mv	a0,s1
    80003a2c:	00000097          	auipc	ra,0x0
    80003a30:	f42080e7          	jalr	-190(ra) # 8000396e <iput>
}
    80003a34:	60e2                	ld	ra,24(sp)
    80003a36:	6442                	ld	s0,16(sp)
    80003a38:	64a2                	ld	s1,8(sp)
    80003a3a:	6105                	addi	sp,sp,32
    80003a3c:	8082                	ret

0000000080003a3e <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003a3e:	1141                	addi	sp,sp,-16
    80003a40:	e422                	sd	s0,8(sp)
    80003a42:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003a44:	411c                	lw	a5,0(a0)
    80003a46:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003a48:	415c                	lw	a5,4(a0)
    80003a4a:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003a4c:	04451783          	lh	a5,68(a0)
    80003a50:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003a54:	04a51783          	lh	a5,74(a0)
    80003a58:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003a5c:	04c56783          	lwu	a5,76(a0)
    80003a60:	e99c                	sd	a5,16(a1)
}
    80003a62:	6422                	ld	s0,8(sp)
    80003a64:	0141                	addi	sp,sp,16
    80003a66:	8082                	ret

0000000080003a68 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003a68:	457c                	lw	a5,76(a0)
    80003a6a:	10d7e563          	bltu	a5,a3,80003b74 <readi+0x10c>
{
    80003a6e:	7159                	addi	sp,sp,-112
    80003a70:	f486                	sd	ra,104(sp)
    80003a72:	f0a2                	sd	s0,96(sp)
    80003a74:	eca6                	sd	s1,88(sp)
    80003a76:	e0d2                	sd	s4,64(sp)
    80003a78:	fc56                	sd	s5,56(sp)
    80003a7a:	f85a                	sd	s6,48(sp)
    80003a7c:	f45e                	sd	s7,40(sp)
    80003a7e:	1880                	addi	s0,sp,112
    80003a80:	8b2a                	mv	s6,a0
    80003a82:	8bae                	mv	s7,a1
    80003a84:	8a32                	mv	s4,a2
    80003a86:	84b6                	mv	s1,a3
    80003a88:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003a8a:	9f35                	addw	a4,a4,a3
    return 0;
    80003a8c:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80003a8e:	0cd76a63          	bltu	a4,a3,80003b62 <readi+0xfa>
    80003a92:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80003a94:	00e7f463          	bgeu	a5,a4,80003a9c <readi+0x34>
    n = ip->size - off;
    80003a98:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003a9c:	0a0a8963          	beqz	s5,80003b4e <readi+0xe6>
    80003aa0:	e8ca                	sd	s2,80(sp)
    80003aa2:	f062                	sd	s8,32(sp)
    80003aa4:	ec66                	sd	s9,24(sp)
    80003aa6:	e86a                	sd	s10,16(sp)
    80003aa8:	e46e                	sd	s11,8(sp)
    80003aaa:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003aac:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003ab0:	5c7d                	li	s8,-1
    80003ab2:	a82d                	j	80003aec <readi+0x84>
    80003ab4:	020d1d93          	slli	s11,s10,0x20
    80003ab8:	020ddd93          	srli	s11,s11,0x20
    80003abc:	05890613          	addi	a2,s2,88
    80003ac0:	86ee                	mv	a3,s11
    80003ac2:	963a                	add	a2,a2,a4
    80003ac4:	85d2                	mv	a1,s4
    80003ac6:	855e                	mv	a0,s7
    80003ac8:	fffff097          	auipc	ra,0xfffff
    80003acc:	a4c080e7          	jalr	-1460(ra) # 80002514 <either_copyout>
    80003ad0:	05850d63          	beq	a0,s8,80003b2a <readi+0xc2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003ad4:	854a                	mv	a0,s2
    80003ad6:	fffff097          	auipc	ra,0xfffff
    80003ada:	5d6080e7          	jalr	1494(ra) # 800030ac <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003ade:	013d09bb          	addw	s3,s10,s3
    80003ae2:	009d04bb          	addw	s1,s10,s1
    80003ae6:	9a6e                	add	s4,s4,s11
    80003ae8:	0559fd63          	bgeu	s3,s5,80003b42 <readi+0xda>
    uint addr = bmap(ip, off/BSIZE);
    80003aec:	00a4d59b          	srliw	a1,s1,0xa
    80003af0:	855a                	mv	a0,s6
    80003af2:	00000097          	auipc	ra,0x0
    80003af6:	88e080e7          	jalr	-1906(ra) # 80003380 <bmap>
    80003afa:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003afe:	c9b1                	beqz	a1,80003b52 <readi+0xea>
    bp = bread(ip->dev, addr);
    80003b00:	000b2503          	lw	a0,0(s6)
    80003b04:	fffff097          	auipc	ra,0xfffff
    80003b08:	478080e7          	jalr	1144(ra) # 80002f7c <bread>
    80003b0c:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003b0e:	3ff4f713          	andi	a4,s1,1023
    80003b12:	40ec87bb          	subw	a5,s9,a4
    80003b16:	413a86bb          	subw	a3,s5,s3
    80003b1a:	8d3e                	mv	s10,a5
    80003b1c:	2781                	sext.w	a5,a5
    80003b1e:	0006861b          	sext.w	a2,a3
    80003b22:	f8f679e3          	bgeu	a2,a5,80003ab4 <readi+0x4c>
    80003b26:	8d36                	mv	s10,a3
    80003b28:	b771                	j	80003ab4 <readi+0x4c>
      brelse(bp);
    80003b2a:	854a                	mv	a0,s2
    80003b2c:	fffff097          	auipc	ra,0xfffff
    80003b30:	580080e7          	jalr	1408(ra) # 800030ac <brelse>
      tot = -1;
    80003b34:	59fd                	li	s3,-1
      break;
    80003b36:	6946                	ld	s2,80(sp)
    80003b38:	7c02                	ld	s8,32(sp)
    80003b3a:	6ce2                	ld	s9,24(sp)
    80003b3c:	6d42                	ld	s10,16(sp)
    80003b3e:	6da2                	ld	s11,8(sp)
    80003b40:	a831                	j	80003b5c <readi+0xf4>
    80003b42:	6946                	ld	s2,80(sp)
    80003b44:	7c02                	ld	s8,32(sp)
    80003b46:	6ce2                	ld	s9,24(sp)
    80003b48:	6d42                	ld	s10,16(sp)
    80003b4a:	6da2                	ld	s11,8(sp)
    80003b4c:	a801                	j	80003b5c <readi+0xf4>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003b4e:	89d6                	mv	s3,s5
    80003b50:	a031                	j	80003b5c <readi+0xf4>
    80003b52:	6946                	ld	s2,80(sp)
    80003b54:	7c02                	ld	s8,32(sp)
    80003b56:	6ce2                	ld	s9,24(sp)
    80003b58:	6d42                	ld	s10,16(sp)
    80003b5a:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003b5c:	0009851b          	sext.w	a0,s3
    80003b60:	69a6                	ld	s3,72(sp)
}
    80003b62:	70a6                	ld	ra,104(sp)
    80003b64:	7406                	ld	s0,96(sp)
    80003b66:	64e6                	ld	s1,88(sp)
    80003b68:	6a06                	ld	s4,64(sp)
    80003b6a:	7ae2                	ld	s5,56(sp)
    80003b6c:	7b42                	ld	s6,48(sp)
    80003b6e:	7ba2                	ld	s7,40(sp)
    80003b70:	6165                	addi	sp,sp,112
    80003b72:	8082                	ret
    return 0;
    80003b74:	4501                	li	a0,0
}
    80003b76:	8082                	ret

0000000080003b78 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003b78:	457c                	lw	a5,76(a0)
    80003b7a:	10d7ee63          	bltu	a5,a3,80003c96 <writei+0x11e>
{
    80003b7e:	7159                	addi	sp,sp,-112
    80003b80:	f486                	sd	ra,104(sp)
    80003b82:	f0a2                	sd	s0,96(sp)
    80003b84:	e8ca                	sd	s2,80(sp)
    80003b86:	e0d2                	sd	s4,64(sp)
    80003b88:	fc56                	sd	s5,56(sp)
    80003b8a:	f85a                	sd	s6,48(sp)
    80003b8c:	f45e                	sd	s7,40(sp)
    80003b8e:	1880                	addi	s0,sp,112
    80003b90:	8aaa                	mv	s5,a0
    80003b92:	8bae                	mv	s7,a1
    80003b94:	8a32                	mv	s4,a2
    80003b96:	8936                	mv	s2,a3
    80003b98:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003b9a:	00e687bb          	addw	a5,a3,a4
    80003b9e:	0ed7ee63          	bltu	a5,a3,80003c9a <writei+0x122>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80003ba2:	00043737          	lui	a4,0x43
    80003ba6:	0ef76c63          	bltu	a4,a5,80003c9e <writei+0x126>
    80003baa:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003bac:	0c0b0d63          	beqz	s6,80003c86 <writei+0x10e>
    80003bb0:	eca6                	sd	s1,88(sp)
    80003bb2:	f062                	sd	s8,32(sp)
    80003bb4:	ec66                	sd	s9,24(sp)
    80003bb6:	e86a                	sd	s10,16(sp)
    80003bb8:	e46e                	sd	s11,8(sp)
    80003bba:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003bbc:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003bc0:	5c7d                	li	s8,-1
    80003bc2:	a091                	j	80003c06 <writei+0x8e>
    80003bc4:	020d1d93          	slli	s11,s10,0x20
    80003bc8:	020ddd93          	srli	s11,s11,0x20
    80003bcc:	05848513          	addi	a0,s1,88
    80003bd0:	86ee                	mv	a3,s11
    80003bd2:	8652                	mv	a2,s4
    80003bd4:	85de                	mv	a1,s7
    80003bd6:	953a                	add	a0,a0,a4
    80003bd8:	fffff097          	auipc	ra,0xfffff
    80003bdc:	992080e7          	jalr	-1646(ra) # 8000256a <either_copyin>
    80003be0:	07850263          	beq	a0,s8,80003c44 <writei+0xcc>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003be4:	8526                	mv	a0,s1
    80003be6:	00000097          	auipc	ra,0x0
    80003bea:	770080e7          	jalr	1904(ra) # 80004356 <log_write>
    brelse(bp);
    80003bee:	8526                	mv	a0,s1
    80003bf0:	fffff097          	auipc	ra,0xfffff
    80003bf4:	4bc080e7          	jalr	1212(ra) # 800030ac <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003bf8:	013d09bb          	addw	s3,s10,s3
    80003bfc:	012d093b          	addw	s2,s10,s2
    80003c00:	9a6e                	add	s4,s4,s11
    80003c02:	0569f663          	bgeu	s3,s6,80003c4e <writei+0xd6>
    uint addr = bmap(ip, off/BSIZE);
    80003c06:	00a9559b          	srliw	a1,s2,0xa
    80003c0a:	8556                	mv	a0,s5
    80003c0c:	fffff097          	auipc	ra,0xfffff
    80003c10:	774080e7          	jalr	1908(ra) # 80003380 <bmap>
    80003c14:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003c18:	c99d                	beqz	a1,80003c4e <writei+0xd6>
    bp = bread(ip->dev, addr);
    80003c1a:	000aa503          	lw	a0,0(s5)
    80003c1e:	fffff097          	auipc	ra,0xfffff
    80003c22:	35e080e7          	jalr	862(ra) # 80002f7c <bread>
    80003c26:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003c28:	3ff97713          	andi	a4,s2,1023
    80003c2c:	40ec87bb          	subw	a5,s9,a4
    80003c30:	413b06bb          	subw	a3,s6,s3
    80003c34:	8d3e                	mv	s10,a5
    80003c36:	2781                	sext.w	a5,a5
    80003c38:	0006861b          	sext.w	a2,a3
    80003c3c:	f8f674e3          	bgeu	a2,a5,80003bc4 <writei+0x4c>
    80003c40:	8d36                	mv	s10,a3
    80003c42:	b749                	j	80003bc4 <writei+0x4c>
      brelse(bp);
    80003c44:	8526                	mv	a0,s1
    80003c46:	fffff097          	auipc	ra,0xfffff
    80003c4a:	466080e7          	jalr	1126(ra) # 800030ac <brelse>
  }

  if(off > ip->size)
    80003c4e:	04caa783          	lw	a5,76(s5)
    80003c52:	0327fc63          	bgeu	a5,s2,80003c8a <writei+0x112>
    ip->size = off;
    80003c56:	052aa623          	sw	s2,76(s5)
    80003c5a:	64e6                	ld	s1,88(sp)
    80003c5c:	7c02                	ld	s8,32(sp)
    80003c5e:	6ce2                	ld	s9,24(sp)
    80003c60:	6d42                	ld	s10,16(sp)
    80003c62:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003c64:	8556                	mv	a0,s5
    80003c66:	00000097          	auipc	ra,0x0
    80003c6a:	a7e080e7          	jalr	-1410(ra) # 800036e4 <iupdate>

  return tot;
    80003c6e:	0009851b          	sext.w	a0,s3
    80003c72:	69a6                	ld	s3,72(sp)
}
    80003c74:	70a6                	ld	ra,104(sp)
    80003c76:	7406                	ld	s0,96(sp)
    80003c78:	6946                	ld	s2,80(sp)
    80003c7a:	6a06                	ld	s4,64(sp)
    80003c7c:	7ae2                	ld	s5,56(sp)
    80003c7e:	7b42                	ld	s6,48(sp)
    80003c80:	7ba2                	ld	s7,40(sp)
    80003c82:	6165                	addi	sp,sp,112
    80003c84:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003c86:	89da                	mv	s3,s6
    80003c88:	bff1                	j	80003c64 <writei+0xec>
    80003c8a:	64e6                	ld	s1,88(sp)
    80003c8c:	7c02                	ld	s8,32(sp)
    80003c8e:	6ce2                	ld	s9,24(sp)
    80003c90:	6d42                	ld	s10,16(sp)
    80003c92:	6da2                	ld	s11,8(sp)
    80003c94:	bfc1                	j	80003c64 <writei+0xec>
    return -1;
    80003c96:	557d                	li	a0,-1
}
    80003c98:	8082                	ret
    return -1;
    80003c9a:	557d                	li	a0,-1
    80003c9c:	bfe1                	j	80003c74 <writei+0xfc>
    return -1;
    80003c9e:	557d                	li	a0,-1
    80003ca0:	bfd1                	j	80003c74 <writei+0xfc>

0000000080003ca2 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003ca2:	1141                	addi	sp,sp,-16
    80003ca4:	e406                	sd	ra,8(sp)
    80003ca6:	e022                	sd	s0,0(sp)
    80003ca8:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003caa:	4639                	li	a2,14
    80003cac:	ffffd097          	auipc	ra,0xffffd
    80003cb0:	158080e7          	jalr	344(ra) # 80000e04 <strncmp>
}
    80003cb4:	60a2                	ld	ra,8(sp)
    80003cb6:	6402                	ld	s0,0(sp)
    80003cb8:	0141                	addi	sp,sp,16
    80003cba:	8082                	ret

0000000080003cbc <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003cbc:	7139                	addi	sp,sp,-64
    80003cbe:	fc06                	sd	ra,56(sp)
    80003cc0:	f822                	sd	s0,48(sp)
    80003cc2:	f426                	sd	s1,40(sp)
    80003cc4:	f04a                	sd	s2,32(sp)
    80003cc6:	ec4e                	sd	s3,24(sp)
    80003cc8:	e852                	sd	s4,16(sp)
    80003cca:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003ccc:	04451703          	lh	a4,68(a0)
    80003cd0:	4785                	li	a5,1
    80003cd2:	00f71a63          	bne	a4,a5,80003ce6 <dirlookup+0x2a>
    80003cd6:	892a                	mv	s2,a0
    80003cd8:	89ae                	mv	s3,a1
    80003cda:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003cdc:	457c                	lw	a5,76(a0)
    80003cde:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003ce0:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003ce2:	e79d                	bnez	a5,80003d10 <dirlookup+0x54>
    80003ce4:	a8a5                	j	80003d5c <dirlookup+0xa0>
    panic("dirlookup not DIR");
    80003ce6:	00005517          	auipc	a0,0x5
    80003cea:	81250513          	addi	a0,a0,-2030 # 800084f8 <etext+0x4f8>
    80003cee:	ffffd097          	auipc	ra,0xffffd
    80003cf2:	872080e7          	jalr	-1934(ra) # 80000560 <panic>
      panic("dirlookup read");
    80003cf6:	00005517          	auipc	a0,0x5
    80003cfa:	81a50513          	addi	a0,a0,-2022 # 80008510 <etext+0x510>
    80003cfe:	ffffd097          	auipc	ra,0xffffd
    80003d02:	862080e7          	jalr	-1950(ra) # 80000560 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003d06:	24c1                	addiw	s1,s1,16
    80003d08:	04c92783          	lw	a5,76(s2)
    80003d0c:	04f4f763          	bgeu	s1,a5,80003d5a <dirlookup+0x9e>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003d10:	4741                	li	a4,16
    80003d12:	86a6                	mv	a3,s1
    80003d14:	fc040613          	addi	a2,s0,-64
    80003d18:	4581                	li	a1,0
    80003d1a:	854a                	mv	a0,s2
    80003d1c:	00000097          	auipc	ra,0x0
    80003d20:	d4c080e7          	jalr	-692(ra) # 80003a68 <readi>
    80003d24:	47c1                	li	a5,16
    80003d26:	fcf518e3          	bne	a0,a5,80003cf6 <dirlookup+0x3a>
    if(de.inum == 0)
    80003d2a:	fc045783          	lhu	a5,-64(s0)
    80003d2e:	dfe1                	beqz	a5,80003d06 <dirlookup+0x4a>
    if(namecmp(name, de.name) == 0){
    80003d30:	fc240593          	addi	a1,s0,-62
    80003d34:	854e                	mv	a0,s3
    80003d36:	00000097          	auipc	ra,0x0
    80003d3a:	f6c080e7          	jalr	-148(ra) # 80003ca2 <namecmp>
    80003d3e:	f561                	bnez	a0,80003d06 <dirlookup+0x4a>
      if(poff)
    80003d40:	000a0463          	beqz	s4,80003d48 <dirlookup+0x8c>
        *poff = off;
    80003d44:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003d48:	fc045583          	lhu	a1,-64(s0)
    80003d4c:	00092503          	lw	a0,0(s2)
    80003d50:	fffff097          	auipc	ra,0xfffff
    80003d54:	720080e7          	jalr	1824(ra) # 80003470 <iget>
    80003d58:	a011                	j	80003d5c <dirlookup+0xa0>
  return 0;
    80003d5a:	4501                	li	a0,0
}
    80003d5c:	70e2                	ld	ra,56(sp)
    80003d5e:	7442                	ld	s0,48(sp)
    80003d60:	74a2                	ld	s1,40(sp)
    80003d62:	7902                	ld	s2,32(sp)
    80003d64:	69e2                	ld	s3,24(sp)
    80003d66:	6a42                	ld	s4,16(sp)
    80003d68:	6121                	addi	sp,sp,64
    80003d6a:	8082                	ret

0000000080003d6c <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003d6c:	711d                	addi	sp,sp,-96
    80003d6e:	ec86                	sd	ra,88(sp)
    80003d70:	e8a2                	sd	s0,80(sp)
    80003d72:	e4a6                	sd	s1,72(sp)
    80003d74:	e0ca                	sd	s2,64(sp)
    80003d76:	fc4e                	sd	s3,56(sp)
    80003d78:	f852                	sd	s4,48(sp)
    80003d7a:	f456                	sd	s5,40(sp)
    80003d7c:	f05a                	sd	s6,32(sp)
    80003d7e:	ec5e                	sd	s7,24(sp)
    80003d80:	e862                	sd	s8,16(sp)
    80003d82:	e466                	sd	s9,8(sp)
    80003d84:	1080                	addi	s0,sp,96
    80003d86:	84aa                	mv	s1,a0
    80003d88:	8b2e                	mv	s6,a1
    80003d8a:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003d8c:	00054703          	lbu	a4,0(a0)
    80003d90:	02f00793          	li	a5,47
    80003d94:	02f70263          	beq	a4,a5,80003db8 <namex+0x4c>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003d98:	ffffe097          	auipc	ra,0xffffe
    80003d9c:	cca080e7          	jalr	-822(ra) # 80001a62 <myproc>
    80003da0:	15053503          	ld	a0,336(a0)
    80003da4:	00000097          	auipc	ra,0x0
    80003da8:	9ce080e7          	jalr	-1586(ra) # 80003772 <idup>
    80003dac:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003dae:	02f00913          	li	s2,47
  if(len >= DIRSIZ)
    80003db2:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003db4:	4b85                	li	s7,1
    80003db6:	a875                	j	80003e72 <namex+0x106>
    ip = iget(ROOTDEV, ROOTINO);
    80003db8:	4585                	li	a1,1
    80003dba:	4505                	li	a0,1
    80003dbc:	fffff097          	auipc	ra,0xfffff
    80003dc0:	6b4080e7          	jalr	1716(ra) # 80003470 <iget>
    80003dc4:	8a2a                	mv	s4,a0
    80003dc6:	b7e5                	j	80003dae <namex+0x42>
      iunlockput(ip);
    80003dc8:	8552                	mv	a0,s4
    80003dca:	00000097          	auipc	ra,0x0
    80003dce:	c4c080e7          	jalr	-948(ra) # 80003a16 <iunlockput>
      return 0;
    80003dd2:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003dd4:	8552                	mv	a0,s4
    80003dd6:	60e6                	ld	ra,88(sp)
    80003dd8:	6446                	ld	s0,80(sp)
    80003dda:	64a6                	ld	s1,72(sp)
    80003ddc:	6906                	ld	s2,64(sp)
    80003dde:	79e2                	ld	s3,56(sp)
    80003de0:	7a42                	ld	s4,48(sp)
    80003de2:	7aa2                	ld	s5,40(sp)
    80003de4:	7b02                	ld	s6,32(sp)
    80003de6:	6be2                	ld	s7,24(sp)
    80003de8:	6c42                	ld	s8,16(sp)
    80003dea:	6ca2                	ld	s9,8(sp)
    80003dec:	6125                	addi	sp,sp,96
    80003dee:	8082                	ret
      iunlock(ip);
    80003df0:	8552                	mv	a0,s4
    80003df2:	00000097          	auipc	ra,0x0
    80003df6:	a84080e7          	jalr	-1404(ra) # 80003876 <iunlock>
      return ip;
    80003dfa:	bfe9                	j	80003dd4 <namex+0x68>
      iunlockput(ip);
    80003dfc:	8552                	mv	a0,s4
    80003dfe:	00000097          	auipc	ra,0x0
    80003e02:	c18080e7          	jalr	-1000(ra) # 80003a16 <iunlockput>
      return 0;
    80003e06:	8a4e                	mv	s4,s3
    80003e08:	b7f1                	j	80003dd4 <namex+0x68>
  len = path - s;
    80003e0a:	40998633          	sub	a2,s3,s1
    80003e0e:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80003e12:	099c5863          	bge	s8,s9,80003ea2 <namex+0x136>
    memmove(name, s, DIRSIZ);
    80003e16:	4639                	li	a2,14
    80003e18:	85a6                	mv	a1,s1
    80003e1a:	8556                	mv	a0,s5
    80003e1c:	ffffd097          	auipc	ra,0xffffd
    80003e20:	f74080e7          	jalr	-140(ra) # 80000d90 <memmove>
    80003e24:	84ce                	mv	s1,s3
  while(*path == '/')
    80003e26:	0004c783          	lbu	a5,0(s1)
    80003e2a:	01279763          	bne	a5,s2,80003e38 <namex+0xcc>
    path++;
    80003e2e:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003e30:	0004c783          	lbu	a5,0(s1)
    80003e34:	ff278de3          	beq	a5,s2,80003e2e <namex+0xc2>
    ilock(ip);
    80003e38:	8552                	mv	a0,s4
    80003e3a:	00000097          	auipc	ra,0x0
    80003e3e:	976080e7          	jalr	-1674(ra) # 800037b0 <ilock>
    if(ip->type != T_DIR){
    80003e42:	044a1783          	lh	a5,68(s4)
    80003e46:	f97791e3          	bne	a5,s7,80003dc8 <namex+0x5c>
    if(nameiparent && *path == '\0'){
    80003e4a:	000b0563          	beqz	s6,80003e54 <namex+0xe8>
    80003e4e:	0004c783          	lbu	a5,0(s1)
    80003e52:	dfd9                	beqz	a5,80003df0 <namex+0x84>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003e54:	4601                	li	a2,0
    80003e56:	85d6                	mv	a1,s5
    80003e58:	8552                	mv	a0,s4
    80003e5a:	00000097          	auipc	ra,0x0
    80003e5e:	e62080e7          	jalr	-414(ra) # 80003cbc <dirlookup>
    80003e62:	89aa                	mv	s3,a0
    80003e64:	dd41                	beqz	a0,80003dfc <namex+0x90>
    iunlockput(ip);
    80003e66:	8552                	mv	a0,s4
    80003e68:	00000097          	auipc	ra,0x0
    80003e6c:	bae080e7          	jalr	-1106(ra) # 80003a16 <iunlockput>
    ip = next;
    80003e70:	8a4e                	mv	s4,s3
  while(*path == '/')
    80003e72:	0004c783          	lbu	a5,0(s1)
    80003e76:	01279763          	bne	a5,s2,80003e84 <namex+0x118>
    path++;
    80003e7a:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003e7c:	0004c783          	lbu	a5,0(s1)
    80003e80:	ff278de3          	beq	a5,s2,80003e7a <namex+0x10e>
  if(*path == 0)
    80003e84:	cb9d                	beqz	a5,80003eba <namex+0x14e>
  while(*path != '/' && *path != 0)
    80003e86:	0004c783          	lbu	a5,0(s1)
    80003e8a:	89a6                	mv	s3,s1
  len = path - s;
    80003e8c:	4c81                	li	s9,0
    80003e8e:	4601                	li	a2,0
  while(*path != '/' && *path != 0)
    80003e90:	01278963          	beq	a5,s2,80003ea2 <namex+0x136>
    80003e94:	dbbd                	beqz	a5,80003e0a <namex+0x9e>
    path++;
    80003e96:	0985                	addi	s3,s3,1
  while(*path != '/' && *path != 0)
    80003e98:	0009c783          	lbu	a5,0(s3)
    80003e9c:	ff279ce3          	bne	a5,s2,80003e94 <namex+0x128>
    80003ea0:	b7ad                	j	80003e0a <namex+0x9e>
    memmove(name, s, len);
    80003ea2:	2601                	sext.w	a2,a2
    80003ea4:	85a6                	mv	a1,s1
    80003ea6:	8556                	mv	a0,s5
    80003ea8:	ffffd097          	auipc	ra,0xffffd
    80003eac:	ee8080e7          	jalr	-280(ra) # 80000d90 <memmove>
    name[len] = 0;
    80003eb0:	9cd6                	add	s9,s9,s5
    80003eb2:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80003eb6:	84ce                	mv	s1,s3
    80003eb8:	b7bd                	j	80003e26 <namex+0xba>
  if(nameiparent){
    80003eba:	f00b0de3          	beqz	s6,80003dd4 <namex+0x68>
    iput(ip);
    80003ebe:	8552                	mv	a0,s4
    80003ec0:	00000097          	auipc	ra,0x0
    80003ec4:	aae080e7          	jalr	-1362(ra) # 8000396e <iput>
    return 0;
    80003ec8:	4a01                	li	s4,0
    80003eca:	b729                	j	80003dd4 <namex+0x68>

0000000080003ecc <dirlink>:
{
    80003ecc:	7139                	addi	sp,sp,-64
    80003ece:	fc06                	sd	ra,56(sp)
    80003ed0:	f822                	sd	s0,48(sp)
    80003ed2:	f04a                	sd	s2,32(sp)
    80003ed4:	ec4e                	sd	s3,24(sp)
    80003ed6:	e852                	sd	s4,16(sp)
    80003ed8:	0080                	addi	s0,sp,64
    80003eda:	892a                	mv	s2,a0
    80003edc:	8a2e                	mv	s4,a1
    80003ede:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003ee0:	4601                	li	a2,0
    80003ee2:	00000097          	auipc	ra,0x0
    80003ee6:	dda080e7          	jalr	-550(ra) # 80003cbc <dirlookup>
    80003eea:	ed25                	bnez	a0,80003f62 <dirlink+0x96>
    80003eec:	f426                	sd	s1,40(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003eee:	04c92483          	lw	s1,76(s2)
    80003ef2:	c49d                	beqz	s1,80003f20 <dirlink+0x54>
    80003ef4:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003ef6:	4741                	li	a4,16
    80003ef8:	86a6                	mv	a3,s1
    80003efa:	fc040613          	addi	a2,s0,-64
    80003efe:	4581                	li	a1,0
    80003f00:	854a                	mv	a0,s2
    80003f02:	00000097          	auipc	ra,0x0
    80003f06:	b66080e7          	jalr	-1178(ra) # 80003a68 <readi>
    80003f0a:	47c1                	li	a5,16
    80003f0c:	06f51163          	bne	a0,a5,80003f6e <dirlink+0xa2>
    if(de.inum == 0)
    80003f10:	fc045783          	lhu	a5,-64(s0)
    80003f14:	c791                	beqz	a5,80003f20 <dirlink+0x54>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003f16:	24c1                	addiw	s1,s1,16
    80003f18:	04c92783          	lw	a5,76(s2)
    80003f1c:	fcf4ede3          	bltu	s1,a5,80003ef6 <dirlink+0x2a>
  strncpy(de.name, name, DIRSIZ);
    80003f20:	4639                	li	a2,14
    80003f22:	85d2                	mv	a1,s4
    80003f24:	fc240513          	addi	a0,s0,-62
    80003f28:	ffffd097          	auipc	ra,0xffffd
    80003f2c:	f12080e7          	jalr	-238(ra) # 80000e3a <strncpy>
  de.inum = inum;
    80003f30:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003f34:	4741                	li	a4,16
    80003f36:	86a6                	mv	a3,s1
    80003f38:	fc040613          	addi	a2,s0,-64
    80003f3c:	4581                	li	a1,0
    80003f3e:	854a                	mv	a0,s2
    80003f40:	00000097          	auipc	ra,0x0
    80003f44:	c38080e7          	jalr	-968(ra) # 80003b78 <writei>
    80003f48:	1541                	addi	a0,a0,-16
    80003f4a:	00a03533          	snez	a0,a0
    80003f4e:	40a00533          	neg	a0,a0
    80003f52:	74a2                	ld	s1,40(sp)
}
    80003f54:	70e2                	ld	ra,56(sp)
    80003f56:	7442                	ld	s0,48(sp)
    80003f58:	7902                	ld	s2,32(sp)
    80003f5a:	69e2                	ld	s3,24(sp)
    80003f5c:	6a42                	ld	s4,16(sp)
    80003f5e:	6121                	addi	sp,sp,64
    80003f60:	8082                	ret
    iput(ip);
    80003f62:	00000097          	auipc	ra,0x0
    80003f66:	a0c080e7          	jalr	-1524(ra) # 8000396e <iput>
    return -1;
    80003f6a:	557d                	li	a0,-1
    80003f6c:	b7e5                	j	80003f54 <dirlink+0x88>
      panic("dirlink read");
    80003f6e:	00004517          	auipc	a0,0x4
    80003f72:	5b250513          	addi	a0,a0,1458 # 80008520 <etext+0x520>
    80003f76:	ffffc097          	auipc	ra,0xffffc
    80003f7a:	5ea080e7          	jalr	1514(ra) # 80000560 <panic>

0000000080003f7e <namei>:

struct inode*
namei(char *path)
{
    80003f7e:	1101                	addi	sp,sp,-32
    80003f80:	ec06                	sd	ra,24(sp)
    80003f82:	e822                	sd	s0,16(sp)
    80003f84:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003f86:	fe040613          	addi	a2,s0,-32
    80003f8a:	4581                	li	a1,0
    80003f8c:	00000097          	auipc	ra,0x0
    80003f90:	de0080e7          	jalr	-544(ra) # 80003d6c <namex>
}
    80003f94:	60e2                	ld	ra,24(sp)
    80003f96:	6442                	ld	s0,16(sp)
    80003f98:	6105                	addi	sp,sp,32
    80003f9a:	8082                	ret

0000000080003f9c <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003f9c:	1141                	addi	sp,sp,-16
    80003f9e:	e406                	sd	ra,8(sp)
    80003fa0:	e022                	sd	s0,0(sp)
    80003fa2:	0800                	addi	s0,sp,16
    80003fa4:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003fa6:	4585                	li	a1,1
    80003fa8:	00000097          	auipc	ra,0x0
    80003fac:	dc4080e7          	jalr	-572(ra) # 80003d6c <namex>
}
    80003fb0:	60a2                	ld	ra,8(sp)
    80003fb2:	6402                	ld	s0,0(sp)
    80003fb4:	0141                	addi	sp,sp,16
    80003fb6:	8082                	ret

0000000080003fb8 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003fb8:	1101                	addi	sp,sp,-32
    80003fba:	ec06                	sd	ra,24(sp)
    80003fbc:	e822                	sd	s0,16(sp)
    80003fbe:	e426                	sd	s1,8(sp)
    80003fc0:	e04a                	sd	s2,0(sp)
    80003fc2:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003fc4:	0001f917          	auipc	s2,0x1f
    80003fc8:	4e490913          	addi	s2,s2,1252 # 800234a8 <log>
    80003fcc:	01892583          	lw	a1,24(s2)
    80003fd0:	02892503          	lw	a0,40(s2)
    80003fd4:	fffff097          	auipc	ra,0xfffff
    80003fd8:	fa8080e7          	jalr	-88(ra) # 80002f7c <bread>
    80003fdc:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003fde:	02c92603          	lw	a2,44(s2)
    80003fe2:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003fe4:	00c05f63          	blez	a2,80004002 <write_head+0x4a>
    80003fe8:	0001f717          	auipc	a4,0x1f
    80003fec:	4f070713          	addi	a4,a4,1264 # 800234d8 <log+0x30>
    80003ff0:	87aa                	mv	a5,a0
    80003ff2:	060a                	slli	a2,a2,0x2
    80003ff4:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003ff6:	4314                	lw	a3,0(a4)
    80003ff8:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003ffa:	0711                	addi	a4,a4,4
    80003ffc:	0791                	addi	a5,a5,4
    80003ffe:	fec79ce3          	bne	a5,a2,80003ff6 <write_head+0x3e>
  }
  bwrite(buf);
    80004002:	8526                	mv	a0,s1
    80004004:	fffff097          	auipc	ra,0xfffff
    80004008:	06a080e7          	jalr	106(ra) # 8000306e <bwrite>
  brelse(buf);
    8000400c:	8526                	mv	a0,s1
    8000400e:	fffff097          	auipc	ra,0xfffff
    80004012:	09e080e7          	jalr	158(ra) # 800030ac <brelse>
}
    80004016:	60e2                	ld	ra,24(sp)
    80004018:	6442                	ld	s0,16(sp)
    8000401a:	64a2                	ld	s1,8(sp)
    8000401c:	6902                	ld	s2,0(sp)
    8000401e:	6105                	addi	sp,sp,32
    80004020:	8082                	ret

0000000080004022 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80004022:	0001f797          	auipc	a5,0x1f
    80004026:	4b27a783          	lw	a5,1202(a5) # 800234d4 <log+0x2c>
    8000402a:	0af05d63          	blez	a5,800040e4 <install_trans+0xc2>
{
    8000402e:	7139                	addi	sp,sp,-64
    80004030:	fc06                	sd	ra,56(sp)
    80004032:	f822                	sd	s0,48(sp)
    80004034:	f426                	sd	s1,40(sp)
    80004036:	f04a                	sd	s2,32(sp)
    80004038:	ec4e                	sd	s3,24(sp)
    8000403a:	e852                	sd	s4,16(sp)
    8000403c:	e456                	sd	s5,8(sp)
    8000403e:	e05a                	sd	s6,0(sp)
    80004040:	0080                	addi	s0,sp,64
    80004042:	8b2a                	mv	s6,a0
    80004044:	0001fa97          	auipc	s5,0x1f
    80004048:	494a8a93          	addi	s5,s5,1172 # 800234d8 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000404c:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    8000404e:	0001f997          	auipc	s3,0x1f
    80004052:	45a98993          	addi	s3,s3,1114 # 800234a8 <log>
    80004056:	a00d                	j	80004078 <install_trans+0x56>
    brelse(lbuf);
    80004058:	854a                	mv	a0,s2
    8000405a:	fffff097          	auipc	ra,0xfffff
    8000405e:	052080e7          	jalr	82(ra) # 800030ac <brelse>
    brelse(dbuf);
    80004062:	8526                	mv	a0,s1
    80004064:	fffff097          	auipc	ra,0xfffff
    80004068:	048080e7          	jalr	72(ra) # 800030ac <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000406c:	2a05                	addiw	s4,s4,1
    8000406e:	0a91                	addi	s5,s5,4
    80004070:	02c9a783          	lw	a5,44(s3)
    80004074:	04fa5e63          	bge	s4,a5,800040d0 <install_trans+0xae>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80004078:	0189a583          	lw	a1,24(s3)
    8000407c:	014585bb          	addw	a1,a1,s4
    80004080:	2585                	addiw	a1,a1,1
    80004082:	0289a503          	lw	a0,40(s3)
    80004086:	fffff097          	auipc	ra,0xfffff
    8000408a:	ef6080e7          	jalr	-266(ra) # 80002f7c <bread>
    8000408e:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80004090:	000aa583          	lw	a1,0(s5)
    80004094:	0289a503          	lw	a0,40(s3)
    80004098:	fffff097          	auipc	ra,0xfffff
    8000409c:	ee4080e7          	jalr	-284(ra) # 80002f7c <bread>
    800040a0:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    800040a2:	40000613          	li	a2,1024
    800040a6:	05890593          	addi	a1,s2,88
    800040aa:	05850513          	addi	a0,a0,88
    800040ae:	ffffd097          	auipc	ra,0xffffd
    800040b2:	ce2080e7          	jalr	-798(ra) # 80000d90 <memmove>
    bwrite(dbuf);  // write dst to disk
    800040b6:	8526                	mv	a0,s1
    800040b8:	fffff097          	auipc	ra,0xfffff
    800040bc:	fb6080e7          	jalr	-74(ra) # 8000306e <bwrite>
    if(recovering == 0)
    800040c0:	f80b1ce3          	bnez	s6,80004058 <install_trans+0x36>
      bunpin(dbuf);
    800040c4:	8526                	mv	a0,s1
    800040c6:	fffff097          	auipc	ra,0xfffff
    800040ca:	0be080e7          	jalr	190(ra) # 80003184 <bunpin>
    800040ce:	b769                	j	80004058 <install_trans+0x36>
}
    800040d0:	70e2                	ld	ra,56(sp)
    800040d2:	7442                	ld	s0,48(sp)
    800040d4:	74a2                	ld	s1,40(sp)
    800040d6:	7902                	ld	s2,32(sp)
    800040d8:	69e2                	ld	s3,24(sp)
    800040da:	6a42                	ld	s4,16(sp)
    800040dc:	6aa2                	ld	s5,8(sp)
    800040de:	6b02                	ld	s6,0(sp)
    800040e0:	6121                	addi	sp,sp,64
    800040e2:	8082                	ret
    800040e4:	8082                	ret

00000000800040e6 <initlog>:
{
    800040e6:	7179                	addi	sp,sp,-48
    800040e8:	f406                	sd	ra,40(sp)
    800040ea:	f022                	sd	s0,32(sp)
    800040ec:	ec26                	sd	s1,24(sp)
    800040ee:	e84a                	sd	s2,16(sp)
    800040f0:	e44e                	sd	s3,8(sp)
    800040f2:	1800                	addi	s0,sp,48
    800040f4:	892a                	mv	s2,a0
    800040f6:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    800040f8:	0001f497          	auipc	s1,0x1f
    800040fc:	3b048493          	addi	s1,s1,944 # 800234a8 <log>
    80004100:	00004597          	auipc	a1,0x4
    80004104:	43058593          	addi	a1,a1,1072 # 80008530 <etext+0x530>
    80004108:	8526                	mv	a0,s1
    8000410a:	ffffd097          	auipc	ra,0xffffd
    8000410e:	a9e080e7          	jalr	-1378(ra) # 80000ba8 <initlock>
  log.start = sb->logstart;
    80004112:	0149a583          	lw	a1,20(s3)
    80004116:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80004118:	0109a783          	lw	a5,16(s3)
    8000411c:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    8000411e:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80004122:	854a                	mv	a0,s2
    80004124:	fffff097          	auipc	ra,0xfffff
    80004128:	e58080e7          	jalr	-424(ra) # 80002f7c <bread>
  log.lh.n = lh->n;
    8000412c:	4d30                	lw	a2,88(a0)
    8000412e:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80004130:	00c05f63          	blez	a2,8000414e <initlog+0x68>
    80004134:	87aa                	mv	a5,a0
    80004136:	0001f717          	auipc	a4,0x1f
    8000413a:	3a270713          	addi	a4,a4,930 # 800234d8 <log+0x30>
    8000413e:	060a                	slli	a2,a2,0x2
    80004140:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80004142:	4ff4                	lw	a3,92(a5)
    80004144:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80004146:	0791                	addi	a5,a5,4
    80004148:	0711                	addi	a4,a4,4
    8000414a:	fec79ce3          	bne	a5,a2,80004142 <initlog+0x5c>
  brelse(buf);
    8000414e:	fffff097          	auipc	ra,0xfffff
    80004152:	f5e080e7          	jalr	-162(ra) # 800030ac <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80004156:	4505                	li	a0,1
    80004158:	00000097          	auipc	ra,0x0
    8000415c:	eca080e7          	jalr	-310(ra) # 80004022 <install_trans>
  log.lh.n = 0;
    80004160:	0001f797          	auipc	a5,0x1f
    80004164:	3607aa23          	sw	zero,884(a5) # 800234d4 <log+0x2c>
  write_head(); // clear the log
    80004168:	00000097          	auipc	ra,0x0
    8000416c:	e50080e7          	jalr	-432(ra) # 80003fb8 <write_head>
}
    80004170:	70a2                	ld	ra,40(sp)
    80004172:	7402                	ld	s0,32(sp)
    80004174:	64e2                	ld	s1,24(sp)
    80004176:	6942                	ld	s2,16(sp)
    80004178:	69a2                	ld	s3,8(sp)
    8000417a:	6145                	addi	sp,sp,48
    8000417c:	8082                	ret

000000008000417e <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    8000417e:	1101                	addi	sp,sp,-32
    80004180:	ec06                	sd	ra,24(sp)
    80004182:	e822                	sd	s0,16(sp)
    80004184:	e426                	sd	s1,8(sp)
    80004186:	e04a                	sd	s2,0(sp)
    80004188:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    8000418a:	0001f517          	auipc	a0,0x1f
    8000418e:	31e50513          	addi	a0,a0,798 # 800234a8 <log>
    80004192:	ffffd097          	auipc	ra,0xffffd
    80004196:	aa6080e7          	jalr	-1370(ra) # 80000c38 <acquire>
  while(1){
    if(log.committing){
    8000419a:	0001f497          	auipc	s1,0x1f
    8000419e:	30e48493          	addi	s1,s1,782 # 800234a8 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    800041a2:	4979                	li	s2,30
    800041a4:	a039                	j	800041b2 <begin_op+0x34>
      sleep(&log, &log.lock);
    800041a6:	85a6                	mv	a1,s1
    800041a8:	8526                	mv	a0,s1
    800041aa:	ffffe097          	auipc	ra,0xffffe
    800041ae:	f62080e7          	jalr	-158(ra) # 8000210c <sleep>
    if(log.committing){
    800041b2:	50dc                	lw	a5,36(s1)
    800041b4:	fbed                	bnez	a5,800041a6 <begin_op+0x28>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    800041b6:	5098                	lw	a4,32(s1)
    800041b8:	2705                	addiw	a4,a4,1
    800041ba:	0027179b          	slliw	a5,a4,0x2
    800041be:	9fb9                	addw	a5,a5,a4
    800041c0:	0017979b          	slliw	a5,a5,0x1
    800041c4:	54d4                	lw	a3,44(s1)
    800041c6:	9fb5                	addw	a5,a5,a3
    800041c8:	00f95963          	bge	s2,a5,800041da <begin_op+0x5c>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    800041cc:	85a6                	mv	a1,s1
    800041ce:	8526                	mv	a0,s1
    800041d0:	ffffe097          	auipc	ra,0xffffe
    800041d4:	f3c080e7          	jalr	-196(ra) # 8000210c <sleep>
    800041d8:	bfe9                	j	800041b2 <begin_op+0x34>
    } else {
      log.outstanding += 1;
    800041da:	0001f517          	auipc	a0,0x1f
    800041de:	2ce50513          	addi	a0,a0,718 # 800234a8 <log>
    800041e2:	d118                	sw	a4,32(a0)
      release(&log.lock);
    800041e4:	ffffd097          	auipc	ra,0xffffd
    800041e8:	b08080e7          	jalr	-1272(ra) # 80000cec <release>
      break;
    }
  }
}
    800041ec:	60e2                	ld	ra,24(sp)
    800041ee:	6442                	ld	s0,16(sp)
    800041f0:	64a2                	ld	s1,8(sp)
    800041f2:	6902                	ld	s2,0(sp)
    800041f4:	6105                	addi	sp,sp,32
    800041f6:	8082                	ret

00000000800041f8 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    800041f8:	7139                	addi	sp,sp,-64
    800041fa:	fc06                	sd	ra,56(sp)
    800041fc:	f822                	sd	s0,48(sp)
    800041fe:	f426                	sd	s1,40(sp)
    80004200:	f04a                	sd	s2,32(sp)
    80004202:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80004204:	0001f497          	auipc	s1,0x1f
    80004208:	2a448493          	addi	s1,s1,676 # 800234a8 <log>
    8000420c:	8526                	mv	a0,s1
    8000420e:	ffffd097          	auipc	ra,0xffffd
    80004212:	a2a080e7          	jalr	-1494(ra) # 80000c38 <acquire>
  log.outstanding -= 1;
    80004216:	509c                	lw	a5,32(s1)
    80004218:	37fd                	addiw	a5,a5,-1
    8000421a:	0007891b          	sext.w	s2,a5
    8000421e:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80004220:	50dc                	lw	a5,36(s1)
    80004222:	e7b9                	bnez	a5,80004270 <end_op+0x78>
    panic("log.committing");
  if(log.outstanding == 0){
    80004224:	06091163          	bnez	s2,80004286 <end_op+0x8e>
    do_commit = 1;
    log.committing = 1;
    80004228:	0001f497          	auipc	s1,0x1f
    8000422c:	28048493          	addi	s1,s1,640 # 800234a8 <log>
    80004230:	4785                	li	a5,1
    80004232:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80004234:	8526                	mv	a0,s1
    80004236:	ffffd097          	auipc	ra,0xffffd
    8000423a:	ab6080e7          	jalr	-1354(ra) # 80000cec <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    8000423e:	54dc                	lw	a5,44(s1)
    80004240:	06f04763          	bgtz	a5,800042ae <end_op+0xb6>
    acquire(&log.lock);
    80004244:	0001f497          	auipc	s1,0x1f
    80004248:	26448493          	addi	s1,s1,612 # 800234a8 <log>
    8000424c:	8526                	mv	a0,s1
    8000424e:	ffffd097          	auipc	ra,0xffffd
    80004252:	9ea080e7          	jalr	-1558(ra) # 80000c38 <acquire>
    log.committing = 0;
    80004256:	0204a223          	sw	zero,36(s1)
    wakeup(&log);
    8000425a:	8526                	mv	a0,s1
    8000425c:	ffffe097          	auipc	ra,0xffffe
    80004260:	f14080e7          	jalr	-236(ra) # 80002170 <wakeup>
    release(&log.lock);
    80004264:	8526                	mv	a0,s1
    80004266:	ffffd097          	auipc	ra,0xffffd
    8000426a:	a86080e7          	jalr	-1402(ra) # 80000cec <release>
}
    8000426e:	a815                	j	800042a2 <end_op+0xaa>
    80004270:	ec4e                	sd	s3,24(sp)
    80004272:	e852                	sd	s4,16(sp)
    80004274:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80004276:	00004517          	auipc	a0,0x4
    8000427a:	2c250513          	addi	a0,a0,706 # 80008538 <etext+0x538>
    8000427e:	ffffc097          	auipc	ra,0xffffc
    80004282:	2e2080e7          	jalr	738(ra) # 80000560 <panic>
    wakeup(&log);
    80004286:	0001f497          	auipc	s1,0x1f
    8000428a:	22248493          	addi	s1,s1,546 # 800234a8 <log>
    8000428e:	8526                	mv	a0,s1
    80004290:	ffffe097          	auipc	ra,0xffffe
    80004294:	ee0080e7          	jalr	-288(ra) # 80002170 <wakeup>
  release(&log.lock);
    80004298:	8526                	mv	a0,s1
    8000429a:	ffffd097          	auipc	ra,0xffffd
    8000429e:	a52080e7          	jalr	-1454(ra) # 80000cec <release>
}
    800042a2:	70e2                	ld	ra,56(sp)
    800042a4:	7442                	ld	s0,48(sp)
    800042a6:	74a2                	ld	s1,40(sp)
    800042a8:	7902                	ld	s2,32(sp)
    800042aa:	6121                	addi	sp,sp,64
    800042ac:	8082                	ret
    800042ae:	ec4e                	sd	s3,24(sp)
    800042b0:	e852                	sd	s4,16(sp)
    800042b2:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    800042b4:	0001fa97          	auipc	s5,0x1f
    800042b8:	224a8a93          	addi	s5,s5,548 # 800234d8 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    800042bc:	0001fa17          	auipc	s4,0x1f
    800042c0:	1eca0a13          	addi	s4,s4,492 # 800234a8 <log>
    800042c4:	018a2583          	lw	a1,24(s4)
    800042c8:	012585bb          	addw	a1,a1,s2
    800042cc:	2585                	addiw	a1,a1,1
    800042ce:	028a2503          	lw	a0,40(s4)
    800042d2:	fffff097          	auipc	ra,0xfffff
    800042d6:	caa080e7          	jalr	-854(ra) # 80002f7c <bread>
    800042da:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    800042dc:	000aa583          	lw	a1,0(s5)
    800042e0:	028a2503          	lw	a0,40(s4)
    800042e4:	fffff097          	auipc	ra,0xfffff
    800042e8:	c98080e7          	jalr	-872(ra) # 80002f7c <bread>
    800042ec:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    800042ee:	40000613          	li	a2,1024
    800042f2:	05850593          	addi	a1,a0,88
    800042f6:	05848513          	addi	a0,s1,88
    800042fa:	ffffd097          	auipc	ra,0xffffd
    800042fe:	a96080e7          	jalr	-1386(ra) # 80000d90 <memmove>
    bwrite(to);  // write the log
    80004302:	8526                	mv	a0,s1
    80004304:	fffff097          	auipc	ra,0xfffff
    80004308:	d6a080e7          	jalr	-662(ra) # 8000306e <bwrite>
    brelse(from);
    8000430c:	854e                	mv	a0,s3
    8000430e:	fffff097          	auipc	ra,0xfffff
    80004312:	d9e080e7          	jalr	-610(ra) # 800030ac <brelse>
    brelse(to);
    80004316:	8526                	mv	a0,s1
    80004318:	fffff097          	auipc	ra,0xfffff
    8000431c:	d94080e7          	jalr	-620(ra) # 800030ac <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004320:	2905                	addiw	s2,s2,1
    80004322:	0a91                	addi	s5,s5,4
    80004324:	02ca2783          	lw	a5,44(s4)
    80004328:	f8f94ee3          	blt	s2,a5,800042c4 <end_op+0xcc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    8000432c:	00000097          	auipc	ra,0x0
    80004330:	c8c080e7          	jalr	-884(ra) # 80003fb8 <write_head>
    install_trans(0); // Now install writes to home locations
    80004334:	4501                	li	a0,0
    80004336:	00000097          	auipc	ra,0x0
    8000433a:	cec080e7          	jalr	-788(ra) # 80004022 <install_trans>
    log.lh.n = 0;
    8000433e:	0001f797          	auipc	a5,0x1f
    80004342:	1807ab23          	sw	zero,406(a5) # 800234d4 <log+0x2c>
    write_head();    // Erase the transaction from the log
    80004346:	00000097          	auipc	ra,0x0
    8000434a:	c72080e7          	jalr	-910(ra) # 80003fb8 <write_head>
    8000434e:	69e2                	ld	s3,24(sp)
    80004350:	6a42                	ld	s4,16(sp)
    80004352:	6aa2                	ld	s5,8(sp)
    80004354:	bdc5                	j	80004244 <end_op+0x4c>

0000000080004356 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80004356:	1101                	addi	sp,sp,-32
    80004358:	ec06                	sd	ra,24(sp)
    8000435a:	e822                	sd	s0,16(sp)
    8000435c:	e426                	sd	s1,8(sp)
    8000435e:	e04a                	sd	s2,0(sp)
    80004360:	1000                	addi	s0,sp,32
    80004362:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80004364:	0001f917          	auipc	s2,0x1f
    80004368:	14490913          	addi	s2,s2,324 # 800234a8 <log>
    8000436c:	854a                	mv	a0,s2
    8000436e:	ffffd097          	auipc	ra,0xffffd
    80004372:	8ca080e7          	jalr	-1846(ra) # 80000c38 <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80004376:	02c92603          	lw	a2,44(s2)
    8000437a:	47f5                	li	a5,29
    8000437c:	06c7c563          	blt	a5,a2,800043e6 <log_write+0x90>
    80004380:	0001f797          	auipc	a5,0x1f
    80004384:	1447a783          	lw	a5,324(a5) # 800234c4 <log+0x1c>
    80004388:	37fd                	addiw	a5,a5,-1
    8000438a:	04f65e63          	bge	a2,a5,800043e6 <log_write+0x90>
    panic("too big a transaction");
  if (log.outstanding < 1)
    8000438e:	0001f797          	auipc	a5,0x1f
    80004392:	13a7a783          	lw	a5,314(a5) # 800234c8 <log+0x20>
    80004396:	06f05063          	blez	a5,800043f6 <log_write+0xa0>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    8000439a:	4781                	li	a5,0
    8000439c:	06c05563          	blez	a2,80004406 <log_write+0xb0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    800043a0:	44cc                	lw	a1,12(s1)
    800043a2:	0001f717          	auipc	a4,0x1f
    800043a6:	13670713          	addi	a4,a4,310 # 800234d8 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    800043aa:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    800043ac:	4314                	lw	a3,0(a4)
    800043ae:	04b68c63          	beq	a3,a1,80004406 <log_write+0xb0>
  for (i = 0; i < log.lh.n; i++) {
    800043b2:	2785                	addiw	a5,a5,1
    800043b4:	0711                	addi	a4,a4,4
    800043b6:	fef61be3          	bne	a2,a5,800043ac <log_write+0x56>
      break;
  }
  log.lh.block[i] = b->blockno;
    800043ba:	0621                	addi	a2,a2,8
    800043bc:	060a                	slli	a2,a2,0x2
    800043be:	0001f797          	auipc	a5,0x1f
    800043c2:	0ea78793          	addi	a5,a5,234 # 800234a8 <log>
    800043c6:	97b2                	add	a5,a5,a2
    800043c8:	44d8                	lw	a4,12(s1)
    800043ca:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    800043cc:	8526                	mv	a0,s1
    800043ce:	fffff097          	auipc	ra,0xfffff
    800043d2:	d7a080e7          	jalr	-646(ra) # 80003148 <bpin>
    log.lh.n++;
    800043d6:	0001f717          	auipc	a4,0x1f
    800043da:	0d270713          	addi	a4,a4,210 # 800234a8 <log>
    800043de:	575c                	lw	a5,44(a4)
    800043e0:	2785                	addiw	a5,a5,1
    800043e2:	d75c                	sw	a5,44(a4)
    800043e4:	a82d                	j	8000441e <log_write+0xc8>
    panic("too big a transaction");
    800043e6:	00004517          	auipc	a0,0x4
    800043ea:	16250513          	addi	a0,a0,354 # 80008548 <etext+0x548>
    800043ee:	ffffc097          	auipc	ra,0xffffc
    800043f2:	172080e7          	jalr	370(ra) # 80000560 <panic>
    panic("log_write outside of trans");
    800043f6:	00004517          	auipc	a0,0x4
    800043fa:	16a50513          	addi	a0,a0,362 # 80008560 <etext+0x560>
    800043fe:	ffffc097          	auipc	ra,0xffffc
    80004402:	162080e7          	jalr	354(ra) # 80000560 <panic>
  log.lh.block[i] = b->blockno;
    80004406:	00878693          	addi	a3,a5,8
    8000440a:	068a                	slli	a3,a3,0x2
    8000440c:	0001f717          	auipc	a4,0x1f
    80004410:	09c70713          	addi	a4,a4,156 # 800234a8 <log>
    80004414:	9736                	add	a4,a4,a3
    80004416:	44d4                	lw	a3,12(s1)
    80004418:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    8000441a:	faf609e3          	beq	a2,a5,800043cc <log_write+0x76>
  }
  release(&log.lock);
    8000441e:	0001f517          	auipc	a0,0x1f
    80004422:	08a50513          	addi	a0,a0,138 # 800234a8 <log>
    80004426:	ffffd097          	auipc	ra,0xffffd
    8000442a:	8c6080e7          	jalr	-1850(ra) # 80000cec <release>
}
    8000442e:	60e2                	ld	ra,24(sp)
    80004430:	6442                	ld	s0,16(sp)
    80004432:	64a2                	ld	s1,8(sp)
    80004434:	6902                	ld	s2,0(sp)
    80004436:	6105                	addi	sp,sp,32
    80004438:	8082                	ret

000000008000443a <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    8000443a:	1101                	addi	sp,sp,-32
    8000443c:	ec06                	sd	ra,24(sp)
    8000443e:	e822                	sd	s0,16(sp)
    80004440:	e426                	sd	s1,8(sp)
    80004442:	e04a                	sd	s2,0(sp)
    80004444:	1000                	addi	s0,sp,32
    80004446:	84aa                	mv	s1,a0
    80004448:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    8000444a:	00004597          	auipc	a1,0x4
    8000444e:	13658593          	addi	a1,a1,310 # 80008580 <etext+0x580>
    80004452:	0521                	addi	a0,a0,8
    80004454:	ffffc097          	auipc	ra,0xffffc
    80004458:	754080e7          	jalr	1876(ra) # 80000ba8 <initlock>
  lk->name = name;
    8000445c:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80004460:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004464:	0204a423          	sw	zero,40(s1)
}
    80004468:	60e2                	ld	ra,24(sp)
    8000446a:	6442                	ld	s0,16(sp)
    8000446c:	64a2                	ld	s1,8(sp)
    8000446e:	6902                	ld	s2,0(sp)
    80004470:	6105                	addi	sp,sp,32
    80004472:	8082                	ret

0000000080004474 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80004474:	1101                	addi	sp,sp,-32
    80004476:	ec06                	sd	ra,24(sp)
    80004478:	e822                	sd	s0,16(sp)
    8000447a:	e426                	sd	s1,8(sp)
    8000447c:	e04a                	sd	s2,0(sp)
    8000447e:	1000                	addi	s0,sp,32
    80004480:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004482:	00850913          	addi	s2,a0,8
    80004486:	854a                	mv	a0,s2
    80004488:	ffffc097          	auipc	ra,0xffffc
    8000448c:	7b0080e7          	jalr	1968(ra) # 80000c38 <acquire>
  while (lk->locked) {
    80004490:	409c                	lw	a5,0(s1)
    80004492:	cb89                	beqz	a5,800044a4 <acquiresleep+0x30>
    sleep(lk, &lk->lk);
    80004494:	85ca                	mv	a1,s2
    80004496:	8526                	mv	a0,s1
    80004498:	ffffe097          	auipc	ra,0xffffe
    8000449c:	c74080e7          	jalr	-908(ra) # 8000210c <sleep>
  while (lk->locked) {
    800044a0:	409c                	lw	a5,0(s1)
    800044a2:	fbed                	bnez	a5,80004494 <acquiresleep+0x20>
  }
  lk->locked = 1;
    800044a4:	4785                	li	a5,1
    800044a6:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800044a8:	ffffd097          	auipc	ra,0xffffd
    800044ac:	5ba080e7          	jalr	1466(ra) # 80001a62 <myproc>
    800044b0:	591c                	lw	a5,48(a0)
    800044b2:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800044b4:	854a                	mv	a0,s2
    800044b6:	ffffd097          	auipc	ra,0xffffd
    800044ba:	836080e7          	jalr	-1994(ra) # 80000cec <release>
}
    800044be:	60e2                	ld	ra,24(sp)
    800044c0:	6442                	ld	s0,16(sp)
    800044c2:	64a2                	ld	s1,8(sp)
    800044c4:	6902                	ld	s2,0(sp)
    800044c6:	6105                	addi	sp,sp,32
    800044c8:	8082                	ret

00000000800044ca <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800044ca:	1101                	addi	sp,sp,-32
    800044cc:	ec06                	sd	ra,24(sp)
    800044ce:	e822                	sd	s0,16(sp)
    800044d0:	e426                	sd	s1,8(sp)
    800044d2:	e04a                	sd	s2,0(sp)
    800044d4:	1000                	addi	s0,sp,32
    800044d6:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800044d8:	00850913          	addi	s2,a0,8
    800044dc:	854a                	mv	a0,s2
    800044de:	ffffc097          	auipc	ra,0xffffc
    800044e2:	75a080e7          	jalr	1882(ra) # 80000c38 <acquire>
  lk->locked = 0;
    800044e6:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800044ea:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    800044ee:	8526                	mv	a0,s1
    800044f0:	ffffe097          	auipc	ra,0xffffe
    800044f4:	c80080e7          	jalr	-896(ra) # 80002170 <wakeup>
  release(&lk->lk);
    800044f8:	854a                	mv	a0,s2
    800044fa:	ffffc097          	auipc	ra,0xffffc
    800044fe:	7f2080e7          	jalr	2034(ra) # 80000cec <release>
}
    80004502:	60e2                	ld	ra,24(sp)
    80004504:	6442                	ld	s0,16(sp)
    80004506:	64a2                	ld	s1,8(sp)
    80004508:	6902                	ld	s2,0(sp)
    8000450a:	6105                	addi	sp,sp,32
    8000450c:	8082                	ret

000000008000450e <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000450e:	7179                	addi	sp,sp,-48
    80004510:	f406                	sd	ra,40(sp)
    80004512:	f022                	sd	s0,32(sp)
    80004514:	ec26                	sd	s1,24(sp)
    80004516:	e84a                	sd	s2,16(sp)
    80004518:	1800                	addi	s0,sp,48
    8000451a:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    8000451c:	00850913          	addi	s2,a0,8
    80004520:	854a                	mv	a0,s2
    80004522:	ffffc097          	auipc	ra,0xffffc
    80004526:	716080e7          	jalr	1814(ra) # 80000c38 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    8000452a:	409c                	lw	a5,0(s1)
    8000452c:	ef91                	bnez	a5,80004548 <holdingsleep+0x3a>
    8000452e:	4481                	li	s1,0
  release(&lk->lk);
    80004530:	854a                	mv	a0,s2
    80004532:	ffffc097          	auipc	ra,0xffffc
    80004536:	7ba080e7          	jalr	1978(ra) # 80000cec <release>
  return r;
}
    8000453a:	8526                	mv	a0,s1
    8000453c:	70a2                	ld	ra,40(sp)
    8000453e:	7402                	ld	s0,32(sp)
    80004540:	64e2                	ld	s1,24(sp)
    80004542:	6942                	ld	s2,16(sp)
    80004544:	6145                	addi	sp,sp,48
    80004546:	8082                	ret
    80004548:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    8000454a:	0284a983          	lw	s3,40(s1)
    8000454e:	ffffd097          	auipc	ra,0xffffd
    80004552:	514080e7          	jalr	1300(ra) # 80001a62 <myproc>
    80004556:	5904                	lw	s1,48(a0)
    80004558:	413484b3          	sub	s1,s1,s3
    8000455c:	0014b493          	seqz	s1,s1
    80004560:	69a2                	ld	s3,8(sp)
    80004562:	b7f9                	j	80004530 <holdingsleep+0x22>

0000000080004564 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80004564:	1141                	addi	sp,sp,-16
    80004566:	e406                	sd	ra,8(sp)
    80004568:	e022                	sd	s0,0(sp)
    8000456a:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    8000456c:	00004597          	auipc	a1,0x4
    80004570:	02458593          	addi	a1,a1,36 # 80008590 <etext+0x590>
    80004574:	0001f517          	auipc	a0,0x1f
    80004578:	07c50513          	addi	a0,a0,124 # 800235f0 <ftable>
    8000457c:	ffffc097          	auipc	ra,0xffffc
    80004580:	62c080e7          	jalr	1580(ra) # 80000ba8 <initlock>
}
    80004584:	60a2                	ld	ra,8(sp)
    80004586:	6402                	ld	s0,0(sp)
    80004588:	0141                	addi	sp,sp,16
    8000458a:	8082                	ret

000000008000458c <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    8000458c:	1101                	addi	sp,sp,-32
    8000458e:	ec06                	sd	ra,24(sp)
    80004590:	e822                	sd	s0,16(sp)
    80004592:	e426                	sd	s1,8(sp)
    80004594:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004596:	0001f517          	auipc	a0,0x1f
    8000459a:	05a50513          	addi	a0,a0,90 # 800235f0 <ftable>
    8000459e:	ffffc097          	auipc	ra,0xffffc
    800045a2:	69a080e7          	jalr	1690(ra) # 80000c38 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800045a6:	0001f497          	auipc	s1,0x1f
    800045aa:	06248493          	addi	s1,s1,98 # 80023608 <ftable+0x18>
    800045ae:	00020717          	auipc	a4,0x20
    800045b2:	ffa70713          	addi	a4,a4,-6 # 800245a8 <disk>
    if(f->ref == 0){
    800045b6:	40dc                	lw	a5,4(s1)
    800045b8:	cf99                	beqz	a5,800045d6 <filealloc+0x4a>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800045ba:	02848493          	addi	s1,s1,40
    800045be:	fee49ce3          	bne	s1,a4,800045b6 <filealloc+0x2a>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800045c2:	0001f517          	auipc	a0,0x1f
    800045c6:	02e50513          	addi	a0,a0,46 # 800235f0 <ftable>
    800045ca:	ffffc097          	auipc	ra,0xffffc
    800045ce:	722080e7          	jalr	1826(ra) # 80000cec <release>
  return 0;
    800045d2:	4481                	li	s1,0
    800045d4:	a819                	j	800045ea <filealloc+0x5e>
      f->ref = 1;
    800045d6:	4785                	li	a5,1
    800045d8:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800045da:	0001f517          	auipc	a0,0x1f
    800045de:	01650513          	addi	a0,a0,22 # 800235f0 <ftable>
    800045e2:	ffffc097          	auipc	ra,0xffffc
    800045e6:	70a080e7          	jalr	1802(ra) # 80000cec <release>
}
    800045ea:	8526                	mv	a0,s1
    800045ec:	60e2                	ld	ra,24(sp)
    800045ee:	6442                	ld	s0,16(sp)
    800045f0:	64a2                	ld	s1,8(sp)
    800045f2:	6105                	addi	sp,sp,32
    800045f4:	8082                	ret

00000000800045f6 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    800045f6:	1101                	addi	sp,sp,-32
    800045f8:	ec06                	sd	ra,24(sp)
    800045fa:	e822                	sd	s0,16(sp)
    800045fc:	e426                	sd	s1,8(sp)
    800045fe:	1000                	addi	s0,sp,32
    80004600:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80004602:	0001f517          	auipc	a0,0x1f
    80004606:	fee50513          	addi	a0,a0,-18 # 800235f0 <ftable>
    8000460a:	ffffc097          	auipc	ra,0xffffc
    8000460e:	62e080e7          	jalr	1582(ra) # 80000c38 <acquire>
  if(f->ref < 1)
    80004612:	40dc                	lw	a5,4(s1)
    80004614:	02f05263          	blez	a5,80004638 <filedup+0x42>
    panic("filedup");
  f->ref++;
    80004618:	2785                	addiw	a5,a5,1
    8000461a:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000461c:	0001f517          	auipc	a0,0x1f
    80004620:	fd450513          	addi	a0,a0,-44 # 800235f0 <ftable>
    80004624:	ffffc097          	auipc	ra,0xffffc
    80004628:	6c8080e7          	jalr	1736(ra) # 80000cec <release>
  return f;
}
    8000462c:	8526                	mv	a0,s1
    8000462e:	60e2                	ld	ra,24(sp)
    80004630:	6442                	ld	s0,16(sp)
    80004632:	64a2                	ld	s1,8(sp)
    80004634:	6105                	addi	sp,sp,32
    80004636:	8082                	ret
    panic("filedup");
    80004638:	00004517          	auipc	a0,0x4
    8000463c:	f6050513          	addi	a0,a0,-160 # 80008598 <etext+0x598>
    80004640:	ffffc097          	auipc	ra,0xffffc
    80004644:	f20080e7          	jalr	-224(ra) # 80000560 <panic>

0000000080004648 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80004648:	7139                	addi	sp,sp,-64
    8000464a:	fc06                	sd	ra,56(sp)
    8000464c:	f822                	sd	s0,48(sp)
    8000464e:	f426                	sd	s1,40(sp)
    80004650:	0080                	addi	s0,sp,64
    80004652:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80004654:	0001f517          	auipc	a0,0x1f
    80004658:	f9c50513          	addi	a0,a0,-100 # 800235f0 <ftable>
    8000465c:	ffffc097          	auipc	ra,0xffffc
    80004660:	5dc080e7          	jalr	1500(ra) # 80000c38 <acquire>
  if(f->ref < 1)
    80004664:	40dc                	lw	a5,4(s1)
    80004666:	04f05c63          	blez	a5,800046be <fileclose+0x76>
    panic("fileclose");
  if(--f->ref > 0){
    8000466a:	37fd                	addiw	a5,a5,-1
    8000466c:	0007871b          	sext.w	a4,a5
    80004670:	c0dc                	sw	a5,4(s1)
    80004672:	06e04263          	bgtz	a4,800046d6 <fileclose+0x8e>
    80004676:	f04a                	sd	s2,32(sp)
    80004678:	ec4e                	sd	s3,24(sp)
    8000467a:	e852                	sd	s4,16(sp)
    8000467c:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    8000467e:	0004a903          	lw	s2,0(s1)
    80004682:	0094ca83          	lbu	s5,9(s1)
    80004686:	0104ba03          	ld	s4,16(s1)
    8000468a:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    8000468e:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004692:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004696:	0001f517          	auipc	a0,0x1f
    8000469a:	f5a50513          	addi	a0,a0,-166 # 800235f0 <ftable>
    8000469e:	ffffc097          	auipc	ra,0xffffc
    800046a2:	64e080e7          	jalr	1614(ra) # 80000cec <release>

  if(ff.type == FD_PIPE){
    800046a6:	4785                	li	a5,1
    800046a8:	04f90463          	beq	s2,a5,800046f0 <fileclose+0xa8>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    800046ac:	3979                	addiw	s2,s2,-2
    800046ae:	4785                	li	a5,1
    800046b0:	0527fb63          	bgeu	a5,s2,80004706 <fileclose+0xbe>
    800046b4:	7902                	ld	s2,32(sp)
    800046b6:	69e2                	ld	s3,24(sp)
    800046b8:	6a42                	ld	s4,16(sp)
    800046ba:	6aa2                	ld	s5,8(sp)
    800046bc:	a02d                	j	800046e6 <fileclose+0x9e>
    800046be:	f04a                	sd	s2,32(sp)
    800046c0:	ec4e                	sd	s3,24(sp)
    800046c2:	e852                	sd	s4,16(sp)
    800046c4:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800046c6:	00004517          	auipc	a0,0x4
    800046ca:	eda50513          	addi	a0,a0,-294 # 800085a0 <etext+0x5a0>
    800046ce:	ffffc097          	auipc	ra,0xffffc
    800046d2:	e92080e7          	jalr	-366(ra) # 80000560 <panic>
    release(&ftable.lock);
    800046d6:	0001f517          	auipc	a0,0x1f
    800046da:	f1a50513          	addi	a0,a0,-230 # 800235f0 <ftable>
    800046de:	ffffc097          	auipc	ra,0xffffc
    800046e2:	60e080e7          	jalr	1550(ra) # 80000cec <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800046e6:	70e2                	ld	ra,56(sp)
    800046e8:	7442                	ld	s0,48(sp)
    800046ea:	74a2                	ld	s1,40(sp)
    800046ec:	6121                	addi	sp,sp,64
    800046ee:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800046f0:	85d6                	mv	a1,s5
    800046f2:	8552                	mv	a0,s4
    800046f4:	00000097          	auipc	ra,0x0
    800046f8:	3a2080e7          	jalr	930(ra) # 80004a96 <pipeclose>
    800046fc:	7902                	ld	s2,32(sp)
    800046fe:	69e2                	ld	s3,24(sp)
    80004700:	6a42                	ld	s4,16(sp)
    80004702:	6aa2                	ld	s5,8(sp)
    80004704:	b7cd                	j	800046e6 <fileclose+0x9e>
    begin_op();
    80004706:	00000097          	auipc	ra,0x0
    8000470a:	a78080e7          	jalr	-1416(ra) # 8000417e <begin_op>
    iput(ff.ip);
    8000470e:	854e                	mv	a0,s3
    80004710:	fffff097          	auipc	ra,0xfffff
    80004714:	25e080e7          	jalr	606(ra) # 8000396e <iput>
    end_op();
    80004718:	00000097          	auipc	ra,0x0
    8000471c:	ae0080e7          	jalr	-1312(ra) # 800041f8 <end_op>
    80004720:	7902                	ld	s2,32(sp)
    80004722:	69e2                	ld	s3,24(sp)
    80004724:	6a42                	ld	s4,16(sp)
    80004726:	6aa2                	ld	s5,8(sp)
    80004728:	bf7d                	j	800046e6 <fileclose+0x9e>

000000008000472a <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    8000472a:	715d                	addi	sp,sp,-80
    8000472c:	e486                	sd	ra,72(sp)
    8000472e:	e0a2                	sd	s0,64(sp)
    80004730:	fc26                	sd	s1,56(sp)
    80004732:	f44e                	sd	s3,40(sp)
    80004734:	0880                	addi	s0,sp,80
    80004736:	84aa                	mv	s1,a0
    80004738:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    8000473a:	ffffd097          	auipc	ra,0xffffd
    8000473e:	328080e7          	jalr	808(ra) # 80001a62 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80004742:	409c                	lw	a5,0(s1)
    80004744:	37f9                	addiw	a5,a5,-2
    80004746:	4705                	li	a4,1
    80004748:	04f76863          	bltu	a4,a5,80004798 <filestat+0x6e>
    8000474c:	f84a                	sd	s2,48(sp)
    8000474e:	892a                	mv	s2,a0
    ilock(f->ip);
    80004750:	6c88                	ld	a0,24(s1)
    80004752:	fffff097          	auipc	ra,0xfffff
    80004756:	05e080e7          	jalr	94(ra) # 800037b0 <ilock>
    stati(f->ip, &st);
    8000475a:	fb840593          	addi	a1,s0,-72
    8000475e:	6c88                	ld	a0,24(s1)
    80004760:	fffff097          	auipc	ra,0xfffff
    80004764:	2de080e7          	jalr	734(ra) # 80003a3e <stati>
    iunlock(f->ip);
    80004768:	6c88                	ld	a0,24(s1)
    8000476a:	fffff097          	auipc	ra,0xfffff
    8000476e:	10c080e7          	jalr	268(ra) # 80003876 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80004772:	46e1                	li	a3,24
    80004774:	fb840613          	addi	a2,s0,-72
    80004778:	85ce                	mv	a1,s3
    8000477a:	05093503          	ld	a0,80(s2)
    8000477e:	ffffd097          	auipc	ra,0xffffd
    80004782:	f64080e7          	jalr	-156(ra) # 800016e2 <copyout>
    80004786:	41f5551b          	sraiw	a0,a0,0x1f
    8000478a:	7942                	ld	s2,48(sp)
      return -1;
    return 0;
  }
  return -1;
}
    8000478c:	60a6                	ld	ra,72(sp)
    8000478e:	6406                	ld	s0,64(sp)
    80004790:	74e2                	ld	s1,56(sp)
    80004792:	79a2                	ld	s3,40(sp)
    80004794:	6161                	addi	sp,sp,80
    80004796:	8082                	ret
  return -1;
    80004798:	557d                	li	a0,-1
    8000479a:	bfcd                	j	8000478c <filestat+0x62>

000000008000479c <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    8000479c:	7179                	addi	sp,sp,-48
    8000479e:	f406                	sd	ra,40(sp)
    800047a0:	f022                	sd	s0,32(sp)
    800047a2:	e84a                	sd	s2,16(sp)
    800047a4:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    800047a6:	00854783          	lbu	a5,8(a0)
    800047aa:	cbc5                	beqz	a5,8000485a <fileread+0xbe>
    800047ac:	ec26                	sd	s1,24(sp)
    800047ae:	e44e                	sd	s3,8(sp)
    800047b0:	84aa                	mv	s1,a0
    800047b2:	89ae                	mv	s3,a1
    800047b4:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    800047b6:	411c                	lw	a5,0(a0)
    800047b8:	4705                	li	a4,1
    800047ba:	04e78963          	beq	a5,a4,8000480c <fileread+0x70>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800047be:	470d                	li	a4,3
    800047c0:	04e78f63          	beq	a5,a4,8000481e <fileread+0x82>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    800047c4:	4709                	li	a4,2
    800047c6:	08e79263          	bne	a5,a4,8000484a <fileread+0xae>
    ilock(f->ip);
    800047ca:	6d08                	ld	a0,24(a0)
    800047cc:	fffff097          	auipc	ra,0xfffff
    800047d0:	fe4080e7          	jalr	-28(ra) # 800037b0 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    800047d4:	874a                	mv	a4,s2
    800047d6:	5094                	lw	a3,32(s1)
    800047d8:	864e                	mv	a2,s3
    800047da:	4585                	li	a1,1
    800047dc:	6c88                	ld	a0,24(s1)
    800047de:	fffff097          	auipc	ra,0xfffff
    800047e2:	28a080e7          	jalr	650(ra) # 80003a68 <readi>
    800047e6:	892a                	mv	s2,a0
    800047e8:	00a05563          	blez	a0,800047f2 <fileread+0x56>
      f->off += r;
    800047ec:	509c                	lw	a5,32(s1)
    800047ee:	9fa9                	addw	a5,a5,a0
    800047f0:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800047f2:	6c88                	ld	a0,24(s1)
    800047f4:	fffff097          	auipc	ra,0xfffff
    800047f8:	082080e7          	jalr	130(ra) # 80003876 <iunlock>
    800047fc:	64e2                	ld	s1,24(sp)
    800047fe:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80004800:	854a                	mv	a0,s2
    80004802:	70a2                	ld	ra,40(sp)
    80004804:	7402                	ld	s0,32(sp)
    80004806:	6942                	ld	s2,16(sp)
    80004808:	6145                	addi	sp,sp,48
    8000480a:	8082                	ret
    r = piperead(f->pipe, addr, n);
    8000480c:	6908                	ld	a0,16(a0)
    8000480e:	00000097          	auipc	ra,0x0
    80004812:	400080e7          	jalr	1024(ra) # 80004c0e <piperead>
    80004816:	892a                	mv	s2,a0
    80004818:	64e2                	ld	s1,24(sp)
    8000481a:	69a2                	ld	s3,8(sp)
    8000481c:	b7d5                	j	80004800 <fileread+0x64>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    8000481e:	02451783          	lh	a5,36(a0)
    80004822:	03079693          	slli	a3,a5,0x30
    80004826:	92c1                	srli	a3,a3,0x30
    80004828:	4725                	li	a4,9
    8000482a:	02d76a63          	bltu	a4,a3,8000485e <fileread+0xc2>
    8000482e:	0792                	slli	a5,a5,0x4
    80004830:	0001f717          	auipc	a4,0x1f
    80004834:	d2070713          	addi	a4,a4,-736 # 80023550 <devsw>
    80004838:	97ba                	add	a5,a5,a4
    8000483a:	639c                	ld	a5,0(a5)
    8000483c:	c78d                	beqz	a5,80004866 <fileread+0xca>
    r = devsw[f->major].read(1, addr, n);
    8000483e:	4505                	li	a0,1
    80004840:	9782                	jalr	a5
    80004842:	892a                	mv	s2,a0
    80004844:	64e2                	ld	s1,24(sp)
    80004846:	69a2                	ld	s3,8(sp)
    80004848:	bf65                	j	80004800 <fileread+0x64>
    panic("fileread");
    8000484a:	00004517          	auipc	a0,0x4
    8000484e:	d6650513          	addi	a0,a0,-666 # 800085b0 <etext+0x5b0>
    80004852:	ffffc097          	auipc	ra,0xffffc
    80004856:	d0e080e7          	jalr	-754(ra) # 80000560 <panic>
    return -1;
    8000485a:	597d                	li	s2,-1
    8000485c:	b755                	j	80004800 <fileread+0x64>
      return -1;
    8000485e:	597d                	li	s2,-1
    80004860:	64e2                	ld	s1,24(sp)
    80004862:	69a2                	ld	s3,8(sp)
    80004864:	bf71                	j	80004800 <fileread+0x64>
    80004866:	597d                	li	s2,-1
    80004868:	64e2                	ld	s1,24(sp)
    8000486a:	69a2                	ld	s3,8(sp)
    8000486c:	bf51                	j	80004800 <fileread+0x64>

000000008000486e <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    8000486e:	00954783          	lbu	a5,9(a0)
    80004872:	12078963          	beqz	a5,800049a4 <filewrite+0x136>
{
    80004876:	715d                	addi	sp,sp,-80
    80004878:	e486                	sd	ra,72(sp)
    8000487a:	e0a2                	sd	s0,64(sp)
    8000487c:	f84a                	sd	s2,48(sp)
    8000487e:	f052                	sd	s4,32(sp)
    80004880:	e85a                	sd	s6,16(sp)
    80004882:	0880                	addi	s0,sp,80
    80004884:	892a                	mv	s2,a0
    80004886:	8b2e                	mv	s6,a1
    80004888:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    8000488a:	411c                	lw	a5,0(a0)
    8000488c:	4705                	li	a4,1
    8000488e:	02e78763          	beq	a5,a4,800048bc <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004892:	470d                	li	a4,3
    80004894:	02e78a63          	beq	a5,a4,800048c8 <filewrite+0x5a>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80004898:	4709                	li	a4,2
    8000489a:	0ee79863          	bne	a5,a4,8000498a <filewrite+0x11c>
    8000489e:	f44e                	sd	s3,40(sp)
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800048a0:	0cc05463          	blez	a2,80004968 <filewrite+0xfa>
    800048a4:	fc26                	sd	s1,56(sp)
    800048a6:	ec56                	sd	s5,24(sp)
    800048a8:	e45e                	sd	s7,8(sp)
    800048aa:	e062                	sd	s8,0(sp)
    int i = 0;
    800048ac:	4981                	li	s3,0
      int n1 = n - i;
      if(n1 > max)
    800048ae:	6b85                	lui	s7,0x1
    800048b0:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800048b4:	6c05                	lui	s8,0x1
    800048b6:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    800048ba:	a851                	j	8000494e <filewrite+0xe0>
    ret = pipewrite(f->pipe, addr, n);
    800048bc:	6908                	ld	a0,16(a0)
    800048be:	00000097          	auipc	ra,0x0
    800048c2:	248080e7          	jalr	584(ra) # 80004b06 <pipewrite>
    800048c6:	a85d                	j	8000497c <filewrite+0x10e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800048c8:	02451783          	lh	a5,36(a0)
    800048cc:	03079693          	slli	a3,a5,0x30
    800048d0:	92c1                	srli	a3,a3,0x30
    800048d2:	4725                	li	a4,9
    800048d4:	0cd76a63          	bltu	a4,a3,800049a8 <filewrite+0x13a>
    800048d8:	0792                	slli	a5,a5,0x4
    800048da:	0001f717          	auipc	a4,0x1f
    800048de:	c7670713          	addi	a4,a4,-906 # 80023550 <devsw>
    800048e2:	97ba                	add	a5,a5,a4
    800048e4:	679c                	ld	a5,8(a5)
    800048e6:	c3f9                	beqz	a5,800049ac <filewrite+0x13e>
    ret = devsw[f->major].write(1, addr, n);
    800048e8:	4505                	li	a0,1
    800048ea:	9782                	jalr	a5
    800048ec:	a841                	j	8000497c <filewrite+0x10e>
      if(n1 > max)
    800048ee:	00048a9b          	sext.w	s5,s1
        n1 = max;

      begin_op();
    800048f2:	00000097          	auipc	ra,0x0
    800048f6:	88c080e7          	jalr	-1908(ra) # 8000417e <begin_op>
      ilock(f->ip);
    800048fa:	01893503          	ld	a0,24(s2)
    800048fe:	fffff097          	auipc	ra,0xfffff
    80004902:	eb2080e7          	jalr	-334(ra) # 800037b0 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004906:	8756                	mv	a4,s5
    80004908:	02092683          	lw	a3,32(s2)
    8000490c:	01698633          	add	a2,s3,s6
    80004910:	4585                	li	a1,1
    80004912:	01893503          	ld	a0,24(s2)
    80004916:	fffff097          	auipc	ra,0xfffff
    8000491a:	262080e7          	jalr	610(ra) # 80003b78 <writei>
    8000491e:	84aa                	mv	s1,a0
    80004920:	00a05763          	blez	a0,8000492e <filewrite+0xc0>
        f->off += r;
    80004924:	02092783          	lw	a5,32(s2)
    80004928:	9fa9                	addw	a5,a5,a0
    8000492a:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000492e:	01893503          	ld	a0,24(s2)
    80004932:	fffff097          	auipc	ra,0xfffff
    80004936:	f44080e7          	jalr	-188(ra) # 80003876 <iunlock>
      end_op();
    8000493a:	00000097          	auipc	ra,0x0
    8000493e:	8be080e7          	jalr	-1858(ra) # 800041f8 <end_op>

      if(r != n1){
    80004942:	029a9563          	bne	s5,s1,8000496c <filewrite+0xfe>
        // error from writei
        break;
      }
      i += r;
    80004946:	013489bb          	addw	s3,s1,s3
    while(i < n){
    8000494a:	0149da63          	bge	s3,s4,8000495e <filewrite+0xf0>
      int n1 = n - i;
    8000494e:	413a04bb          	subw	s1,s4,s3
      if(n1 > max)
    80004952:	0004879b          	sext.w	a5,s1
    80004956:	f8fbdce3          	bge	s7,a5,800048ee <filewrite+0x80>
    8000495a:	84e2                	mv	s1,s8
    8000495c:	bf49                	j	800048ee <filewrite+0x80>
    8000495e:	74e2                	ld	s1,56(sp)
    80004960:	6ae2                	ld	s5,24(sp)
    80004962:	6ba2                	ld	s7,8(sp)
    80004964:	6c02                	ld	s8,0(sp)
    80004966:	a039                	j	80004974 <filewrite+0x106>
    int i = 0;
    80004968:	4981                	li	s3,0
    8000496a:	a029                	j	80004974 <filewrite+0x106>
    8000496c:	74e2                	ld	s1,56(sp)
    8000496e:	6ae2                	ld	s5,24(sp)
    80004970:	6ba2                	ld	s7,8(sp)
    80004972:	6c02                	ld	s8,0(sp)
    }
    ret = (i == n ? n : -1);
    80004974:	033a1e63          	bne	s4,s3,800049b0 <filewrite+0x142>
    80004978:	8552                	mv	a0,s4
    8000497a:	79a2                	ld	s3,40(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    8000497c:	60a6                	ld	ra,72(sp)
    8000497e:	6406                	ld	s0,64(sp)
    80004980:	7942                	ld	s2,48(sp)
    80004982:	7a02                	ld	s4,32(sp)
    80004984:	6b42                	ld	s6,16(sp)
    80004986:	6161                	addi	sp,sp,80
    80004988:	8082                	ret
    8000498a:	fc26                	sd	s1,56(sp)
    8000498c:	f44e                	sd	s3,40(sp)
    8000498e:	ec56                	sd	s5,24(sp)
    80004990:	e45e                	sd	s7,8(sp)
    80004992:	e062                	sd	s8,0(sp)
    panic("filewrite");
    80004994:	00004517          	auipc	a0,0x4
    80004998:	c2c50513          	addi	a0,a0,-980 # 800085c0 <etext+0x5c0>
    8000499c:	ffffc097          	auipc	ra,0xffffc
    800049a0:	bc4080e7          	jalr	-1084(ra) # 80000560 <panic>
    return -1;
    800049a4:	557d                	li	a0,-1
}
    800049a6:	8082                	ret
      return -1;
    800049a8:	557d                	li	a0,-1
    800049aa:	bfc9                	j	8000497c <filewrite+0x10e>
    800049ac:	557d                	li	a0,-1
    800049ae:	b7f9                	j	8000497c <filewrite+0x10e>
    ret = (i == n ? n : -1);
    800049b0:	557d                	li	a0,-1
    800049b2:	79a2                	ld	s3,40(sp)
    800049b4:	b7e1                	j	8000497c <filewrite+0x10e>

00000000800049b6 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800049b6:	7179                	addi	sp,sp,-48
    800049b8:	f406                	sd	ra,40(sp)
    800049ba:	f022                	sd	s0,32(sp)
    800049bc:	ec26                	sd	s1,24(sp)
    800049be:	e052                	sd	s4,0(sp)
    800049c0:	1800                	addi	s0,sp,48
    800049c2:	84aa                	mv	s1,a0
    800049c4:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800049c6:	0005b023          	sd	zero,0(a1)
    800049ca:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800049ce:	00000097          	auipc	ra,0x0
    800049d2:	bbe080e7          	jalr	-1090(ra) # 8000458c <filealloc>
    800049d6:	e088                	sd	a0,0(s1)
    800049d8:	cd49                	beqz	a0,80004a72 <pipealloc+0xbc>
    800049da:	00000097          	auipc	ra,0x0
    800049de:	bb2080e7          	jalr	-1102(ra) # 8000458c <filealloc>
    800049e2:	00aa3023          	sd	a0,0(s4)
    800049e6:	c141                	beqz	a0,80004a66 <pipealloc+0xb0>
    800049e8:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800049ea:	ffffc097          	auipc	ra,0xffffc
    800049ee:	15e080e7          	jalr	350(ra) # 80000b48 <kalloc>
    800049f2:	892a                	mv	s2,a0
    800049f4:	c13d                	beqz	a0,80004a5a <pipealloc+0xa4>
    800049f6:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    800049f8:	4985                	li	s3,1
    800049fa:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800049fe:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004a02:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004a06:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004a0a:	00004597          	auipc	a1,0x4
    80004a0e:	bc658593          	addi	a1,a1,-1082 # 800085d0 <etext+0x5d0>
    80004a12:	ffffc097          	auipc	ra,0xffffc
    80004a16:	196080e7          	jalr	406(ra) # 80000ba8 <initlock>
  (*f0)->type = FD_PIPE;
    80004a1a:	609c                	ld	a5,0(s1)
    80004a1c:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004a20:	609c                	ld	a5,0(s1)
    80004a22:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004a26:	609c                	ld	a5,0(s1)
    80004a28:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004a2c:	609c                	ld	a5,0(s1)
    80004a2e:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004a32:	000a3783          	ld	a5,0(s4)
    80004a36:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004a3a:	000a3783          	ld	a5,0(s4)
    80004a3e:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004a42:	000a3783          	ld	a5,0(s4)
    80004a46:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004a4a:	000a3783          	ld	a5,0(s4)
    80004a4e:	0127b823          	sd	s2,16(a5)
  return 0;
    80004a52:	4501                	li	a0,0
    80004a54:	6942                	ld	s2,16(sp)
    80004a56:	69a2                	ld	s3,8(sp)
    80004a58:	a03d                	j	80004a86 <pipealloc+0xd0>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004a5a:	6088                	ld	a0,0(s1)
    80004a5c:	c119                	beqz	a0,80004a62 <pipealloc+0xac>
    80004a5e:	6942                	ld	s2,16(sp)
    80004a60:	a029                	j	80004a6a <pipealloc+0xb4>
    80004a62:	6942                	ld	s2,16(sp)
    80004a64:	a039                	j	80004a72 <pipealloc+0xbc>
    80004a66:	6088                	ld	a0,0(s1)
    80004a68:	c50d                	beqz	a0,80004a92 <pipealloc+0xdc>
    fileclose(*f0);
    80004a6a:	00000097          	auipc	ra,0x0
    80004a6e:	bde080e7          	jalr	-1058(ra) # 80004648 <fileclose>
  if(*f1)
    80004a72:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004a76:	557d                	li	a0,-1
  if(*f1)
    80004a78:	c799                	beqz	a5,80004a86 <pipealloc+0xd0>
    fileclose(*f1);
    80004a7a:	853e                	mv	a0,a5
    80004a7c:	00000097          	auipc	ra,0x0
    80004a80:	bcc080e7          	jalr	-1076(ra) # 80004648 <fileclose>
  return -1;
    80004a84:	557d                	li	a0,-1
}
    80004a86:	70a2                	ld	ra,40(sp)
    80004a88:	7402                	ld	s0,32(sp)
    80004a8a:	64e2                	ld	s1,24(sp)
    80004a8c:	6a02                	ld	s4,0(sp)
    80004a8e:	6145                	addi	sp,sp,48
    80004a90:	8082                	ret
  return -1;
    80004a92:	557d                	li	a0,-1
    80004a94:	bfcd                	j	80004a86 <pipealloc+0xd0>

0000000080004a96 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004a96:	1101                	addi	sp,sp,-32
    80004a98:	ec06                	sd	ra,24(sp)
    80004a9a:	e822                	sd	s0,16(sp)
    80004a9c:	e426                	sd	s1,8(sp)
    80004a9e:	e04a                	sd	s2,0(sp)
    80004aa0:	1000                	addi	s0,sp,32
    80004aa2:	84aa                	mv	s1,a0
    80004aa4:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004aa6:	ffffc097          	auipc	ra,0xffffc
    80004aaa:	192080e7          	jalr	402(ra) # 80000c38 <acquire>
  if(writable){
    80004aae:	02090d63          	beqz	s2,80004ae8 <pipeclose+0x52>
    pi->writeopen = 0;
    80004ab2:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004ab6:	21848513          	addi	a0,s1,536
    80004aba:	ffffd097          	auipc	ra,0xffffd
    80004abe:	6b6080e7          	jalr	1718(ra) # 80002170 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80004ac2:	2204b783          	ld	a5,544(s1)
    80004ac6:	eb95                	bnez	a5,80004afa <pipeclose+0x64>
    release(&pi->lock);
    80004ac8:	8526                	mv	a0,s1
    80004aca:	ffffc097          	auipc	ra,0xffffc
    80004ace:	222080e7          	jalr	546(ra) # 80000cec <release>
    kfree((char*)pi);
    80004ad2:	8526                	mv	a0,s1
    80004ad4:	ffffc097          	auipc	ra,0xffffc
    80004ad8:	f76080e7          	jalr	-138(ra) # 80000a4a <kfree>
  } else
    release(&pi->lock);
}
    80004adc:	60e2                	ld	ra,24(sp)
    80004ade:	6442                	ld	s0,16(sp)
    80004ae0:	64a2                	ld	s1,8(sp)
    80004ae2:	6902                	ld	s2,0(sp)
    80004ae4:	6105                	addi	sp,sp,32
    80004ae6:	8082                	ret
    pi->readopen = 0;
    80004ae8:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004aec:	21c48513          	addi	a0,s1,540
    80004af0:	ffffd097          	auipc	ra,0xffffd
    80004af4:	680080e7          	jalr	1664(ra) # 80002170 <wakeup>
    80004af8:	b7e9                	j	80004ac2 <pipeclose+0x2c>
    release(&pi->lock);
    80004afa:	8526                	mv	a0,s1
    80004afc:	ffffc097          	auipc	ra,0xffffc
    80004b00:	1f0080e7          	jalr	496(ra) # 80000cec <release>
}
    80004b04:	bfe1                	j	80004adc <pipeclose+0x46>

0000000080004b06 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004b06:	711d                	addi	sp,sp,-96
    80004b08:	ec86                	sd	ra,88(sp)
    80004b0a:	e8a2                	sd	s0,80(sp)
    80004b0c:	e4a6                	sd	s1,72(sp)
    80004b0e:	e0ca                	sd	s2,64(sp)
    80004b10:	fc4e                	sd	s3,56(sp)
    80004b12:	f852                	sd	s4,48(sp)
    80004b14:	f456                	sd	s5,40(sp)
    80004b16:	1080                	addi	s0,sp,96
    80004b18:	84aa                	mv	s1,a0
    80004b1a:	8aae                	mv	s5,a1
    80004b1c:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004b1e:	ffffd097          	auipc	ra,0xffffd
    80004b22:	f44080e7          	jalr	-188(ra) # 80001a62 <myproc>
    80004b26:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004b28:	8526                	mv	a0,s1
    80004b2a:	ffffc097          	auipc	ra,0xffffc
    80004b2e:	10e080e7          	jalr	270(ra) # 80000c38 <acquire>
  while(i < n){
    80004b32:	0d405863          	blez	s4,80004c02 <pipewrite+0xfc>
    80004b36:	f05a                	sd	s6,32(sp)
    80004b38:	ec5e                	sd	s7,24(sp)
    80004b3a:	e862                	sd	s8,16(sp)
  int i = 0;
    80004b3c:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004b3e:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004b40:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004b44:	21c48b93          	addi	s7,s1,540
    80004b48:	a089                	j	80004b8a <pipewrite+0x84>
      release(&pi->lock);
    80004b4a:	8526                	mv	a0,s1
    80004b4c:	ffffc097          	auipc	ra,0xffffc
    80004b50:	1a0080e7          	jalr	416(ra) # 80000cec <release>
      return -1;
    80004b54:	597d                	li	s2,-1
    80004b56:	7b02                	ld	s6,32(sp)
    80004b58:	6be2                	ld	s7,24(sp)
    80004b5a:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004b5c:	854a                	mv	a0,s2
    80004b5e:	60e6                	ld	ra,88(sp)
    80004b60:	6446                	ld	s0,80(sp)
    80004b62:	64a6                	ld	s1,72(sp)
    80004b64:	6906                	ld	s2,64(sp)
    80004b66:	79e2                	ld	s3,56(sp)
    80004b68:	7a42                	ld	s4,48(sp)
    80004b6a:	7aa2                	ld	s5,40(sp)
    80004b6c:	6125                	addi	sp,sp,96
    80004b6e:	8082                	ret
      wakeup(&pi->nread);
    80004b70:	8562                	mv	a0,s8
    80004b72:	ffffd097          	auipc	ra,0xffffd
    80004b76:	5fe080e7          	jalr	1534(ra) # 80002170 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004b7a:	85a6                	mv	a1,s1
    80004b7c:	855e                	mv	a0,s7
    80004b7e:	ffffd097          	auipc	ra,0xffffd
    80004b82:	58e080e7          	jalr	1422(ra) # 8000210c <sleep>
  while(i < n){
    80004b86:	05495f63          	bge	s2,s4,80004be4 <pipewrite+0xde>
    if(pi->readopen == 0 || killed(pr)){
    80004b8a:	2204a783          	lw	a5,544(s1)
    80004b8e:	dfd5                	beqz	a5,80004b4a <pipewrite+0x44>
    80004b90:	854e                	mv	a0,s3
    80004b92:	ffffe097          	auipc	ra,0xffffe
    80004b96:	822080e7          	jalr	-2014(ra) # 800023b4 <killed>
    80004b9a:	f945                	bnez	a0,80004b4a <pipewrite+0x44>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004b9c:	2184a783          	lw	a5,536(s1)
    80004ba0:	21c4a703          	lw	a4,540(s1)
    80004ba4:	2007879b          	addiw	a5,a5,512
    80004ba8:	fcf704e3          	beq	a4,a5,80004b70 <pipewrite+0x6a>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004bac:	4685                	li	a3,1
    80004bae:	01590633          	add	a2,s2,s5
    80004bb2:	faf40593          	addi	a1,s0,-81
    80004bb6:	0509b503          	ld	a0,80(s3)
    80004bba:	ffffd097          	auipc	ra,0xffffd
    80004bbe:	bb4080e7          	jalr	-1100(ra) # 8000176e <copyin>
    80004bc2:	05650263          	beq	a0,s6,80004c06 <pipewrite+0x100>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004bc6:	21c4a783          	lw	a5,540(s1)
    80004bca:	0017871b          	addiw	a4,a5,1
    80004bce:	20e4ae23          	sw	a4,540(s1)
    80004bd2:	1ff7f793          	andi	a5,a5,511
    80004bd6:	97a6                	add	a5,a5,s1
    80004bd8:	faf44703          	lbu	a4,-81(s0)
    80004bdc:	00e78c23          	sb	a4,24(a5)
      i++;
    80004be0:	2905                	addiw	s2,s2,1
    80004be2:	b755                	j	80004b86 <pipewrite+0x80>
    80004be4:	7b02                	ld	s6,32(sp)
    80004be6:	6be2                	ld	s7,24(sp)
    80004be8:	6c42                	ld	s8,16(sp)
  wakeup(&pi->nread);
    80004bea:	21848513          	addi	a0,s1,536
    80004bee:	ffffd097          	auipc	ra,0xffffd
    80004bf2:	582080e7          	jalr	1410(ra) # 80002170 <wakeup>
  release(&pi->lock);
    80004bf6:	8526                	mv	a0,s1
    80004bf8:	ffffc097          	auipc	ra,0xffffc
    80004bfc:	0f4080e7          	jalr	244(ra) # 80000cec <release>
  return i;
    80004c00:	bfb1                	j	80004b5c <pipewrite+0x56>
  int i = 0;
    80004c02:	4901                	li	s2,0
    80004c04:	b7dd                	j	80004bea <pipewrite+0xe4>
    80004c06:	7b02                	ld	s6,32(sp)
    80004c08:	6be2                	ld	s7,24(sp)
    80004c0a:	6c42                	ld	s8,16(sp)
    80004c0c:	bff9                	j	80004bea <pipewrite+0xe4>

0000000080004c0e <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004c0e:	715d                	addi	sp,sp,-80
    80004c10:	e486                	sd	ra,72(sp)
    80004c12:	e0a2                	sd	s0,64(sp)
    80004c14:	fc26                	sd	s1,56(sp)
    80004c16:	f84a                	sd	s2,48(sp)
    80004c18:	f44e                	sd	s3,40(sp)
    80004c1a:	f052                	sd	s4,32(sp)
    80004c1c:	ec56                	sd	s5,24(sp)
    80004c1e:	0880                	addi	s0,sp,80
    80004c20:	84aa                	mv	s1,a0
    80004c22:	892e                	mv	s2,a1
    80004c24:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004c26:	ffffd097          	auipc	ra,0xffffd
    80004c2a:	e3c080e7          	jalr	-452(ra) # 80001a62 <myproc>
    80004c2e:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80004c30:	8526                	mv	a0,s1
    80004c32:	ffffc097          	auipc	ra,0xffffc
    80004c36:	006080e7          	jalr	6(ra) # 80000c38 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004c3a:	2184a703          	lw	a4,536(s1)
    80004c3e:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004c42:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004c46:	02f71963          	bne	a4,a5,80004c78 <piperead+0x6a>
    80004c4a:	2244a783          	lw	a5,548(s1)
    80004c4e:	cf95                	beqz	a5,80004c8a <piperead+0x7c>
    if(killed(pr)){
    80004c50:	8552                	mv	a0,s4
    80004c52:	ffffd097          	auipc	ra,0xffffd
    80004c56:	762080e7          	jalr	1890(ra) # 800023b4 <killed>
    80004c5a:	e10d                	bnez	a0,80004c7c <piperead+0x6e>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004c5c:	85a6                	mv	a1,s1
    80004c5e:	854e                	mv	a0,s3
    80004c60:	ffffd097          	auipc	ra,0xffffd
    80004c64:	4ac080e7          	jalr	1196(ra) # 8000210c <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004c68:	2184a703          	lw	a4,536(s1)
    80004c6c:	21c4a783          	lw	a5,540(s1)
    80004c70:	fcf70de3          	beq	a4,a5,80004c4a <piperead+0x3c>
    80004c74:	e85a                	sd	s6,16(sp)
    80004c76:	a819                	j	80004c8c <piperead+0x7e>
    80004c78:	e85a                	sd	s6,16(sp)
    80004c7a:	a809                	j	80004c8c <piperead+0x7e>
      release(&pi->lock);
    80004c7c:	8526                	mv	a0,s1
    80004c7e:	ffffc097          	auipc	ra,0xffffc
    80004c82:	06e080e7          	jalr	110(ra) # 80000cec <release>
      return -1;
    80004c86:	59fd                	li	s3,-1
    80004c88:	a0a5                	j	80004cf0 <piperead+0xe2>
    80004c8a:	e85a                	sd	s6,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004c8c:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004c8e:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004c90:	05505463          	blez	s5,80004cd8 <piperead+0xca>
    if(pi->nread == pi->nwrite)
    80004c94:	2184a783          	lw	a5,536(s1)
    80004c98:	21c4a703          	lw	a4,540(s1)
    80004c9c:	02f70e63          	beq	a4,a5,80004cd8 <piperead+0xca>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80004ca0:	0017871b          	addiw	a4,a5,1
    80004ca4:	20e4ac23          	sw	a4,536(s1)
    80004ca8:	1ff7f793          	andi	a5,a5,511
    80004cac:	97a6                	add	a5,a5,s1
    80004cae:	0187c783          	lbu	a5,24(a5)
    80004cb2:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004cb6:	4685                	li	a3,1
    80004cb8:	fbf40613          	addi	a2,s0,-65
    80004cbc:	85ca                	mv	a1,s2
    80004cbe:	050a3503          	ld	a0,80(s4)
    80004cc2:	ffffd097          	auipc	ra,0xffffd
    80004cc6:	a20080e7          	jalr	-1504(ra) # 800016e2 <copyout>
    80004cca:	01650763          	beq	a0,s6,80004cd8 <piperead+0xca>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004cce:	2985                	addiw	s3,s3,1
    80004cd0:	0905                	addi	s2,s2,1
    80004cd2:	fd3a91e3          	bne	s5,s3,80004c94 <piperead+0x86>
    80004cd6:	89d6                	mv	s3,s5
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004cd8:	21c48513          	addi	a0,s1,540
    80004cdc:	ffffd097          	auipc	ra,0xffffd
    80004ce0:	494080e7          	jalr	1172(ra) # 80002170 <wakeup>
  release(&pi->lock);
    80004ce4:	8526                	mv	a0,s1
    80004ce6:	ffffc097          	auipc	ra,0xffffc
    80004cea:	006080e7          	jalr	6(ra) # 80000cec <release>
    80004cee:	6b42                	ld	s6,16(sp)
  return i;
}
    80004cf0:	854e                	mv	a0,s3
    80004cf2:	60a6                	ld	ra,72(sp)
    80004cf4:	6406                	ld	s0,64(sp)
    80004cf6:	74e2                	ld	s1,56(sp)
    80004cf8:	7942                	ld	s2,48(sp)
    80004cfa:	79a2                	ld	s3,40(sp)
    80004cfc:	7a02                	ld	s4,32(sp)
    80004cfe:	6ae2                	ld	s5,24(sp)
    80004d00:	6161                	addi	sp,sp,80
    80004d02:	8082                	ret

0000000080004d04 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80004d04:	1141                	addi	sp,sp,-16
    80004d06:	e422                	sd	s0,8(sp)
    80004d08:	0800                	addi	s0,sp,16
    80004d0a:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004d0c:	8905                	andi	a0,a0,1
    80004d0e:	050e                	slli	a0,a0,0x3
      perm = PTE_X;
    if(flags & 0x2)
    80004d10:	8b89                	andi	a5,a5,2
    80004d12:	c399                	beqz	a5,80004d18 <flags2perm+0x14>
      perm |= PTE_W;
    80004d14:	00456513          	ori	a0,a0,4
    return perm;
}
    80004d18:	6422                	ld	s0,8(sp)
    80004d1a:	0141                	addi	sp,sp,16
    80004d1c:	8082                	ret

0000000080004d1e <exec>:

int
exec(char *path, char **argv)
{
    80004d1e:	df010113          	addi	sp,sp,-528
    80004d22:	20113423          	sd	ra,520(sp)
    80004d26:	20813023          	sd	s0,512(sp)
    80004d2a:	ffa6                	sd	s1,504(sp)
    80004d2c:	fbca                	sd	s2,496(sp)
    80004d2e:	0c00                	addi	s0,sp,528
    80004d30:	892a                	mv	s2,a0
    80004d32:	dea43c23          	sd	a0,-520(s0)
    80004d36:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004d3a:	ffffd097          	auipc	ra,0xffffd
    80004d3e:	d28080e7          	jalr	-728(ra) # 80001a62 <myproc>
    80004d42:	84aa                	mv	s1,a0

  begin_op();
    80004d44:	fffff097          	auipc	ra,0xfffff
    80004d48:	43a080e7          	jalr	1082(ra) # 8000417e <begin_op>

  if((ip = namei(path)) == 0){
    80004d4c:	854a                	mv	a0,s2
    80004d4e:	fffff097          	auipc	ra,0xfffff
    80004d52:	230080e7          	jalr	560(ra) # 80003f7e <namei>
    80004d56:	c135                	beqz	a0,80004dba <exec+0x9c>
    80004d58:	f3d2                	sd	s4,480(sp)
    80004d5a:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004d5c:	fffff097          	auipc	ra,0xfffff
    80004d60:	a54080e7          	jalr	-1452(ra) # 800037b0 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004d64:	04000713          	li	a4,64
    80004d68:	4681                	li	a3,0
    80004d6a:	e5040613          	addi	a2,s0,-432
    80004d6e:	4581                	li	a1,0
    80004d70:	8552                	mv	a0,s4
    80004d72:	fffff097          	auipc	ra,0xfffff
    80004d76:	cf6080e7          	jalr	-778(ra) # 80003a68 <readi>
    80004d7a:	04000793          	li	a5,64
    80004d7e:	00f51a63          	bne	a0,a5,80004d92 <exec+0x74>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80004d82:	e5042703          	lw	a4,-432(s0)
    80004d86:	464c47b7          	lui	a5,0x464c4
    80004d8a:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004d8e:	02f70c63          	beq	a4,a5,80004dc6 <exec+0xa8>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004d92:	8552                	mv	a0,s4
    80004d94:	fffff097          	auipc	ra,0xfffff
    80004d98:	c82080e7          	jalr	-894(ra) # 80003a16 <iunlockput>
    end_op();
    80004d9c:	fffff097          	auipc	ra,0xfffff
    80004da0:	45c080e7          	jalr	1116(ra) # 800041f8 <end_op>
  }
  return -1;
    80004da4:	557d                	li	a0,-1
    80004da6:	7a1e                	ld	s4,480(sp)
}
    80004da8:	20813083          	ld	ra,520(sp)
    80004dac:	20013403          	ld	s0,512(sp)
    80004db0:	74fe                	ld	s1,504(sp)
    80004db2:	795e                	ld	s2,496(sp)
    80004db4:	21010113          	addi	sp,sp,528
    80004db8:	8082                	ret
    end_op();
    80004dba:	fffff097          	auipc	ra,0xfffff
    80004dbe:	43e080e7          	jalr	1086(ra) # 800041f8 <end_op>
    return -1;
    80004dc2:	557d                	li	a0,-1
    80004dc4:	b7d5                	j	80004da8 <exec+0x8a>
    80004dc6:	ebda                	sd	s6,464(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80004dc8:	8526                	mv	a0,s1
    80004dca:	ffffd097          	auipc	ra,0xffffd
    80004dce:	d5c080e7          	jalr	-676(ra) # 80001b26 <proc_pagetable>
    80004dd2:	8b2a                	mv	s6,a0
    80004dd4:	30050f63          	beqz	a0,800050f2 <exec+0x3d4>
    80004dd8:	f7ce                	sd	s3,488(sp)
    80004dda:	efd6                	sd	s5,472(sp)
    80004ddc:	e7de                	sd	s7,456(sp)
    80004dde:	e3e2                	sd	s8,448(sp)
    80004de0:	ff66                	sd	s9,440(sp)
    80004de2:	fb6a                	sd	s10,432(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004de4:	e7042d03          	lw	s10,-400(s0)
    80004de8:	e8845783          	lhu	a5,-376(s0)
    80004dec:	14078d63          	beqz	a5,80004f46 <exec+0x228>
    80004df0:	f76e                	sd	s11,424(sp)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004df2:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004df4:	4d81                	li	s11,0
    if(ph.vaddr % PGSIZE != 0)
    80004df6:	6c85                	lui	s9,0x1
    80004df8:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80004dfc:	def43823          	sd	a5,-528(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80004e00:	6a85                	lui	s5,0x1
    80004e02:	a0b5                	j	80004e6e <exec+0x150>
      panic("loadseg: address should exist");
    80004e04:	00003517          	auipc	a0,0x3
    80004e08:	7d450513          	addi	a0,a0,2004 # 800085d8 <etext+0x5d8>
    80004e0c:	ffffb097          	auipc	ra,0xffffb
    80004e10:	754080e7          	jalr	1876(ra) # 80000560 <panic>
    if(sz - i < PGSIZE)
    80004e14:	2481                	sext.w	s1,s1
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004e16:	8726                	mv	a4,s1
    80004e18:	012c06bb          	addw	a3,s8,s2
    80004e1c:	4581                	li	a1,0
    80004e1e:	8552                	mv	a0,s4
    80004e20:	fffff097          	auipc	ra,0xfffff
    80004e24:	c48080e7          	jalr	-952(ra) # 80003a68 <readi>
    80004e28:	2501                	sext.w	a0,a0
    80004e2a:	28a49863          	bne	s1,a0,800050ba <exec+0x39c>
  for(i = 0; i < sz; i += PGSIZE){
    80004e2e:	012a893b          	addw	s2,s5,s2
    80004e32:	03397563          	bgeu	s2,s3,80004e5c <exec+0x13e>
    pa = walkaddr(pagetable, va + i);
    80004e36:	02091593          	slli	a1,s2,0x20
    80004e3a:	9181                	srli	a1,a1,0x20
    80004e3c:	95de                	add	a1,a1,s7
    80004e3e:	855a                	mv	a0,s6
    80004e40:	ffffc097          	auipc	ra,0xffffc
    80004e44:	276080e7          	jalr	630(ra) # 800010b6 <walkaddr>
    80004e48:	862a                	mv	a2,a0
    if(pa == 0)
    80004e4a:	dd4d                	beqz	a0,80004e04 <exec+0xe6>
    if(sz - i < PGSIZE)
    80004e4c:	412984bb          	subw	s1,s3,s2
    80004e50:	0004879b          	sext.w	a5,s1
    80004e54:	fcfcf0e3          	bgeu	s9,a5,80004e14 <exec+0xf6>
    80004e58:	84d6                	mv	s1,s5
    80004e5a:	bf6d                	j	80004e14 <exec+0xf6>
    sz = sz1;
    80004e5c:	e0843903          	ld	s2,-504(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004e60:	2d85                	addiw	s11,s11,1
    80004e62:	038d0d1b          	addiw	s10,s10,56
    80004e66:	e8845783          	lhu	a5,-376(s0)
    80004e6a:	08fdd663          	bge	s11,a5,80004ef6 <exec+0x1d8>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004e6e:	2d01                	sext.w	s10,s10
    80004e70:	03800713          	li	a4,56
    80004e74:	86ea                	mv	a3,s10
    80004e76:	e1840613          	addi	a2,s0,-488
    80004e7a:	4581                	li	a1,0
    80004e7c:	8552                	mv	a0,s4
    80004e7e:	fffff097          	auipc	ra,0xfffff
    80004e82:	bea080e7          	jalr	-1046(ra) # 80003a68 <readi>
    80004e86:	03800793          	li	a5,56
    80004e8a:	20f51063          	bne	a0,a5,8000508a <exec+0x36c>
    if(ph.type != ELF_PROG_LOAD)
    80004e8e:	e1842783          	lw	a5,-488(s0)
    80004e92:	4705                	li	a4,1
    80004e94:	fce796e3          	bne	a5,a4,80004e60 <exec+0x142>
    if(ph.memsz < ph.filesz)
    80004e98:	e4043483          	ld	s1,-448(s0)
    80004e9c:	e3843783          	ld	a5,-456(s0)
    80004ea0:	1ef4e963          	bltu	s1,a5,80005092 <exec+0x374>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004ea4:	e2843783          	ld	a5,-472(s0)
    80004ea8:	94be                	add	s1,s1,a5
    80004eaa:	1ef4e863          	bltu	s1,a5,8000509a <exec+0x37c>
    if(ph.vaddr % PGSIZE != 0)
    80004eae:	df043703          	ld	a4,-528(s0)
    80004eb2:	8ff9                	and	a5,a5,a4
    80004eb4:	1e079763          	bnez	a5,800050a2 <exec+0x384>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004eb8:	e1c42503          	lw	a0,-484(s0)
    80004ebc:	00000097          	auipc	ra,0x0
    80004ec0:	e48080e7          	jalr	-440(ra) # 80004d04 <flags2perm>
    80004ec4:	86aa                	mv	a3,a0
    80004ec6:	8626                	mv	a2,s1
    80004ec8:	85ca                	mv	a1,s2
    80004eca:	855a                	mv	a0,s6
    80004ecc:	ffffc097          	auipc	ra,0xffffc
    80004ed0:	5ae080e7          	jalr	1454(ra) # 8000147a <uvmalloc>
    80004ed4:	e0a43423          	sd	a0,-504(s0)
    80004ed8:	1c050963          	beqz	a0,800050aa <exec+0x38c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004edc:	e2843b83          	ld	s7,-472(s0)
    80004ee0:	e2042c03          	lw	s8,-480(s0)
    80004ee4:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004ee8:	00098463          	beqz	s3,80004ef0 <exec+0x1d2>
    80004eec:	4901                	li	s2,0
    80004eee:	b7a1                	j	80004e36 <exec+0x118>
    sz = sz1;
    80004ef0:	e0843903          	ld	s2,-504(s0)
    80004ef4:	b7b5                	j	80004e60 <exec+0x142>
    80004ef6:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    80004ef8:	8552                	mv	a0,s4
    80004efa:	fffff097          	auipc	ra,0xfffff
    80004efe:	b1c080e7          	jalr	-1252(ra) # 80003a16 <iunlockput>
  end_op();
    80004f02:	fffff097          	auipc	ra,0xfffff
    80004f06:	2f6080e7          	jalr	758(ra) # 800041f8 <end_op>
  p = myproc();
    80004f0a:	ffffd097          	auipc	ra,0xffffd
    80004f0e:	b58080e7          	jalr	-1192(ra) # 80001a62 <myproc>
    80004f12:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80004f14:	04853c83          	ld	s9,72(a0)
  sz = PGROUNDUP(sz);
    80004f18:	6985                	lui	s3,0x1
    80004f1a:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80004f1c:	99ca                	add	s3,s3,s2
    80004f1e:	77fd                	lui	a5,0xfffff
    80004f20:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + 2*PGSIZE, PTE_W)) == 0)
    80004f24:	4691                	li	a3,4
    80004f26:	6609                	lui	a2,0x2
    80004f28:	964e                	add	a2,a2,s3
    80004f2a:	85ce                	mv	a1,s3
    80004f2c:	855a                	mv	a0,s6
    80004f2e:	ffffc097          	auipc	ra,0xffffc
    80004f32:	54c080e7          	jalr	1356(ra) # 8000147a <uvmalloc>
    80004f36:	892a                	mv	s2,a0
    80004f38:	e0a43423          	sd	a0,-504(s0)
    80004f3c:	e519                	bnez	a0,80004f4a <exec+0x22c>
  if(pagetable)
    80004f3e:	e1343423          	sd	s3,-504(s0)
    80004f42:	4a01                	li	s4,0
    80004f44:	aaa5                	j	800050bc <exec+0x39e>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004f46:	4901                	li	s2,0
    80004f48:	bf45                	j	80004ef8 <exec+0x1da>
  uvmclear(pagetable, sz-2*PGSIZE);
    80004f4a:	75f9                	lui	a1,0xffffe
    80004f4c:	95aa                	add	a1,a1,a0
    80004f4e:	855a                	mv	a0,s6
    80004f50:	ffffc097          	auipc	ra,0xffffc
    80004f54:	760080e7          	jalr	1888(ra) # 800016b0 <uvmclear>
  stackbase = sp - PGSIZE;
    80004f58:	7bfd                	lui	s7,0xfffff
    80004f5a:	9bca                	add	s7,s7,s2
  for(argc = 0; argv[argc]; argc++) {
    80004f5c:	e0043783          	ld	a5,-512(s0)
    80004f60:	6388                	ld	a0,0(a5)
    80004f62:	c52d                	beqz	a0,80004fcc <exec+0x2ae>
    80004f64:	e9040993          	addi	s3,s0,-368
    80004f68:	f9040c13          	addi	s8,s0,-112
    80004f6c:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004f6e:	ffffc097          	auipc	ra,0xffffc
    80004f72:	f3a080e7          	jalr	-198(ra) # 80000ea8 <strlen>
    80004f76:	0015079b          	addiw	a5,a0,1
    80004f7a:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004f7e:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004f82:	13796863          	bltu	s2,s7,800050b2 <exec+0x394>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004f86:	e0043d03          	ld	s10,-512(s0)
    80004f8a:	000d3a03          	ld	s4,0(s10)
    80004f8e:	8552                	mv	a0,s4
    80004f90:	ffffc097          	auipc	ra,0xffffc
    80004f94:	f18080e7          	jalr	-232(ra) # 80000ea8 <strlen>
    80004f98:	0015069b          	addiw	a3,a0,1
    80004f9c:	8652                	mv	a2,s4
    80004f9e:	85ca                	mv	a1,s2
    80004fa0:	855a                	mv	a0,s6
    80004fa2:	ffffc097          	auipc	ra,0xffffc
    80004fa6:	740080e7          	jalr	1856(ra) # 800016e2 <copyout>
    80004faa:	10054663          	bltz	a0,800050b6 <exec+0x398>
    ustack[argc] = sp;
    80004fae:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80004fb2:	0485                	addi	s1,s1,1
    80004fb4:	008d0793          	addi	a5,s10,8
    80004fb8:	e0f43023          	sd	a5,-512(s0)
    80004fbc:	008d3503          	ld	a0,8(s10)
    80004fc0:	c909                	beqz	a0,80004fd2 <exec+0x2b4>
    if(argc >= MAXARG)
    80004fc2:	09a1                	addi	s3,s3,8
    80004fc4:	fb8995e3          	bne	s3,s8,80004f6e <exec+0x250>
  ip = 0;
    80004fc8:	4a01                	li	s4,0
    80004fca:	a8cd                	j	800050bc <exec+0x39e>
  sp = sz;
    80004fcc:	e0843903          	ld	s2,-504(s0)
  for(argc = 0; argv[argc]; argc++) {
    80004fd0:	4481                	li	s1,0
  ustack[argc] = 0;
    80004fd2:	00349793          	slli	a5,s1,0x3
    80004fd6:	f9078793          	addi	a5,a5,-112 # ffffffffffffef90 <end+0xffffffff7ffda8a8>
    80004fda:	97a2                	add	a5,a5,s0
    80004fdc:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004fe0:	00148693          	addi	a3,s1,1
    80004fe4:	068e                	slli	a3,a3,0x3
    80004fe6:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004fea:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004fee:	e0843983          	ld	s3,-504(s0)
  if(sp < stackbase)
    80004ff2:	f57966e3          	bltu	s2,s7,80004f3e <exec+0x220>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004ff6:	e9040613          	addi	a2,s0,-368
    80004ffa:	85ca                	mv	a1,s2
    80004ffc:	855a                	mv	a0,s6
    80004ffe:	ffffc097          	auipc	ra,0xffffc
    80005002:	6e4080e7          	jalr	1764(ra) # 800016e2 <copyout>
    80005006:	0e054863          	bltz	a0,800050f6 <exec+0x3d8>
  p->trapframe->a1 = sp;
    8000500a:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    8000500e:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80005012:	df843783          	ld	a5,-520(s0)
    80005016:	0007c703          	lbu	a4,0(a5)
    8000501a:	cf11                	beqz	a4,80005036 <exec+0x318>
    8000501c:	0785                	addi	a5,a5,1
    if(*s == '/')
    8000501e:	02f00693          	li	a3,47
    80005022:	a039                	j	80005030 <exec+0x312>
      last = s+1;
    80005024:	def43c23          	sd	a5,-520(s0)
  for(last=s=path; *s; s++)
    80005028:	0785                	addi	a5,a5,1
    8000502a:	fff7c703          	lbu	a4,-1(a5)
    8000502e:	c701                	beqz	a4,80005036 <exec+0x318>
    if(*s == '/')
    80005030:	fed71ce3          	bne	a4,a3,80005028 <exec+0x30a>
    80005034:	bfc5                	j	80005024 <exec+0x306>
  safestrcpy(p->name, last, sizeof(p->name));
    80005036:	4641                	li	a2,16
    80005038:	df843583          	ld	a1,-520(s0)
    8000503c:	158a8513          	addi	a0,s5,344
    80005040:	ffffc097          	auipc	ra,0xffffc
    80005044:	e36080e7          	jalr	-458(ra) # 80000e76 <safestrcpy>
  oldpagetable = p->pagetable;
    80005048:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    8000504c:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80005050:	e0843783          	ld	a5,-504(s0)
    80005054:	04fab423          	sd	a5,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80005058:	058ab783          	ld	a5,88(s5)
    8000505c:	e6843703          	ld	a4,-408(s0)
    80005060:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80005062:	058ab783          	ld	a5,88(s5)
    80005066:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    8000506a:	85e6                	mv	a1,s9
    8000506c:	ffffd097          	auipc	ra,0xffffd
    80005070:	b56080e7          	jalr	-1194(ra) # 80001bc2 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80005074:	0004851b          	sext.w	a0,s1
    80005078:	79be                	ld	s3,488(sp)
    8000507a:	7a1e                	ld	s4,480(sp)
    8000507c:	6afe                	ld	s5,472(sp)
    8000507e:	6b5e                	ld	s6,464(sp)
    80005080:	6bbe                	ld	s7,456(sp)
    80005082:	6c1e                	ld	s8,448(sp)
    80005084:	7cfa                	ld	s9,440(sp)
    80005086:	7d5a                	ld	s10,432(sp)
    80005088:	b305                	j	80004da8 <exec+0x8a>
    8000508a:	e1243423          	sd	s2,-504(s0)
    8000508e:	7dba                	ld	s11,424(sp)
    80005090:	a035                	j	800050bc <exec+0x39e>
    80005092:	e1243423          	sd	s2,-504(s0)
    80005096:	7dba                	ld	s11,424(sp)
    80005098:	a015                	j	800050bc <exec+0x39e>
    8000509a:	e1243423          	sd	s2,-504(s0)
    8000509e:	7dba                	ld	s11,424(sp)
    800050a0:	a831                	j	800050bc <exec+0x39e>
    800050a2:	e1243423          	sd	s2,-504(s0)
    800050a6:	7dba                	ld	s11,424(sp)
    800050a8:	a811                	j	800050bc <exec+0x39e>
    800050aa:	e1243423          	sd	s2,-504(s0)
    800050ae:	7dba                	ld	s11,424(sp)
    800050b0:	a031                	j	800050bc <exec+0x39e>
  ip = 0;
    800050b2:	4a01                	li	s4,0
    800050b4:	a021                	j	800050bc <exec+0x39e>
    800050b6:	4a01                	li	s4,0
  if(pagetable)
    800050b8:	a011                	j	800050bc <exec+0x39e>
    800050ba:	7dba                	ld	s11,424(sp)
    proc_freepagetable(pagetable, sz);
    800050bc:	e0843583          	ld	a1,-504(s0)
    800050c0:	855a                	mv	a0,s6
    800050c2:	ffffd097          	auipc	ra,0xffffd
    800050c6:	b00080e7          	jalr	-1280(ra) # 80001bc2 <proc_freepagetable>
  return -1;
    800050ca:	557d                	li	a0,-1
  if(ip){
    800050cc:	000a1b63          	bnez	s4,800050e2 <exec+0x3c4>
    800050d0:	79be                	ld	s3,488(sp)
    800050d2:	7a1e                	ld	s4,480(sp)
    800050d4:	6afe                	ld	s5,472(sp)
    800050d6:	6b5e                	ld	s6,464(sp)
    800050d8:	6bbe                	ld	s7,456(sp)
    800050da:	6c1e                	ld	s8,448(sp)
    800050dc:	7cfa                	ld	s9,440(sp)
    800050de:	7d5a                	ld	s10,432(sp)
    800050e0:	b1e1                	j	80004da8 <exec+0x8a>
    800050e2:	79be                	ld	s3,488(sp)
    800050e4:	6afe                	ld	s5,472(sp)
    800050e6:	6b5e                	ld	s6,464(sp)
    800050e8:	6bbe                	ld	s7,456(sp)
    800050ea:	6c1e                	ld	s8,448(sp)
    800050ec:	7cfa                	ld	s9,440(sp)
    800050ee:	7d5a                	ld	s10,432(sp)
    800050f0:	b14d                	j	80004d92 <exec+0x74>
    800050f2:	6b5e                	ld	s6,464(sp)
    800050f4:	b979                	j	80004d92 <exec+0x74>
  sz = sz1;
    800050f6:	e0843983          	ld	s3,-504(s0)
    800050fa:	b591                	j	80004f3e <exec+0x220>

00000000800050fc <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    800050fc:	7179                	addi	sp,sp,-48
    800050fe:	f406                	sd	ra,40(sp)
    80005100:	f022                	sd	s0,32(sp)
    80005102:	ec26                	sd	s1,24(sp)
    80005104:	e84a                	sd	s2,16(sp)
    80005106:	1800                	addi	s0,sp,48
    80005108:	892e                	mv	s2,a1
    8000510a:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    8000510c:	fdc40593          	addi	a1,s0,-36
    80005110:	ffffe097          	auipc	ra,0xffffe
    80005114:	a72080e7          	jalr	-1422(ra) # 80002b82 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80005118:	fdc42703          	lw	a4,-36(s0)
    8000511c:	47bd                	li	a5,15
    8000511e:	02e7eb63          	bltu	a5,a4,80005154 <argfd+0x58>
    80005122:	ffffd097          	auipc	ra,0xffffd
    80005126:	940080e7          	jalr	-1728(ra) # 80001a62 <myproc>
    8000512a:	fdc42703          	lw	a4,-36(s0)
    8000512e:	01a70793          	addi	a5,a4,26
    80005132:	078e                	slli	a5,a5,0x3
    80005134:	953e                	add	a0,a0,a5
    80005136:	611c                	ld	a5,0(a0)
    80005138:	c385                	beqz	a5,80005158 <argfd+0x5c>
    return -1;
  if(pfd)
    8000513a:	00090463          	beqz	s2,80005142 <argfd+0x46>
    *pfd = fd;
    8000513e:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80005142:	4501                	li	a0,0
  if(pf)
    80005144:	c091                	beqz	s1,80005148 <argfd+0x4c>
    *pf = f;
    80005146:	e09c                	sd	a5,0(s1)
}
    80005148:	70a2                	ld	ra,40(sp)
    8000514a:	7402                	ld	s0,32(sp)
    8000514c:	64e2                	ld	s1,24(sp)
    8000514e:	6942                	ld	s2,16(sp)
    80005150:	6145                	addi	sp,sp,48
    80005152:	8082                	ret
    return -1;
    80005154:	557d                	li	a0,-1
    80005156:	bfcd                	j	80005148 <argfd+0x4c>
    80005158:	557d                	li	a0,-1
    8000515a:	b7fd                	j	80005148 <argfd+0x4c>

000000008000515c <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    8000515c:	1101                	addi	sp,sp,-32
    8000515e:	ec06                	sd	ra,24(sp)
    80005160:	e822                	sd	s0,16(sp)
    80005162:	e426                	sd	s1,8(sp)
    80005164:	1000                	addi	s0,sp,32
    80005166:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80005168:	ffffd097          	auipc	ra,0xffffd
    8000516c:	8fa080e7          	jalr	-1798(ra) # 80001a62 <myproc>
    80005170:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80005172:	0d050793          	addi	a5,a0,208
    80005176:	4501                	li	a0,0
    80005178:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    8000517a:	6398                	ld	a4,0(a5)
    8000517c:	cb19                	beqz	a4,80005192 <fdalloc+0x36>
  for(fd = 0; fd < NOFILE; fd++){
    8000517e:	2505                	addiw	a0,a0,1
    80005180:	07a1                	addi	a5,a5,8
    80005182:	fed51ce3          	bne	a0,a3,8000517a <fdalloc+0x1e>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80005186:	557d                	li	a0,-1
}
    80005188:	60e2                	ld	ra,24(sp)
    8000518a:	6442                	ld	s0,16(sp)
    8000518c:	64a2                	ld	s1,8(sp)
    8000518e:	6105                	addi	sp,sp,32
    80005190:	8082                	ret
      p->ofile[fd] = f;
    80005192:	01a50793          	addi	a5,a0,26
    80005196:	078e                	slli	a5,a5,0x3
    80005198:	963e                	add	a2,a2,a5
    8000519a:	e204                	sd	s1,0(a2)
      return fd;
    8000519c:	b7f5                	j	80005188 <fdalloc+0x2c>

000000008000519e <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    8000519e:	715d                	addi	sp,sp,-80
    800051a0:	e486                	sd	ra,72(sp)
    800051a2:	e0a2                	sd	s0,64(sp)
    800051a4:	fc26                	sd	s1,56(sp)
    800051a6:	f84a                	sd	s2,48(sp)
    800051a8:	f44e                	sd	s3,40(sp)
    800051aa:	ec56                	sd	s5,24(sp)
    800051ac:	e85a                	sd	s6,16(sp)
    800051ae:	0880                	addi	s0,sp,80
    800051b0:	8b2e                	mv	s6,a1
    800051b2:	89b2                	mv	s3,a2
    800051b4:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    800051b6:	fb040593          	addi	a1,s0,-80
    800051ba:	fffff097          	auipc	ra,0xfffff
    800051be:	de2080e7          	jalr	-542(ra) # 80003f9c <nameiparent>
    800051c2:	84aa                	mv	s1,a0
    800051c4:	14050e63          	beqz	a0,80005320 <create+0x182>
    return 0;

  ilock(dp);
    800051c8:	ffffe097          	auipc	ra,0xffffe
    800051cc:	5e8080e7          	jalr	1512(ra) # 800037b0 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    800051d0:	4601                	li	a2,0
    800051d2:	fb040593          	addi	a1,s0,-80
    800051d6:	8526                	mv	a0,s1
    800051d8:	fffff097          	auipc	ra,0xfffff
    800051dc:	ae4080e7          	jalr	-1308(ra) # 80003cbc <dirlookup>
    800051e0:	8aaa                	mv	s5,a0
    800051e2:	c539                	beqz	a0,80005230 <create+0x92>
    iunlockput(dp);
    800051e4:	8526                	mv	a0,s1
    800051e6:	fffff097          	auipc	ra,0xfffff
    800051ea:	830080e7          	jalr	-2000(ra) # 80003a16 <iunlockput>
    ilock(ip);
    800051ee:	8556                	mv	a0,s5
    800051f0:	ffffe097          	auipc	ra,0xffffe
    800051f4:	5c0080e7          	jalr	1472(ra) # 800037b0 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    800051f8:	4789                	li	a5,2
    800051fa:	02fb1463          	bne	s6,a5,80005222 <create+0x84>
    800051fe:	044ad783          	lhu	a5,68(s5)
    80005202:	37f9                	addiw	a5,a5,-2
    80005204:	17c2                	slli	a5,a5,0x30
    80005206:	93c1                	srli	a5,a5,0x30
    80005208:	4705                	li	a4,1
    8000520a:	00f76c63          	bltu	a4,a5,80005222 <create+0x84>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    8000520e:	8556                	mv	a0,s5
    80005210:	60a6                	ld	ra,72(sp)
    80005212:	6406                	ld	s0,64(sp)
    80005214:	74e2                	ld	s1,56(sp)
    80005216:	7942                	ld	s2,48(sp)
    80005218:	79a2                	ld	s3,40(sp)
    8000521a:	6ae2                	ld	s5,24(sp)
    8000521c:	6b42                	ld	s6,16(sp)
    8000521e:	6161                	addi	sp,sp,80
    80005220:	8082                	ret
    iunlockput(ip);
    80005222:	8556                	mv	a0,s5
    80005224:	ffffe097          	auipc	ra,0xffffe
    80005228:	7f2080e7          	jalr	2034(ra) # 80003a16 <iunlockput>
    return 0;
    8000522c:	4a81                	li	s5,0
    8000522e:	b7c5                	j	8000520e <create+0x70>
    80005230:	f052                	sd	s4,32(sp)
  if((ip = ialloc(dp->dev, type)) == 0){
    80005232:	85da                	mv	a1,s6
    80005234:	4088                	lw	a0,0(s1)
    80005236:	ffffe097          	auipc	ra,0xffffe
    8000523a:	3d6080e7          	jalr	982(ra) # 8000360c <ialloc>
    8000523e:	8a2a                	mv	s4,a0
    80005240:	c531                	beqz	a0,8000528c <create+0xee>
  ilock(ip);
    80005242:	ffffe097          	auipc	ra,0xffffe
    80005246:	56e080e7          	jalr	1390(ra) # 800037b0 <ilock>
  ip->major = major;
    8000524a:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    8000524e:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80005252:	4905                	li	s2,1
    80005254:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80005258:	8552                	mv	a0,s4
    8000525a:	ffffe097          	auipc	ra,0xffffe
    8000525e:	48a080e7          	jalr	1162(ra) # 800036e4 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80005262:	032b0d63          	beq	s6,s2,8000529c <create+0xfe>
  if(dirlink(dp, name, ip->inum) < 0)
    80005266:	004a2603          	lw	a2,4(s4)
    8000526a:	fb040593          	addi	a1,s0,-80
    8000526e:	8526                	mv	a0,s1
    80005270:	fffff097          	auipc	ra,0xfffff
    80005274:	c5c080e7          	jalr	-932(ra) # 80003ecc <dirlink>
    80005278:	08054163          	bltz	a0,800052fa <create+0x15c>
  iunlockput(dp);
    8000527c:	8526                	mv	a0,s1
    8000527e:	ffffe097          	auipc	ra,0xffffe
    80005282:	798080e7          	jalr	1944(ra) # 80003a16 <iunlockput>
  return ip;
    80005286:	8ad2                	mv	s5,s4
    80005288:	7a02                	ld	s4,32(sp)
    8000528a:	b751                	j	8000520e <create+0x70>
    iunlockput(dp);
    8000528c:	8526                	mv	a0,s1
    8000528e:	ffffe097          	auipc	ra,0xffffe
    80005292:	788080e7          	jalr	1928(ra) # 80003a16 <iunlockput>
    return 0;
    80005296:	8ad2                	mv	s5,s4
    80005298:	7a02                	ld	s4,32(sp)
    8000529a:	bf95                	j	8000520e <create+0x70>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    8000529c:	004a2603          	lw	a2,4(s4)
    800052a0:	00003597          	auipc	a1,0x3
    800052a4:	35858593          	addi	a1,a1,856 # 800085f8 <etext+0x5f8>
    800052a8:	8552                	mv	a0,s4
    800052aa:	fffff097          	auipc	ra,0xfffff
    800052ae:	c22080e7          	jalr	-990(ra) # 80003ecc <dirlink>
    800052b2:	04054463          	bltz	a0,800052fa <create+0x15c>
    800052b6:	40d0                	lw	a2,4(s1)
    800052b8:	00003597          	auipc	a1,0x3
    800052bc:	34858593          	addi	a1,a1,840 # 80008600 <etext+0x600>
    800052c0:	8552                	mv	a0,s4
    800052c2:	fffff097          	auipc	ra,0xfffff
    800052c6:	c0a080e7          	jalr	-1014(ra) # 80003ecc <dirlink>
    800052ca:	02054863          	bltz	a0,800052fa <create+0x15c>
  if(dirlink(dp, name, ip->inum) < 0)
    800052ce:	004a2603          	lw	a2,4(s4)
    800052d2:	fb040593          	addi	a1,s0,-80
    800052d6:	8526                	mv	a0,s1
    800052d8:	fffff097          	auipc	ra,0xfffff
    800052dc:	bf4080e7          	jalr	-1036(ra) # 80003ecc <dirlink>
    800052e0:	00054d63          	bltz	a0,800052fa <create+0x15c>
    dp->nlink++;  // for ".."
    800052e4:	04a4d783          	lhu	a5,74(s1)
    800052e8:	2785                	addiw	a5,a5,1
    800052ea:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800052ee:	8526                	mv	a0,s1
    800052f0:	ffffe097          	auipc	ra,0xffffe
    800052f4:	3f4080e7          	jalr	1012(ra) # 800036e4 <iupdate>
    800052f8:	b751                	j	8000527c <create+0xde>
  ip->nlink = 0;
    800052fa:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    800052fe:	8552                	mv	a0,s4
    80005300:	ffffe097          	auipc	ra,0xffffe
    80005304:	3e4080e7          	jalr	996(ra) # 800036e4 <iupdate>
  iunlockput(ip);
    80005308:	8552                	mv	a0,s4
    8000530a:	ffffe097          	auipc	ra,0xffffe
    8000530e:	70c080e7          	jalr	1804(ra) # 80003a16 <iunlockput>
  iunlockput(dp);
    80005312:	8526                	mv	a0,s1
    80005314:	ffffe097          	auipc	ra,0xffffe
    80005318:	702080e7          	jalr	1794(ra) # 80003a16 <iunlockput>
  return 0;
    8000531c:	7a02                	ld	s4,32(sp)
    8000531e:	bdc5                	j	8000520e <create+0x70>
    return 0;
    80005320:	8aaa                	mv	s5,a0
    80005322:	b5f5                	j	8000520e <create+0x70>

0000000080005324 <sys_dup>:
{
    80005324:	7179                	addi	sp,sp,-48
    80005326:	f406                	sd	ra,40(sp)
    80005328:	f022                	sd	s0,32(sp)
    8000532a:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    8000532c:	fd840613          	addi	a2,s0,-40
    80005330:	4581                	li	a1,0
    80005332:	4501                	li	a0,0
    80005334:	00000097          	auipc	ra,0x0
    80005338:	dc8080e7          	jalr	-568(ra) # 800050fc <argfd>
    return -1;
    8000533c:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    8000533e:	02054763          	bltz	a0,8000536c <sys_dup+0x48>
    80005342:	ec26                	sd	s1,24(sp)
    80005344:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80005346:	fd843903          	ld	s2,-40(s0)
    8000534a:	854a                	mv	a0,s2
    8000534c:	00000097          	auipc	ra,0x0
    80005350:	e10080e7          	jalr	-496(ra) # 8000515c <fdalloc>
    80005354:	84aa                	mv	s1,a0
    return -1;
    80005356:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80005358:	00054f63          	bltz	a0,80005376 <sys_dup+0x52>
  filedup(f);
    8000535c:	854a                	mv	a0,s2
    8000535e:	fffff097          	auipc	ra,0xfffff
    80005362:	298080e7          	jalr	664(ra) # 800045f6 <filedup>
  return fd;
    80005366:	87a6                	mv	a5,s1
    80005368:	64e2                	ld	s1,24(sp)
    8000536a:	6942                	ld	s2,16(sp)
}
    8000536c:	853e                	mv	a0,a5
    8000536e:	70a2                	ld	ra,40(sp)
    80005370:	7402                	ld	s0,32(sp)
    80005372:	6145                	addi	sp,sp,48
    80005374:	8082                	ret
    80005376:	64e2                	ld	s1,24(sp)
    80005378:	6942                	ld	s2,16(sp)
    8000537a:	bfcd                	j	8000536c <sys_dup+0x48>

000000008000537c <sys_read>:
{
    8000537c:	7179                	addi	sp,sp,-48
    8000537e:	f406                	sd	ra,40(sp)
    80005380:	f022                	sd	s0,32(sp)
    80005382:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80005384:	fd840593          	addi	a1,s0,-40
    80005388:	4505                	li	a0,1
    8000538a:	ffffe097          	auipc	ra,0xffffe
    8000538e:	818080e7          	jalr	-2024(ra) # 80002ba2 <argaddr>
  argint(2, &n);
    80005392:	fe440593          	addi	a1,s0,-28
    80005396:	4509                	li	a0,2
    80005398:	ffffd097          	auipc	ra,0xffffd
    8000539c:	7ea080e7          	jalr	2026(ra) # 80002b82 <argint>
  if(argfd(0, 0, &f) < 0)
    800053a0:	fe840613          	addi	a2,s0,-24
    800053a4:	4581                	li	a1,0
    800053a6:	4501                	li	a0,0
    800053a8:	00000097          	auipc	ra,0x0
    800053ac:	d54080e7          	jalr	-684(ra) # 800050fc <argfd>
    800053b0:	87aa                	mv	a5,a0
    return -1;
    800053b2:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800053b4:	0007cc63          	bltz	a5,800053cc <sys_read+0x50>
  return fileread(f, p, n);
    800053b8:	fe442603          	lw	a2,-28(s0)
    800053bc:	fd843583          	ld	a1,-40(s0)
    800053c0:	fe843503          	ld	a0,-24(s0)
    800053c4:	fffff097          	auipc	ra,0xfffff
    800053c8:	3d8080e7          	jalr	984(ra) # 8000479c <fileread>
}
    800053cc:	70a2                	ld	ra,40(sp)
    800053ce:	7402                	ld	s0,32(sp)
    800053d0:	6145                	addi	sp,sp,48
    800053d2:	8082                	ret

00000000800053d4 <sys_write>:
{
    800053d4:	7179                	addi	sp,sp,-48
    800053d6:	f406                	sd	ra,40(sp)
    800053d8:	f022                	sd	s0,32(sp)
    800053da:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800053dc:	fd840593          	addi	a1,s0,-40
    800053e0:	4505                	li	a0,1
    800053e2:	ffffd097          	auipc	ra,0xffffd
    800053e6:	7c0080e7          	jalr	1984(ra) # 80002ba2 <argaddr>
  argint(2, &n);
    800053ea:	fe440593          	addi	a1,s0,-28
    800053ee:	4509                	li	a0,2
    800053f0:	ffffd097          	auipc	ra,0xffffd
    800053f4:	792080e7          	jalr	1938(ra) # 80002b82 <argint>
  if(argfd(0, 0, &f) < 0)
    800053f8:	fe840613          	addi	a2,s0,-24
    800053fc:	4581                	li	a1,0
    800053fe:	4501                	li	a0,0
    80005400:	00000097          	auipc	ra,0x0
    80005404:	cfc080e7          	jalr	-772(ra) # 800050fc <argfd>
    80005408:	87aa                	mv	a5,a0
    return -1;
    8000540a:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000540c:	0007cc63          	bltz	a5,80005424 <sys_write+0x50>
  return filewrite(f, p, n);
    80005410:	fe442603          	lw	a2,-28(s0)
    80005414:	fd843583          	ld	a1,-40(s0)
    80005418:	fe843503          	ld	a0,-24(s0)
    8000541c:	fffff097          	auipc	ra,0xfffff
    80005420:	452080e7          	jalr	1106(ra) # 8000486e <filewrite>
}
    80005424:	70a2                	ld	ra,40(sp)
    80005426:	7402                	ld	s0,32(sp)
    80005428:	6145                	addi	sp,sp,48
    8000542a:	8082                	ret

000000008000542c <sys_close>:
{
    8000542c:	1101                	addi	sp,sp,-32
    8000542e:	ec06                	sd	ra,24(sp)
    80005430:	e822                	sd	s0,16(sp)
    80005432:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80005434:	fe040613          	addi	a2,s0,-32
    80005438:	fec40593          	addi	a1,s0,-20
    8000543c:	4501                	li	a0,0
    8000543e:	00000097          	auipc	ra,0x0
    80005442:	cbe080e7          	jalr	-834(ra) # 800050fc <argfd>
    return -1;
    80005446:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80005448:	02054463          	bltz	a0,80005470 <sys_close+0x44>
  myproc()->ofile[fd] = 0;
    8000544c:	ffffc097          	auipc	ra,0xffffc
    80005450:	616080e7          	jalr	1558(ra) # 80001a62 <myproc>
    80005454:	fec42783          	lw	a5,-20(s0)
    80005458:	07e9                	addi	a5,a5,26
    8000545a:	078e                	slli	a5,a5,0x3
    8000545c:	953e                	add	a0,a0,a5
    8000545e:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80005462:	fe043503          	ld	a0,-32(s0)
    80005466:	fffff097          	auipc	ra,0xfffff
    8000546a:	1e2080e7          	jalr	482(ra) # 80004648 <fileclose>
  return 0;
    8000546e:	4781                	li	a5,0
}
    80005470:	853e                	mv	a0,a5
    80005472:	60e2                	ld	ra,24(sp)
    80005474:	6442                	ld	s0,16(sp)
    80005476:	6105                	addi	sp,sp,32
    80005478:	8082                	ret

000000008000547a <sys_fstat>:
{
    8000547a:	1101                	addi	sp,sp,-32
    8000547c:	ec06                	sd	ra,24(sp)
    8000547e:	e822                	sd	s0,16(sp)
    80005480:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80005482:	fe040593          	addi	a1,s0,-32
    80005486:	4505                	li	a0,1
    80005488:	ffffd097          	auipc	ra,0xffffd
    8000548c:	71a080e7          	jalr	1818(ra) # 80002ba2 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80005490:	fe840613          	addi	a2,s0,-24
    80005494:	4581                	li	a1,0
    80005496:	4501                	li	a0,0
    80005498:	00000097          	auipc	ra,0x0
    8000549c:	c64080e7          	jalr	-924(ra) # 800050fc <argfd>
    800054a0:	87aa                	mv	a5,a0
    return -1;
    800054a2:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800054a4:	0007ca63          	bltz	a5,800054b8 <sys_fstat+0x3e>
  return filestat(f, st);
    800054a8:	fe043583          	ld	a1,-32(s0)
    800054ac:	fe843503          	ld	a0,-24(s0)
    800054b0:	fffff097          	auipc	ra,0xfffff
    800054b4:	27a080e7          	jalr	634(ra) # 8000472a <filestat>
}
    800054b8:	60e2                	ld	ra,24(sp)
    800054ba:	6442                	ld	s0,16(sp)
    800054bc:	6105                	addi	sp,sp,32
    800054be:	8082                	ret

00000000800054c0 <sys_link>:
{
    800054c0:	7169                	addi	sp,sp,-304
    800054c2:	f606                	sd	ra,296(sp)
    800054c4:	f222                	sd	s0,288(sp)
    800054c6:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800054c8:	08000613          	li	a2,128
    800054cc:	ed040593          	addi	a1,s0,-304
    800054d0:	4501                	li	a0,0
    800054d2:	ffffd097          	auipc	ra,0xffffd
    800054d6:	6f0080e7          	jalr	1776(ra) # 80002bc2 <argstr>
    return -1;
    800054da:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800054dc:	12054663          	bltz	a0,80005608 <sys_link+0x148>
    800054e0:	08000613          	li	a2,128
    800054e4:	f5040593          	addi	a1,s0,-176
    800054e8:	4505                	li	a0,1
    800054ea:	ffffd097          	auipc	ra,0xffffd
    800054ee:	6d8080e7          	jalr	1752(ra) # 80002bc2 <argstr>
    return -1;
    800054f2:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800054f4:	10054a63          	bltz	a0,80005608 <sys_link+0x148>
    800054f8:	ee26                	sd	s1,280(sp)
  begin_op();
    800054fa:	fffff097          	auipc	ra,0xfffff
    800054fe:	c84080e7          	jalr	-892(ra) # 8000417e <begin_op>
  if((ip = namei(old)) == 0){
    80005502:	ed040513          	addi	a0,s0,-304
    80005506:	fffff097          	auipc	ra,0xfffff
    8000550a:	a78080e7          	jalr	-1416(ra) # 80003f7e <namei>
    8000550e:	84aa                	mv	s1,a0
    80005510:	c949                	beqz	a0,800055a2 <sys_link+0xe2>
  ilock(ip);
    80005512:	ffffe097          	auipc	ra,0xffffe
    80005516:	29e080e7          	jalr	670(ra) # 800037b0 <ilock>
  if(ip->type == T_DIR){
    8000551a:	04449703          	lh	a4,68(s1)
    8000551e:	4785                	li	a5,1
    80005520:	08f70863          	beq	a4,a5,800055b0 <sys_link+0xf0>
    80005524:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80005526:	04a4d783          	lhu	a5,74(s1)
    8000552a:	2785                	addiw	a5,a5,1
    8000552c:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005530:	8526                	mv	a0,s1
    80005532:	ffffe097          	auipc	ra,0xffffe
    80005536:	1b2080e7          	jalr	434(ra) # 800036e4 <iupdate>
  iunlock(ip);
    8000553a:	8526                	mv	a0,s1
    8000553c:	ffffe097          	auipc	ra,0xffffe
    80005540:	33a080e7          	jalr	826(ra) # 80003876 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80005544:	fd040593          	addi	a1,s0,-48
    80005548:	f5040513          	addi	a0,s0,-176
    8000554c:	fffff097          	auipc	ra,0xfffff
    80005550:	a50080e7          	jalr	-1456(ra) # 80003f9c <nameiparent>
    80005554:	892a                	mv	s2,a0
    80005556:	cd35                	beqz	a0,800055d2 <sys_link+0x112>
  ilock(dp);
    80005558:	ffffe097          	auipc	ra,0xffffe
    8000555c:	258080e7          	jalr	600(ra) # 800037b0 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80005560:	00092703          	lw	a4,0(s2)
    80005564:	409c                	lw	a5,0(s1)
    80005566:	06f71163          	bne	a4,a5,800055c8 <sys_link+0x108>
    8000556a:	40d0                	lw	a2,4(s1)
    8000556c:	fd040593          	addi	a1,s0,-48
    80005570:	854a                	mv	a0,s2
    80005572:	fffff097          	auipc	ra,0xfffff
    80005576:	95a080e7          	jalr	-1702(ra) # 80003ecc <dirlink>
    8000557a:	04054763          	bltz	a0,800055c8 <sys_link+0x108>
  iunlockput(dp);
    8000557e:	854a                	mv	a0,s2
    80005580:	ffffe097          	auipc	ra,0xffffe
    80005584:	496080e7          	jalr	1174(ra) # 80003a16 <iunlockput>
  iput(ip);
    80005588:	8526                	mv	a0,s1
    8000558a:	ffffe097          	auipc	ra,0xffffe
    8000558e:	3e4080e7          	jalr	996(ra) # 8000396e <iput>
  end_op();
    80005592:	fffff097          	auipc	ra,0xfffff
    80005596:	c66080e7          	jalr	-922(ra) # 800041f8 <end_op>
  return 0;
    8000559a:	4781                	li	a5,0
    8000559c:	64f2                	ld	s1,280(sp)
    8000559e:	6952                	ld	s2,272(sp)
    800055a0:	a0a5                	j	80005608 <sys_link+0x148>
    end_op();
    800055a2:	fffff097          	auipc	ra,0xfffff
    800055a6:	c56080e7          	jalr	-938(ra) # 800041f8 <end_op>
    return -1;
    800055aa:	57fd                	li	a5,-1
    800055ac:	64f2                	ld	s1,280(sp)
    800055ae:	a8a9                	j	80005608 <sys_link+0x148>
    iunlockput(ip);
    800055b0:	8526                	mv	a0,s1
    800055b2:	ffffe097          	auipc	ra,0xffffe
    800055b6:	464080e7          	jalr	1124(ra) # 80003a16 <iunlockput>
    end_op();
    800055ba:	fffff097          	auipc	ra,0xfffff
    800055be:	c3e080e7          	jalr	-962(ra) # 800041f8 <end_op>
    return -1;
    800055c2:	57fd                	li	a5,-1
    800055c4:	64f2                	ld	s1,280(sp)
    800055c6:	a089                	j	80005608 <sys_link+0x148>
    iunlockput(dp);
    800055c8:	854a                	mv	a0,s2
    800055ca:	ffffe097          	auipc	ra,0xffffe
    800055ce:	44c080e7          	jalr	1100(ra) # 80003a16 <iunlockput>
  ilock(ip);
    800055d2:	8526                	mv	a0,s1
    800055d4:	ffffe097          	auipc	ra,0xffffe
    800055d8:	1dc080e7          	jalr	476(ra) # 800037b0 <ilock>
  ip->nlink--;
    800055dc:	04a4d783          	lhu	a5,74(s1)
    800055e0:	37fd                	addiw	a5,a5,-1
    800055e2:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800055e6:	8526                	mv	a0,s1
    800055e8:	ffffe097          	auipc	ra,0xffffe
    800055ec:	0fc080e7          	jalr	252(ra) # 800036e4 <iupdate>
  iunlockput(ip);
    800055f0:	8526                	mv	a0,s1
    800055f2:	ffffe097          	auipc	ra,0xffffe
    800055f6:	424080e7          	jalr	1060(ra) # 80003a16 <iunlockput>
  end_op();
    800055fa:	fffff097          	auipc	ra,0xfffff
    800055fe:	bfe080e7          	jalr	-1026(ra) # 800041f8 <end_op>
  return -1;
    80005602:	57fd                	li	a5,-1
    80005604:	64f2                	ld	s1,280(sp)
    80005606:	6952                	ld	s2,272(sp)
}
    80005608:	853e                	mv	a0,a5
    8000560a:	70b2                	ld	ra,296(sp)
    8000560c:	7412                	ld	s0,288(sp)
    8000560e:	6155                	addi	sp,sp,304
    80005610:	8082                	ret

0000000080005612 <sys_unlink>:
{
    80005612:	7151                	addi	sp,sp,-240
    80005614:	f586                	sd	ra,232(sp)
    80005616:	f1a2                	sd	s0,224(sp)
    80005618:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    8000561a:	08000613          	li	a2,128
    8000561e:	f3040593          	addi	a1,s0,-208
    80005622:	4501                	li	a0,0
    80005624:	ffffd097          	auipc	ra,0xffffd
    80005628:	59e080e7          	jalr	1438(ra) # 80002bc2 <argstr>
    8000562c:	1a054a63          	bltz	a0,800057e0 <sys_unlink+0x1ce>
    80005630:	eda6                	sd	s1,216(sp)
  begin_op();
    80005632:	fffff097          	auipc	ra,0xfffff
    80005636:	b4c080e7          	jalr	-1204(ra) # 8000417e <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    8000563a:	fb040593          	addi	a1,s0,-80
    8000563e:	f3040513          	addi	a0,s0,-208
    80005642:	fffff097          	auipc	ra,0xfffff
    80005646:	95a080e7          	jalr	-1702(ra) # 80003f9c <nameiparent>
    8000564a:	84aa                	mv	s1,a0
    8000564c:	cd71                	beqz	a0,80005728 <sys_unlink+0x116>
  ilock(dp);
    8000564e:	ffffe097          	auipc	ra,0xffffe
    80005652:	162080e7          	jalr	354(ra) # 800037b0 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80005656:	00003597          	auipc	a1,0x3
    8000565a:	fa258593          	addi	a1,a1,-94 # 800085f8 <etext+0x5f8>
    8000565e:	fb040513          	addi	a0,s0,-80
    80005662:	ffffe097          	auipc	ra,0xffffe
    80005666:	640080e7          	jalr	1600(ra) # 80003ca2 <namecmp>
    8000566a:	14050c63          	beqz	a0,800057c2 <sys_unlink+0x1b0>
    8000566e:	00003597          	auipc	a1,0x3
    80005672:	f9258593          	addi	a1,a1,-110 # 80008600 <etext+0x600>
    80005676:	fb040513          	addi	a0,s0,-80
    8000567a:	ffffe097          	auipc	ra,0xffffe
    8000567e:	628080e7          	jalr	1576(ra) # 80003ca2 <namecmp>
    80005682:	14050063          	beqz	a0,800057c2 <sys_unlink+0x1b0>
    80005686:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80005688:	f2c40613          	addi	a2,s0,-212
    8000568c:	fb040593          	addi	a1,s0,-80
    80005690:	8526                	mv	a0,s1
    80005692:	ffffe097          	auipc	ra,0xffffe
    80005696:	62a080e7          	jalr	1578(ra) # 80003cbc <dirlookup>
    8000569a:	892a                	mv	s2,a0
    8000569c:	12050263          	beqz	a0,800057c0 <sys_unlink+0x1ae>
  ilock(ip);
    800056a0:	ffffe097          	auipc	ra,0xffffe
    800056a4:	110080e7          	jalr	272(ra) # 800037b0 <ilock>
  if(ip->nlink < 1)
    800056a8:	04a91783          	lh	a5,74(s2)
    800056ac:	08f05563          	blez	a5,80005736 <sys_unlink+0x124>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800056b0:	04491703          	lh	a4,68(s2)
    800056b4:	4785                	li	a5,1
    800056b6:	08f70963          	beq	a4,a5,80005748 <sys_unlink+0x136>
  memset(&de, 0, sizeof(de));
    800056ba:	4641                	li	a2,16
    800056bc:	4581                	li	a1,0
    800056be:	fc040513          	addi	a0,s0,-64
    800056c2:	ffffb097          	auipc	ra,0xffffb
    800056c6:	672080e7          	jalr	1650(ra) # 80000d34 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800056ca:	4741                	li	a4,16
    800056cc:	f2c42683          	lw	a3,-212(s0)
    800056d0:	fc040613          	addi	a2,s0,-64
    800056d4:	4581                	li	a1,0
    800056d6:	8526                	mv	a0,s1
    800056d8:	ffffe097          	auipc	ra,0xffffe
    800056dc:	4a0080e7          	jalr	1184(ra) # 80003b78 <writei>
    800056e0:	47c1                	li	a5,16
    800056e2:	0af51b63          	bne	a0,a5,80005798 <sys_unlink+0x186>
  if(ip->type == T_DIR){
    800056e6:	04491703          	lh	a4,68(s2)
    800056ea:	4785                	li	a5,1
    800056ec:	0af70f63          	beq	a4,a5,800057aa <sys_unlink+0x198>
  iunlockput(dp);
    800056f0:	8526                	mv	a0,s1
    800056f2:	ffffe097          	auipc	ra,0xffffe
    800056f6:	324080e7          	jalr	804(ra) # 80003a16 <iunlockput>
  ip->nlink--;
    800056fa:	04a95783          	lhu	a5,74(s2)
    800056fe:	37fd                	addiw	a5,a5,-1
    80005700:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80005704:	854a                	mv	a0,s2
    80005706:	ffffe097          	auipc	ra,0xffffe
    8000570a:	fde080e7          	jalr	-34(ra) # 800036e4 <iupdate>
  iunlockput(ip);
    8000570e:	854a                	mv	a0,s2
    80005710:	ffffe097          	auipc	ra,0xffffe
    80005714:	306080e7          	jalr	774(ra) # 80003a16 <iunlockput>
  end_op();
    80005718:	fffff097          	auipc	ra,0xfffff
    8000571c:	ae0080e7          	jalr	-1312(ra) # 800041f8 <end_op>
  return 0;
    80005720:	4501                	li	a0,0
    80005722:	64ee                	ld	s1,216(sp)
    80005724:	694e                	ld	s2,208(sp)
    80005726:	a84d                	j	800057d8 <sys_unlink+0x1c6>
    end_op();
    80005728:	fffff097          	auipc	ra,0xfffff
    8000572c:	ad0080e7          	jalr	-1328(ra) # 800041f8 <end_op>
    return -1;
    80005730:	557d                	li	a0,-1
    80005732:	64ee                	ld	s1,216(sp)
    80005734:	a055                	j	800057d8 <sys_unlink+0x1c6>
    80005736:	e5ce                	sd	s3,200(sp)
    panic("unlink: nlink < 1");
    80005738:	00003517          	auipc	a0,0x3
    8000573c:	ed050513          	addi	a0,a0,-304 # 80008608 <etext+0x608>
    80005740:	ffffb097          	auipc	ra,0xffffb
    80005744:	e20080e7          	jalr	-480(ra) # 80000560 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005748:	04c92703          	lw	a4,76(s2)
    8000574c:	02000793          	li	a5,32
    80005750:	f6e7f5e3          	bgeu	a5,a4,800056ba <sys_unlink+0xa8>
    80005754:	e5ce                	sd	s3,200(sp)
    80005756:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000575a:	4741                	li	a4,16
    8000575c:	86ce                	mv	a3,s3
    8000575e:	f1840613          	addi	a2,s0,-232
    80005762:	4581                	li	a1,0
    80005764:	854a                	mv	a0,s2
    80005766:	ffffe097          	auipc	ra,0xffffe
    8000576a:	302080e7          	jalr	770(ra) # 80003a68 <readi>
    8000576e:	47c1                	li	a5,16
    80005770:	00f51c63          	bne	a0,a5,80005788 <sys_unlink+0x176>
    if(de.inum != 0)
    80005774:	f1845783          	lhu	a5,-232(s0)
    80005778:	e7b5                	bnez	a5,800057e4 <sys_unlink+0x1d2>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000577a:	29c1                	addiw	s3,s3,16
    8000577c:	04c92783          	lw	a5,76(s2)
    80005780:	fcf9ede3          	bltu	s3,a5,8000575a <sys_unlink+0x148>
    80005784:	69ae                	ld	s3,200(sp)
    80005786:	bf15                	j	800056ba <sys_unlink+0xa8>
      panic("isdirempty: readi");
    80005788:	00003517          	auipc	a0,0x3
    8000578c:	e9850513          	addi	a0,a0,-360 # 80008620 <etext+0x620>
    80005790:	ffffb097          	auipc	ra,0xffffb
    80005794:	dd0080e7          	jalr	-560(ra) # 80000560 <panic>
    80005798:	e5ce                	sd	s3,200(sp)
    panic("unlink: writei");
    8000579a:	00003517          	auipc	a0,0x3
    8000579e:	e9e50513          	addi	a0,a0,-354 # 80008638 <etext+0x638>
    800057a2:	ffffb097          	auipc	ra,0xffffb
    800057a6:	dbe080e7          	jalr	-578(ra) # 80000560 <panic>
    dp->nlink--;
    800057aa:	04a4d783          	lhu	a5,74(s1)
    800057ae:	37fd                	addiw	a5,a5,-1
    800057b0:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800057b4:	8526                	mv	a0,s1
    800057b6:	ffffe097          	auipc	ra,0xffffe
    800057ba:	f2e080e7          	jalr	-210(ra) # 800036e4 <iupdate>
    800057be:	bf0d                	j	800056f0 <sys_unlink+0xde>
    800057c0:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800057c2:	8526                	mv	a0,s1
    800057c4:	ffffe097          	auipc	ra,0xffffe
    800057c8:	252080e7          	jalr	594(ra) # 80003a16 <iunlockput>
  end_op();
    800057cc:	fffff097          	auipc	ra,0xfffff
    800057d0:	a2c080e7          	jalr	-1492(ra) # 800041f8 <end_op>
  return -1;
    800057d4:	557d                	li	a0,-1
    800057d6:	64ee                	ld	s1,216(sp)
}
    800057d8:	70ae                	ld	ra,232(sp)
    800057da:	740e                	ld	s0,224(sp)
    800057dc:	616d                	addi	sp,sp,240
    800057de:	8082                	ret
    return -1;
    800057e0:	557d                	li	a0,-1
    800057e2:	bfdd                	j	800057d8 <sys_unlink+0x1c6>
    iunlockput(ip);
    800057e4:	854a                	mv	a0,s2
    800057e6:	ffffe097          	auipc	ra,0xffffe
    800057ea:	230080e7          	jalr	560(ra) # 80003a16 <iunlockput>
    goto bad;
    800057ee:	694e                	ld	s2,208(sp)
    800057f0:	69ae                	ld	s3,200(sp)
    800057f2:	bfc1                	j	800057c2 <sys_unlink+0x1b0>

00000000800057f4 <sys_open>:

uint64
sys_open(void)
{
    800057f4:	7131                	addi	sp,sp,-192
    800057f6:	fd06                	sd	ra,184(sp)
    800057f8:	f922                	sd	s0,176(sp)
    800057fa:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800057fc:	f4c40593          	addi	a1,s0,-180
    80005800:	4505                	li	a0,1
    80005802:	ffffd097          	auipc	ra,0xffffd
    80005806:	380080e7          	jalr	896(ra) # 80002b82 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000580a:	08000613          	li	a2,128
    8000580e:	f5040593          	addi	a1,s0,-176
    80005812:	4501                	li	a0,0
    80005814:	ffffd097          	auipc	ra,0xffffd
    80005818:	3ae080e7          	jalr	942(ra) # 80002bc2 <argstr>
    8000581c:	87aa                	mv	a5,a0
    return -1;
    8000581e:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    80005820:	0a07ce63          	bltz	a5,800058dc <sys_open+0xe8>
    80005824:	f526                	sd	s1,168(sp)

  begin_op();
    80005826:	fffff097          	auipc	ra,0xfffff
    8000582a:	958080e7          	jalr	-1704(ra) # 8000417e <begin_op>

  if(omode & O_CREATE){
    8000582e:	f4c42783          	lw	a5,-180(s0)
    80005832:	2007f793          	andi	a5,a5,512
    80005836:	cfd5                	beqz	a5,800058f2 <sys_open+0xfe>
    ip = create(path, T_FILE, 0, 0);
    80005838:	4681                	li	a3,0
    8000583a:	4601                	li	a2,0
    8000583c:	4589                	li	a1,2
    8000583e:	f5040513          	addi	a0,s0,-176
    80005842:	00000097          	auipc	ra,0x0
    80005846:	95c080e7          	jalr	-1700(ra) # 8000519e <create>
    8000584a:	84aa                	mv	s1,a0
    if(ip == 0){
    8000584c:	cd41                	beqz	a0,800058e4 <sys_open+0xf0>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    8000584e:	04449703          	lh	a4,68(s1)
    80005852:	478d                	li	a5,3
    80005854:	00f71763          	bne	a4,a5,80005862 <sys_open+0x6e>
    80005858:	0464d703          	lhu	a4,70(s1)
    8000585c:	47a5                	li	a5,9
    8000585e:	0ee7e163          	bltu	a5,a4,80005940 <sys_open+0x14c>
    80005862:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80005864:	fffff097          	auipc	ra,0xfffff
    80005868:	d28080e7          	jalr	-728(ra) # 8000458c <filealloc>
    8000586c:	892a                	mv	s2,a0
    8000586e:	c97d                	beqz	a0,80005964 <sys_open+0x170>
    80005870:	ed4e                	sd	s3,152(sp)
    80005872:	00000097          	auipc	ra,0x0
    80005876:	8ea080e7          	jalr	-1814(ra) # 8000515c <fdalloc>
    8000587a:	89aa                	mv	s3,a0
    8000587c:	0c054e63          	bltz	a0,80005958 <sys_open+0x164>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80005880:	04449703          	lh	a4,68(s1)
    80005884:	478d                	li	a5,3
    80005886:	0ef70c63          	beq	a4,a5,8000597e <sys_open+0x18a>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    8000588a:	4789                	li	a5,2
    8000588c:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80005890:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80005894:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80005898:	f4c42783          	lw	a5,-180(s0)
    8000589c:	0017c713          	xori	a4,a5,1
    800058a0:	8b05                	andi	a4,a4,1
    800058a2:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    800058a6:	0037f713          	andi	a4,a5,3
    800058aa:	00e03733          	snez	a4,a4
    800058ae:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    800058b2:	4007f793          	andi	a5,a5,1024
    800058b6:	c791                	beqz	a5,800058c2 <sys_open+0xce>
    800058b8:	04449703          	lh	a4,68(s1)
    800058bc:	4789                	li	a5,2
    800058be:	0cf70763          	beq	a4,a5,8000598c <sys_open+0x198>
    itrunc(ip);
  }

  iunlock(ip);
    800058c2:	8526                	mv	a0,s1
    800058c4:	ffffe097          	auipc	ra,0xffffe
    800058c8:	fb2080e7          	jalr	-78(ra) # 80003876 <iunlock>
  end_op();
    800058cc:	fffff097          	auipc	ra,0xfffff
    800058d0:	92c080e7          	jalr	-1748(ra) # 800041f8 <end_op>

  return fd;
    800058d4:	854e                	mv	a0,s3
    800058d6:	74aa                	ld	s1,168(sp)
    800058d8:	790a                	ld	s2,160(sp)
    800058da:	69ea                	ld	s3,152(sp)
}
    800058dc:	70ea                	ld	ra,184(sp)
    800058de:	744a                	ld	s0,176(sp)
    800058e0:	6129                	addi	sp,sp,192
    800058e2:	8082                	ret
      end_op();
    800058e4:	fffff097          	auipc	ra,0xfffff
    800058e8:	914080e7          	jalr	-1772(ra) # 800041f8 <end_op>
      return -1;
    800058ec:	557d                	li	a0,-1
    800058ee:	74aa                	ld	s1,168(sp)
    800058f0:	b7f5                	j	800058dc <sys_open+0xe8>
    if((ip = namei(path)) == 0){
    800058f2:	f5040513          	addi	a0,s0,-176
    800058f6:	ffffe097          	auipc	ra,0xffffe
    800058fa:	688080e7          	jalr	1672(ra) # 80003f7e <namei>
    800058fe:	84aa                	mv	s1,a0
    80005900:	c90d                	beqz	a0,80005932 <sys_open+0x13e>
    ilock(ip);
    80005902:	ffffe097          	auipc	ra,0xffffe
    80005906:	eae080e7          	jalr	-338(ra) # 800037b0 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    8000590a:	04449703          	lh	a4,68(s1)
    8000590e:	4785                	li	a5,1
    80005910:	f2f71fe3          	bne	a4,a5,8000584e <sys_open+0x5a>
    80005914:	f4c42783          	lw	a5,-180(s0)
    80005918:	d7a9                	beqz	a5,80005862 <sys_open+0x6e>
      iunlockput(ip);
    8000591a:	8526                	mv	a0,s1
    8000591c:	ffffe097          	auipc	ra,0xffffe
    80005920:	0fa080e7          	jalr	250(ra) # 80003a16 <iunlockput>
      end_op();
    80005924:	fffff097          	auipc	ra,0xfffff
    80005928:	8d4080e7          	jalr	-1836(ra) # 800041f8 <end_op>
      return -1;
    8000592c:	557d                	li	a0,-1
    8000592e:	74aa                	ld	s1,168(sp)
    80005930:	b775                	j	800058dc <sys_open+0xe8>
      end_op();
    80005932:	fffff097          	auipc	ra,0xfffff
    80005936:	8c6080e7          	jalr	-1850(ra) # 800041f8 <end_op>
      return -1;
    8000593a:	557d                	li	a0,-1
    8000593c:	74aa                	ld	s1,168(sp)
    8000593e:	bf79                	j	800058dc <sys_open+0xe8>
    iunlockput(ip);
    80005940:	8526                	mv	a0,s1
    80005942:	ffffe097          	auipc	ra,0xffffe
    80005946:	0d4080e7          	jalr	212(ra) # 80003a16 <iunlockput>
    end_op();
    8000594a:	fffff097          	auipc	ra,0xfffff
    8000594e:	8ae080e7          	jalr	-1874(ra) # 800041f8 <end_op>
    return -1;
    80005952:	557d                	li	a0,-1
    80005954:	74aa                	ld	s1,168(sp)
    80005956:	b759                	j	800058dc <sys_open+0xe8>
      fileclose(f);
    80005958:	854a                	mv	a0,s2
    8000595a:	fffff097          	auipc	ra,0xfffff
    8000595e:	cee080e7          	jalr	-786(ra) # 80004648 <fileclose>
    80005962:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80005964:	8526                	mv	a0,s1
    80005966:	ffffe097          	auipc	ra,0xffffe
    8000596a:	0b0080e7          	jalr	176(ra) # 80003a16 <iunlockput>
    end_op();
    8000596e:	fffff097          	auipc	ra,0xfffff
    80005972:	88a080e7          	jalr	-1910(ra) # 800041f8 <end_op>
    return -1;
    80005976:	557d                	li	a0,-1
    80005978:	74aa                	ld	s1,168(sp)
    8000597a:	790a                	ld	s2,160(sp)
    8000597c:	b785                	j	800058dc <sys_open+0xe8>
    f->type = FD_DEVICE;
    8000597e:	00f92023          	sw	a5,0(s2)
    f->major = ip->major;
    80005982:	04649783          	lh	a5,70(s1)
    80005986:	02f91223          	sh	a5,36(s2)
    8000598a:	b729                	j	80005894 <sys_open+0xa0>
    itrunc(ip);
    8000598c:	8526                	mv	a0,s1
    8000598e:	ffffe097          	auipc	ra,0xffffe
    80005992:	f34080e7          	jalr	-204(ra) # 800038c2 <itrunc>
    80005996:	b735                	j	800058c2 <sys_open+0xce>

0000000080005998 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005998:	7175                	addi	sp,sp,-144
    8000599a:	e506                	sd	ra,136(sp)
    8000599c:	e122                	sd	s0,128(sp)
    8000599e:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    800059a0:	ffffe097          	auipc	ra,0xffffe
    800059a4:	7de080e7          	jalr	2014(ra) # 8000417e <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    800059a8:	08000613          	li	a2,128
    800059ac:	f7040593          	addi	a1,s0,-144
    800059b0:	4501                	li	a0,0
    800059b2:	ffffd097          	auipc	ra,0xffffd
    800059b6:	210080e7          	jalr	528(ra) # 80002bc2 <argstr>
    800059ba:	02054963          	bltz	a0,800059ec <sys_mkdir+0x54>
    800059be:	4681                	li	a3,0
    800059c0:	4601                	li	a2,0
    800059c2:	4585                	li	a1,1
    800059c4:	f7040513          	addi	a0,s0,-144
    800059c8:	fffff097          	auipc	ra,0xfffff
    800059cc:	7d6080e7          	jalr	2006(ra) # 8000519e <create>
    800059d0:	cd11                	beqz	a0,800059ec <sys_mkdir+0x54>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800059d2:	ffffe097          	auipc	ra,0xffffe
    800059d6:	044080e7          	jalr	68(ra) # 80003a16 <iunlockput>
  end_op();
    800059da:	fffff097          	auipc	ra,0xfffff
    800059de:	81e080e7          	jalr	-2018(ra) # 800041f8 <end_op>
  return 0;
    800059e2:	4501                	li	a0,0
}
    800059e4:	60aa                	ld	ra,136(sp)
    800059e6:	640a                	ld	s0,128(sp)
    800059e8:	6149                	addi	sp,sp,144
    800059ea:	8082                	ret
    end_op();
    800059ec:	fffff097          	auipc	ra,0xfffff
    800059f0:	80c080e7          	jalr	-2036(ra) # 800041f8 <end_op>
    return -1;
    800059f4:	557d                	li	a0,-1
    800059f6:	b7fd                	j	800059e4 <sys_mkdir+0x4c>

00000000800059f8 <sys_mknod>:

uint64
sys_mknod(void)
{
    800059f8:	7135                	addi	sp,sp,-160
    800059fa:	ed06                	sd	ra,152(sp)
    800059fc:	e922                	sd	s0,144(sp)
    800059fe:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005a00:	ffffe097          	auipc	ra,0xffffe
    80005a04:	77e080e7          	jalr	1918(ra) # 8000417e <begin_op>
  argint(1, &major);
    80005a08:	f6c40593          	addi	a1,s0,-148
    80005a0c:	4505                	li	a0,1
    80005a0e:	ffffd097          	auipc	ra,0xffffd
    80005a12:	174080e7          	jalr	372(ra) # 80002b82 <argint>
  argint(2, &minor);
    80005a16:	f6840593          	addi	a1,s0,-152
    80005a1a:	4509                	li	a0,2
    80005a1c:	ffffd097          	auipc	ra,0xffffd
    80005a20:	166080e7          	jalr	358(ra) # 80002b82 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005a24:	08000613          	li	a2,128
    80005a28:	f7040593          	addi	a1,s0,-144
    80005a2c:	4501                	li	a0,0
    80005a2e:	ffffd097          	auipc	ra,0xffffd
    80005a32:	194080e7          	jalr	404(ra) # 80002bc2 <argstr>
    80005a36:	02054b63          	bltz	a0,80005a6c <sys_mknod+0x74>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80005a3a:	f6841683          	lh	a3,-152(s0)
    80005a3e:	f6c41603          	lh	a2,-148(s0)
    80005a42:	458d                	li	a1,3
    80005a44:	f7040513          	addi	a0,s0,-144
    80005a48:	fffff097          	auipc	ra,0xfffff
    80005a4c:	756080e7          	jalr	1878(ra) # 8000519e <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005a50:	cd11                	beqz	a0,80005a6c <sys_mknod+0x74>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005a52:	ffffe097          	auipc	ra,0xffffe
    80005a56:	fc4080e7          	jalr	-60(ra) # 80003a16 <iunlockput>
  end_op();
    80005a5a:	ffffe097          	auipc	ra,0xffffe
    80005a5e:	79e080e7          	jalr	1950(ra) # 800041f8 <end_op>
  return 0;
    80005a62:	4501                	li	a0,0
}
    80005a64:	60ea                	ld	ra,152(sp)
    80005a66:	644a                	ld	s0,144(sp)
    80005a68:	610d                	addi	sp,sp,160
    80005a6a:	8082                	ret
    end_op();
    80005a6c:	ffffe097          	auipc	ra,0xffffe
    80005a70:	78c080e7          	jalr	1932(ra) # 800041f8 <end_op>
    return -1;
    80005a74:	557d                	li	a0,-1
    80005a76:	b7fd                	j	80005a64 <sys_mknod+0x6c>

0000000080005a78 <sys_chdir>:

uint64
sys_chdir(void)
{
    80005a78:	7135                	addi	sp,sp,-160
    80005a7a:	ed06                	sd	ra,152(sp)
    80005a7c:	e922                	sd	s0,144(sp)
    80005a7e:	e14a                	sd	s2,128(sp)
    80005a80:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005a82:	ffffc097          	auipc	ra,0xffffc
    80005a86:	fe0080e7          	jalr	-32(ra) # 80001a62 <myproc>
    80005a8a:	892a                	mv	s2,a0
  
  begin_op();
    80005a8c:	ffffe097          	auipc	ra,0xffffe
    80005a90:	6f2080e7          	jalr	1778(ra) # 8000417e <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80005a94:	08000613          	li	a2,128
    80005a98:	f6040593          	addi	a1,s0,-160
    80005a9c:	4501                	li	a0,0
    80005a9e:	ffffd097          	auipc	ra,0xffffd
    80005aa2:	124080e7          	jalr	292(ra) # 80002bc2 <argstr>
    80005aa6:	04054d63          	bltz	a0,80005b00 <sys_chdir+0x88>
    80005aaa:	e526                	sd	s1,136(sp)
    80005aac:	f6040513          	addi	a0,s0,-160
    80005ab0:	ffffe097          	auipc	ra,0xffffe
    80005ab4:	4ce080e7          	jalr	1230(ra) # 80003f7e <namei>
    80005ab8:	84aa                	mv	s1,a0
    80005aba:	c131                	beqz	a0,80005afe <sys_chdir+0x86>
    end_op();
    return -1;
  }
  ilock(ip);
    80005abc:	ffffe097          	auipc	ra,0xffffe
    80005ac0:	cf4080e7          	jalr	-780(ra) # 800037b0 <ilock>
  if(ip->type != T_DIR){
    80005ac4:	04449703          	lh	a4,68(s1)
    80005ac8:	4785                	li	a5,1
    80005aca:	04f71163          	bne	a4,a5,80005b0c <sys_chdir+0x94>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80005ace:	8526                	mv	a0,s1
    80005ad0:	ffffe097          	auipc	ra,0xffffe
    80005ad4:	da6080e7          	jalr	-602(ra) # 80003876 <iunlock>
  iput(p->cwd);
    80005ad8:	15093503          	ld	a0,336(s2)
    80005adc:	ffffe097          	auipc	ra,0xffffe
    80005ae0:	e92080e7          	jalr	-366(ra) # 8000396e <iput>
  end_op();
    80005ae4:	ffffe097          	auipc	ra,0xffffe
    80005ae8:	714080e7          	jalr	1812(ra) # 800041f8 <end_op>
  p->cwd = ip;
    80005aec:	14993823          	sd	s1,336(s2)
  return 0;
    80005af0:	4501                	li	a0,0
    80005af2:	64aa                	ld	s1,136(sp)
}
    80005af4:	60ea                	ld	ra,152(sp)
    80005af6:	644a                	ld	s0,144(sp)
    80005af8:	690a                	ld	s2,128(sp)
    80005afa:	610d                	addi	sp,sp,160
    80005afc:	8082                	ret
    80005afe:	64aa                	ld	s1,136(sp)
    end_op();
    80005b00:	ffffe097          	auipc	ra,0xffffe
    80005b04:	6f8080e7          	jalr	1784(ra) # 800041f8 <end_op>
    return -1;
    80005b08:	557d                	li	a0,-1
    80005b0a:	b7ed                	j	80005af4 <sys_chdir+0x7c>
    iunlockput(ip);
    80005b0c:	8526                	mv	a0,s1
    80005b0e:	ffffe097          	auipc	ra,0xffffe
    80005b12:	f08080e7          	jalr	-248(ra) # 80003a16 <iunlockput>
    end_op();
    80005b16:	ffffe097          	auipc	ra,0xffffe
    80005b1a:	6e2080e7          	jalr	1762(ra) # 800041f8 <end_op>
    return -1;
    80005b1e:	557d                	li	a0,-1
    80005b20:	64aa                	ld	s1,136(sp)
    80005b22:	bfc9                	j	80005af4 <sys_chdir+0x7c>

0000000080005b24 <sys_exec>:

uint64
sys_exec(void)
{
    80005b24:	7121                	addi	sp,sp,-448
    80005b26:	ff06                	sd	ra,440(sp)
    80005b28:	fb22                	sd	s0,432(sp)
    80005b2a:	0380                	addi	s0,sp,448
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005b2c:	e4840593          	addi	a1,s0,-440
    80005b30:	4505                	li	a0,1
    80005b32:	ffffd097          	auipc	ra,0xffffd
    80005b36:	070080e7          	jalr	112(ra) # 80002ba2 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005b3a:	08000613          	li	a2,128
    80005b3e:	f5040593          	addi	a1,s0,-176
    80005b42:	4501                	li	a0,0
    80005b44:	ffffd097          	auipc	ra,0xffffd
    80005b48:	07e080e7          	jalr	126(ra) # 80002bc2 <argstr>
    80005b4c:	87aa                	mv	a5,a0
    return -1;
    80005b4e:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005b50:	0e07c263          	bltz	a5,80005c34 <sys_exec+0x110>
    80005b54:	f726                	sd	s1,424(sp)
    80005b56:	f34a                	sd	s2,416(sp)
    80005b58:	ef4e                	sd	s3,408(sp)
    80005b5a:	eb52                	sd	s4,400(sp)
  }
  memset(argv, 0, sizeof(argv));
    80005b5c:	10000613          	li	a2,256
    80005b60:	4581                	li	a1,0
    80005b62:	e5040513          	addi	a0,s0,-432
    80005b66:	ffffb097          	auipc	ra,0xffffb
    80005b6a:	1ce080e7          	jalr	462(ra) # 80000d34 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80005b6e:	e5040493          	addi	s1,s0,-432
  memset(argv, 0, sizeof(argv));
    80005b72:	89a6                	mv	s3,s1
    80005b74:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    80005b76:	02000a13          	li	s4,32
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005b7a:	00391513          	slli	a0,s2,0x3
    80005b7e:	e4040593          	addi	a1,s0,-448
    80005b82:	e4843783          	ld	a5,-440(s0)
    80005b86:	953e                	add	a0,a0,a5
    80005b88:	ffffd097          	auipc	ra,0xffffd
    80005b8c:	f5c080e7          	jalr	-164(ra) # 80002ae4 <fetchaddr>
    80005b90:	02054a63          	bltz	a0,80005bc4 <sys_exec+0xa0>
      goto bad;
    }
    if(uarg == 0){
    80005b94:	e4043783          	ld	a5,-448(s0)
    80005b98:	c7b9                	beqz	a5,80005be6 <sys_exec+0xc2>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80005b9a:	ffffb097          	auipc	ra,0xffffb
    80005b9e:	fae080e7          	jalr	-82(ra) # 80000b48 <kalloc>
    80005ba2:	85aa                	mv	a1,a0
    80005ba4:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    80005ba8:	cd11                	beqz	a0,80005bc4 <sys_exec+0xa0>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005baa:	6605                	lui	a2,0x1
    80005bac:	e4043503          	ld	a0,-448(s0)
    80005bb0:	ffffd097          	auipc	ra,0xffffd
    80005bb4:	f86080e7          	jalr	-122(ra) # 80002b36 <fetchstr>
    80005bb8:	00054663          	bltz	a0,80005bc4 <sys_exec+0xa0>
    if(i >= NELEM(argv)){
    80005bbc:	0905                	addi	s2,s2,1
    80005bbe:	09a1                	addi	s3,s3,8
    80005bc0:	fb491de3          	bne	s2,s4,80005b7a <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005bc4:	f5040913          	addi	s2,s0,-176
    80005bc8:	6088                	ld	a0,0(s1)
    80005bca:	c125                	beqz	a0,80005c2a <sys_exec+0x106>
    kfree(argv[i]);
    80005bcc:	ffffb097          	auipc	ra,0xffffb
    80005bd0:	e7e080e7          	jalr	-386(ra) # 80000a4a <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005bd4:	04a1                	addi	s1,s1,8
    80005bd6:	ff2499e3          	bne	s1,s2,80005bc8 <sys_exec+0xa4>
  return -1;
    80005bda:	557d                	li	a0,-1
    80005bdc:	74ba                	ld	s1,424(sp)
    80005bde:	791a                	ld	s2,416(sp)
    80005be0:	69fa                	ld	s3,408(sp)
    80005be2:	6a5a                	ld	s4,400(sp)
    80005be4:	a881                	j	80005c34 <sys_exec+0x110>
      argv[i] = 0;
    80005be6:	0009079b          	sext.w	a5,s2
    80005bea:	078e                	slli	a5,a5,0x3
    80005bec:	fd078793          	addi	a5,a5,-48
    80005bf0:	97a2                	add	a5,a5,s0
    80005bf2:	e807b023          	sd	zero,-384(a5)
  int ret = exec(path, argv);
    80005bf6:	e5040593          	addi	a1,s0,-432
    80005bfa:	f5040513          	addi	a0,s0,-176
    80005bfe:	fffff097          	auipc	ra,0xfffff
    80005c02:	120080e7          	jalr	288(ra) # 80004d1e <exec>
    80005c06:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005c08:	f5040993          	addi	s3,s0,-176
    80005c0c:	6088                	ld	a0,0(s1)
    80005c0e:	c901                	beqz	a0,80005c1e <sys_exec+0xfa>
    kfree(argv[i]);
    80005c10:	ffffb097          	auipc	ra,0xffffb
    80005c14:	e3a080e7          	jalr	-454(ra) # 80000a4a <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005c18:	04a1                	addi	s1,s1,8
    80005c1a:	ff3499e3          	bne	s1,s3,80005c0c <sys_exec+0xe8>
  return ret;
    80005c1e:	854a                	mv	a0,s2
    80005c20:	74ba                	ld	s1,424(sp)
    80005c22:	791a                	ld	s2,416(sp)
    80005c24:	69fa                	ld	s3,408(sp)
    80005c26:	6a5a                	ld	s4,400(sp)
    80005c28:	a031                	j	80005c34 <sys_exec+0x110>
  return -1;
    80005c2a:	557d                	li	a0,-1
    80005c2c:	74ba                	ld	s1,424(sp)
    80005c2e:	791a                	ld	s2,416(sp)
    80005c30:	69fa                	ld	s3,408(sp)
    80005c32:	6a5a                	ld	s4,400(sp)
}
    80005c34:	70fa                	ld	ra,440(sp)
    80005c36:	745a                	ld	s0,432(sp)
    80005c38:	6139                	addi	sp,sp,448
    80005c3a:	8082                	ret

0000000080005c3c <sys_pipe>:

uint64
sys_pipe(void)
{
    80005c3c:	7139                	addi	sp,sp,-64
    80005c3e:	fc06                	sd	ra,56(sp)
    80005c40:	f822                	sd	s0,48(sp)
    80005c42:	f426                	sd	s1,40(sp)
    80005c44:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005c46:	ffffc097          	auipc	ra,0xffffc
    80005c4a:	e1c080e7          	jalr	-484(ra) # 80001a62 <myproc>
    80005c4e:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005c50:	fd840593          	addi	a1,s0,-40
    80005c54:	4501                	li	a0,0
    80005c56:	ffffd097          	auipc	ra,0xffffd
    80005c5a:	f4c080e7          	jalr	-180(ra) # 80002ba2 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80005c5e:	fc840593          	addi	a1,s0,-56
    80005c62:	fd040513          	addi	a0,s0,-48
    80005c66:	fffff097          	auipc	ra,0xfffff
    80005c6a:	d50080e7          	jalr	-688(ra) # 800049b6 <pipealloc>
    return -1;
    80005c6e:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80005c70:	0c054463          	bltz	a0,80005d38 <sys_pipe+0xfc>
  fd0 = -1;
    80005c74:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80005c78:	fd043503          	ld	a0,-48(s0)
    80005c7c:	fffff097          	auipc	ra,0xfffff
    80005c80:	4e0080e7          	jalr	1248(ra) # 8000515c <fdalloc>
    80005c84:	fca42223          	sw	a0,-60(s0)
    80005c88:	08054b63          	bltz	a0,80005d1e <sys_pipe+0xe2>
    80005c8c:	fc843503          	ld	a0,-56(s0)
    80005c90:	fffff097          	auipc	ra,0xfffff
    80005c94:	4cc080e7          	jalr	1228(ra) # 8000515c <fdalloc>
    80005c98:	fca42023          	sw	a0,-64(s0)
    80005c9c:	06054863          	bltz	a0,80005d0c <sys_pipe+0xd0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005ca0:	4691                	li	a3,4
    80005ca2:	fc440613          	addi	a2,s0,-60
    80005ca6:	fd843583          	ld	a1,-40(s0)
    80005caa:	68a8                	ld	a0,80(s1)
    80005cac:	ffffc097          	auipc	ra,0xffffc
    80005cb0:	a36080e7          	jalr	-1482(ra) # 800016e2 <copyout>
    80005cb4:	02054063          	bltz	a0,80005cd4 <sys_pipe+0x98>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005cb8:	4691                	li	a3,4
    80005cba:	fc040613          	addi	a2,s0,-64
    80005cbe:	fd843583          	ld	a1,-40(s0)
    80005cc2:	0591                	addi	a1,a1,4
    80005cc4:	68a8                	ld	a0,80(s1)
    80005cc6:	ffffc097          	auipc	ra,0xffffc
    80005cca:	a1c080e7          	jalr	-1508(ra) # 800016e2 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005cce:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005cd0:	06055463          	bgez	a0,80005d38 <sys_pipe+0xfc>
    p->ofile[fd0] = 0;
    80005cd4:	fc442783          	lw	a5,-60(s0)
    80005cd8:	07e9                	addi	a5,a5,26
    80005cda:	078e                	slli	a5,a5,0x3
    80005cdc:	97a6                	add	a5,a5,s1
    80005cde:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005ce2:	fc042783          	lw	a5,-64(s0)
    80005ce6:	07e9                	addi	a5,a5,26
    80005ce8:	078e                	slli	a5,a5,0x3
    80005cea:	94be                	add	s1,s1,a5
    80005cec:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005cf0:	fd043503          	ld	a0,-48(s0)
    80005cf4:	fffff097          	auipc	ra,0xfffff
    80005cf8:	954080e7          	jalr	-1708(ra) # 80004648 <fileclose>
    fileclose(wf);
    80005cfc:	fc843503          	ld	a0,-56(s0)
    80005d00:	fffff097          	auipc	ra,0xfffff
    80005d04:	948080e7          	jalr	-1720(ra) # 80004648 <fileclose>
    return -1;
    80005d08:	57fd                	li	a5,-1
    80005d0a:	a03d                	j	80005d38 <sys_pipe+0xfc>
    if(fd0 >= 0)
    80005d0c:	fc442783          	lw	a5,-60(s0)
    80005d10:	0007c763          	bltz	a5,80005d1e <sys_pipe+0xe2>
      p->ofile[fd0] = 0;
    80005d14:	07e9                	addi	a5,a5,26
    80005d16:	078e                	slli	a5,a5,0x3
    80005d18:	97a6                	add	a5,a5,s1
    80005d1a:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005d1e:	fd043503          	ld	a0,-48(s0)
    80005d22:	fffff097          	auipc	ra,0xfffff
    80005d26:	926080e7          	jalr	-1754(ra) # 80004648 <fileclose>
    fileclose(wf);
    80005d2a:	fc843503          	ld	a0,-56(s0)
    80005d2e:	fffff097          	auipc	ra,0xfffff
    80005d32:	91a080e7          	jalr	-1766(ra) # 80004648 <fileclose>
    return -1;
    80005d36:	57fd                	li	a5,-1
}
    80005d38:	853e                	mv	a0,a5
    80005d3a:	70e2                	ld	ra,56(sp)
    80005d3c:	7442                	ld	s0,48(sp)
    80005d3e:	74a2                	ld	s1,40(sp)
    80005d40:	6121                	addi	sp,sp,64
    80005d42:	8082                	ret
	...

0000000080005d50 <kernelvec>:
    80005d50:	7111                	addi	sp,sp,-256
    80005d52:	e006                	sd	ra,0(sp)
    80005d54:	e40a                	sd	sp,8(sp)
    80005d56:	e80e                	sd	gp,16(sp)
    80005d58:	ec12                	sd	tp,24(sp)
    80005d5a:	f016                	sd	t0,32(sp)
    80005d5c:	f41a                	sd	t1,40(sp)
    80005d5e:	f81e                	sd	t2,48(sp)
    80005d60:	fc22                	sd	s0,56(sp)
    80005d62:	e0a6                	sd	s1,64(sp)
    80005d64:	e4aa                	sd	a0,72(sp)
    80005d66:	e8ae                	sd	a1,80(sp)
    80005d68:	ecb2                	sd	a2,88(sp)
    80005d6a:	f0b6                	sd	a3,96(sp)
    80005d6c:	f4ba                	sd	a4,104(sp)
    80005d6e:	f8be                	sd	a5,112(sp)
    80005d70:	fcc2                	sd	a6,120(sp)
    80005d72:	e146                	sd	a7,128(sp)
    80005d74:	e54a                	sd	s2,136(sp)
    80005d76:	e94e                	sd	s3,144(sp)
    80005d78:	ed52                	sd	s4,152(sp)
    80005d7a:	f156                	sd	s5,160(sp)
    80005d7c:	f55a                	sd	s6,168(sp)
    80005d7e:	f95e                	sd	s7,176(sp)
    80005d80:	fd62                	sd	s8,184(sp)
    80005d82:	e1e6                	sd	s9,192(sp)
    80005d84:	e5ea                	sd	s10,200(sp)
    80005d86:	e9ee                	sd	s11,208(sp)
    80005d88:	edf2                	sd	t3,216(sp)
    80005d8a:	f1f6                	sd	t4,224(sp)
    80005d8c:	f5fa                	sd	t5,232(sp)
    80005d8e:	f9fe                	sd	t6,240(sp)
    80005d90:	c21fc0ef          	jal	800029b0 <kerneltrap>
    80005d94:	6082                	ld	ra,0(sp)
    80005d96:	6122                	ld	sp,8(sp)
    80005d98:	61c2                	ld	gp,16(sp)
    80005d9a:	7282                	ld	t0,32(sp)
    80005d9c:	7322                	ld	t1,40(sp)
    80005d9e:	73c2                	ld	t2,48(sp)
    80005da0:	7462                	ld	s0,56(sp)
    80005da2:	6486                	ld	s1,64(sp)
    80005da4:	6526                	ld	a0,72(sp)
    80005da6:	65c6                	ld	a1,80(sp)
    80005da8:	6666                	ld	a2,88(sp)
    80005daa:	7686                	ld	a3,96(sp)
    80005dac:	7726                	ld	a4,104(sp)
    80005dae:	77c6                	ld	a5,112(sp)
    80005db0:	7866                	ld	a6,120(sp)
    80005db2:	688a                	ld	a7,128(sp)
    80005db4:	692a                	ld	s2,136(sp)
    80005db6:	69ca                	ld	s3,144(sp)
    80005db8:	6a6a                	ld	s4,152(sp)
    80005dba:	7a8a                	ld	s5,160(sp)
    80005dbc:	7b2a                	ld	s6,168(sp)
    80005dbe:	7bca                	ld	s7,176(sp)
    80005dc0:	7c6a                	ld	s8,184(sp)
    80005dc2:	6c8e                	ld	s9,192(sp)
    80005dc4:	6d2e                	ld	s10,200(sp)
    80005dc6:	6dce                	ld	s11,208(sp)
    80005dc8:	6e6e                	ld	t3,216(sp)
    80005dca:	7e8e                	ld	t4,224(sp)
    80005dcc:	7f2e                	ld	t5,232(sp)
    80005dce:	7fce                	ld	t6,240(sp)
    80005dd0:	6111                	addi	sp,sp,256
    80005dd2:	10200073          	sret
    80005dd6:	00000013          	nop
    80005dda:	00000013          	nop
    80005dde:	0001                	nop

0000000080005de0 <timervec>:
    80005de0:	34051573          	csrrw	a0,mscratch,a0
    80005de4:	e10c                	sd	a1,0(a0)
    80005de6:	e510                	sd	a2,8(a0)
    80005de8:	e914                	sd	a3,16(a0)
    80005dea:	6d0c                	ld	a1,24(a0)
    80005dec:	7110                	ld	a2,32(a0)
    80005dee:	6194                	ld	a3,0(a1)
    80005df0:	96b2                	add	a3,a3,a2
    80005df2:	e194                	sd	a3,0(a1)
    80005df4:	4589                	li	a1,2
    80005df6:	14459073          	csrw	sip,a1
    80005dfa:	6914                	ld	a3,16(a0)
    80005dfc:	6510                	ld	a2,8(a0)
    80005dfe:	610c                	ld	a1,0(a0)
    80005e00:	34051573          	csrrw	a0,mscratch,a0
    80005e04:	30200073          	mret
	...

0000000080005e0a <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    80005e0a:	1141                	addi	sp,sp,-16
    80005e0c:	e422                	sd	s0,8(sp)
    80005e0e:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005e10:	0c0007b7          	lui	a5,0xc000
    80005e14:	4705                	li	a4,1
    80005e16:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    80005e18:	0c0007b7          	lui	a5,0xc000
    80005e1c:	c3d8                	sw	a4,4(a5)
}
    80005e1e:	6422                	ld	s0,8(sp)
    80005e20:	0141                	addi	sp,sp,16
    80005e22:	8082                	ret

0000000080005e24 <plicinithart>:

void
plicinithart(void)
{
    80005e24:	1141                	addi	sp,sp,-16
    80005e26:	e406                	sd	ra,8(sp)
    80005e28:	e022                	sd	s0,0(sp)
    80005e2a:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005e2c:	ffffc097          	auipc	ra,0xffffc
    80005e30:	c0a080e7          	jalr	-1014(ra) # 80001a36 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005e34:	0085171b          	slliw	a4,a0,0x8
    80005e38:	0c0027b7          	lui	a5,0xc002
    80005e3c:	97ba                	add	a5,a5,a4
    80005e3e:	40200713          	li	a4,1026
    80005e42:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005e46:	00d5151b          	slliw	a0,a0,0xd
    80005e4a:	0c2017b7          	lui	a5,0xc201
    80005e4e:	97aa                	add	a5,a5,a0
    80005e50:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005e54:	60a2                	ld	ra,8(sp)
    80005e56:	6402                	ld	s0,0(sp)
    80005e58:	0141                	addi	sp,sp,16
    80005e5a:	8082                	ret

0000000080005e5c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80005e5c:	1141                	addi	sp,sp,-16
    80005e5e:	e406                	sd	ra,8(sp)
    80005e60:	e022                	sd	s0,0(sp)
    80005e62:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005e64:	ffffc097          	auipc	ra,0xffffc
    80005e68:	bd2080e7          	jalr	-1070(ra) # 80001a36 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005e6c:	00d5151b          	slliw	a0,a0,0xd
    80005e70:	0c2017b7          	lui	a5,0xc201
    80005e74:	97aa                	add	a5,a5,a0
  return irq;
}
    80005e76:	43c8                	lw	a0,4(a5)
    80005e78:	60a2                	ld	ra,8(sp)
    80005e7a:	6402                	ld	s0,0(sp)
    80005e7c:	0141                	addi	sp,sp,16
    80005e7e:	8082                	ret

0000000080005e80 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005e80:	1101                	addi	sp,sp,-32
    80005e82:	ec06                	sd	ra,24(sp)
    80005e84:	e822                	sd	s0,16(sp)
    80005e86:	e426                	sd	s1,8(sp)
    80005e88:	1000                	addi	s0,sp,32
    80005e8a:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005e8c:	ffffc097          	auipc	ra,0xffffc
    80005e90:	baa080e7          	jalr	-1110(ra) # 80001a36 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80005e94:	00d5151b          	slliw	a0,a0,0xd
    80005e98:	0c2017b7          	lui	a5,0xc201
    80005e9c:	97aa                	add	a5,a5,a0
    80005e9e:	c3c4                	sw	s1,4(a5)
}
    80005ea0:	60e2                	ld	ra,24(sp)
    80005ea2:	6442                	ld	s0,16(sp)
    80005ea4:	64a2                	ld	s1,8(sp)
    80005ea6:	6105                	addi	sp,sp,32
    80005ea8:	8082                	ret

0000000080005eaa <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005eaa:	1141                	addi	sp,sp,-16
    80005eac:	e406                	sd	ra,8(sp)
    80005eae:	e022                	sd	s0,0(sp)
    80005eb0:	0800                	addi	s0,sp,16
  if(i >= NUM)
    80005eb2:	479d                	li	a5,7
    80005eb4:	04a7cc63          	blt	a5,a0,80005f0c <free_desc+0x62>
    panic("free_desc 1");
  if(disk.free[i])
    80005eb8:	0001e797          	auipc	a5,0x1e
    80005ebc:	6f078793          	addi	a5,a5,1776 # 800245a8 <disk>
    80005ec0:	97aa                	add	a5,a5,a0
    80005ec2:	0187c783          	lbu	a5,24(a5)
    80005ec6:	ebb9                	bnez	a5,80005f1c <free_desc+0x72>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005ec8:	00451693          	slli	a3,a0,0x4
    80005ecc:	0001e797          	auipc	a5,0x1e
    80005ed0:	6dc78793          	addi	a5,a5,1756 # 800245a8 <disk>
    80005ed4:	6398                	ld	a4,0(a5)
    80005ed6:	9736                	add	a4,a4,a3
    80005ed8:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    80005edc:	6398                	ld	a4,0(a5)
    80005ede:	9736                	add	a4,a4,a3
    80005ee0:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80005ee4:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005ee8:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005eec:	97aa                	add	a5,a5,a0
    80005eee:	4705                	li	a4,1
    80005ef0:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80005ef4:	0001e517          	auipc	a0,0x1e
    80005ef8:	6cc50513          	addi	a0,a0,1740 # 800245c0 <disk+0x18>
    80005efc:	ffffc097          	auipc	ra,0xffffc
    80005f00:	274080e7          	jalr	628(ra) # 80002170 <wakeup>
}
    80005f04:	60a2                	ld	ra,8(sp)
    80005f06:	6402                	ld	s0,0(sp)
    80005f08:	0141                	addi	sp,sp,16
    80005f0a:	8082                	ret
    panic("free_desc 1");
    80005f0c:	00002517          	auipc	a0,0x2
    80005f10:	73c50513          	addi	a0,a0,1852 # 80008648 <etext+0x648>
    80005f14:	ffffa097          	auipc	ra,0xffffa
    80005f18:	64c080e7          	jalr	1612(ra) # 80000560 <panic>
    panic("free_desc 2");
    80005f1c:	00002517          	auipc	a0,0x2
    80005f20:	73c50513          	addi	a0,a0,1852 # 80008658 <etext+0x658>
    80005f24:	ffffa097          	auipc	ra,0xffffa
    80005f28:	63c080e7          	jalr	1596(ra) # 80000560 <panic>

0000000080005f2c <virtio_disk_init>:
{
    80005f2c:	1101                	addi	sp,sp,-32
    80005f2e:	ec06                	sd	ra,24(sp)
    80005f30:	e822                	sd	s0,16(sp)
    80005f32:	e426                	sd	s1,8(sp)
    80005f34:	e04a                	sd	s2,0(sp)
    80005f36:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005f38:	00002597          	auipc	a1,0x2
    80005f3c:	73058593          	addi	a1,a1,1840 # 80008668 <etext+0x668>
    80005f40:	0001e517          	auipc	a0,0x1e
    80005f44:	79050513          	addi	a0,a0,1936 # 800246d0 <disk+0x128>
    80005f48:	ffffb097          	auipc	ra,0xffffb
    80005f4c:	c60080e7          	jalr	-928(ra) # 80000ba8 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005f50:	100017b7          	lui	a5,0x10001
    80005f54:	4398                	lw	a4,0(a5)
    80005f56:	2701                	sext.w	a4,a4
    80005f58:	747277b7          	lui	a5,0x74727
    80005f5c:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005f60:	18f71c63          	bne	a4,a5,800060f8 <virtio_disk_init+0x1cc>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005f64:	100017b7          	lui	a5,0x10001
    80005f68:	0791                	addi	a5,a5,4 # 10001004 <_entry-0x6fffeffc>
    80005f6a:	439c                	lw	a5,0(a5)
    80005f6c:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005f6e:	4709                	li	a4,2
    80005f70:	18e79463          	bne	a5,a4,800060f8 <virtio_disk_init+0x1cc>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005f74:	100017b7          	lui	a5,0x10001
    80005f78:	07a1                	addi	a5,a5,8 # 10001008 <_entry-0x6fffeff8>
    80005f7a:	439c                	lw	a5,0(a5)
    80005f7c:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005f7e:	16e79d63          	bne	a5,a4,800060f8 <virtio_disk_init+0x1cc>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80005f82:	100017b7          	lui	a5,0x10001
    80005f86:	47d8                	lw	a4,12(a5)
    80005f88:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005f8a:	554d47b7          	lui	a5,0x554d4
    80005f8e:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005f92:	16f71363          	bne	a4,a5,800060f8 <virtio_disk_init+0x1cc>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005f96:	100017b7          	lui	a5,0x10001
    80005f9a:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005f9e:	4705                	li	a4,1
    80005fa0:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005fa2:	470d                	li	a4,3
    80005fa4:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005fa6:	10001737          	lui	a4,0x10001
    80005faa:	4b14                	lw	a3,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005fac:	c7ffe737          	lui	a4,0xc7ffe
    80005fb0:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fda077>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005fb4:	8ef9                	and	a3,a3,a4
    80005fb6:	10001737          	lui	a4,0x10001
    80005fba:	d314                	sw	a3,32(a4)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005fbc:	472d                	li	a4,11
    80005fbe:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005fc0:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80005fc4:	439c                	lw	a5,0(a5)
    80005fc6:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005fca:	8ba1                	andi	a5,a5,8
    80005fcc:	12078e63          	beqz	a5,80006108 <virtio_disk_init+0x1dc>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005fd0:	100017b7          	lui	a5,0x10001
    80005fd4:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005fd8:	100017b7          	lui	a5,0x10001
    80005fdc:	04478793          	addi	a5,a5,68 # 10001044 <_entry-0x6fffefbc>
    80005fe0:	439c                	lw	a5,0(a5)
    80005fe2:	2781                	sext.w	a5,a5
    80005fe4:	12079a63          	bnez	a5,80006118 <virtio_disk_init+0x1ec>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005fe8:	100017b7          	lui	a5,0x10001
    80005fec:	03478793          	addi	a5,a5,52 # 10001034 <_entry-0x6fffefcc>
    80005ff0:	439c                	lw	a5,0(a5)
    80005ff2:	2781                	sext.w	a5,a5
  if(max == 0)
    80005ff4:	12078a63          	beqz	a5,80006128 <virtio_disk_init+0x1fc>
  if(max < NUM)
    80005ff8:	471d                	li	a4,7
    80005ffa:	12f77f63          	bgeu	a4,a5,80006138 <virtio_disk_init+0x20c>
  disk.desc = kalloc();
    80005ffe:	ffffb097          	auipc	ra,0xffffb
    80006002:	b4a080e7          	jalr	-1206(ra) # 80000b48 <kalloc>
    80006006:	0001e497          	auipc	s1,0x1e
    8000600a:	5a248493          	addi	s1,s1,1442 # 800245a8 <disk>
    8000600e:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80006010:	ffffb097          	auipc	ra,0xffffb
    80006014:	b38080e7          	jalr	-1224(ra) # 80000b48 <kalloc>
    80006018:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    8000601a:	ffffb097          	auipc	ra,0xffffb
    8000601e:	b2e080e7          	jalr	-1234(ra) # 80000b48 <kalloc>
    80006022:	87aa                	mv	a5,a0
    80006024:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80006026:	6088                	ld	a0,0(s1)
    80006028:	12050063          	beqz	a0,80006148 <virtio_disk_init+0x21c>
    8000602c:	0001e717          	auipc	a4,0x1e
    80006030:	58473703          	ld	a4,1412(a4) # 800245b0 <disk+0x8>
    80006034:	10070a63          	beqz	a4,80006148 <virtio_disk_init+0x21c>
    80006038:	10078863          	beqz	a5,80006148 <virtio_disk_init+0x21c>
  memset(disk.desc, 0, PGSIZE);
    8000603c:	6605                	lui	a2,0x1
    8000603e:	4581                	li	a1,0
    80006040:	ffffb097          	auipc	ra,0xffffb
    80006044:	cf4080e7          	jalr	-780(ra) # 80000d34 <memset>
  memset(disk.avail, 0, PGSIZE);
    80006048:	0001e497          	auipc	s1,0x1e
    8000604c:	56048493          	addi	s1,s1,1376 # 800245a8 <disk>
    80006050:	6605                	lui	a2,0x1
    80006052:	4581                	li	a1,0
    80006054:	6488                	ld	a0,8(s1)
    80006056:	ffffb097          	auipc	ra,0xffffb
    8000605a:	cde080e7          	jalr	-802(ra) # 80000d34 <memset>
  memset(disk.used, 0, PGSIZE);
    8000605e:	6605                	lui	a2,0x1
    80006060:	4581                	li	a1,0
    80006062:	6888                	ld	a0,16(s1)
    80006064:	ffffb097          	auipc	ra,0xffffb
    80006068:	cd0080e7          	jalr	-816(ra) # 80000d34 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    8000606c:	100017b7          	lui	a5,0x10001
    80006070:	4721                	li	a4,8
    80006072:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80006074:	4098                	lw	a4,0(s1)
    80006076:	100017b7          	lui	a5,0x10001
    8000607a:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    8000607e:	40d8                	lw	a4,4(s1)
    80006080:	100017b7          	lui	a5,0x10001
    80006084:	08e7a223          	sw	a4,132(a5) # 10001084 <_entry-0x6fffef7c>
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80006088:	649c                	ld	a5,8(s1)
    8000608a:	0007869b          	sext.w	a3,a5
    8000608e:	10001737          	lui	a4,0x10001
    80006092:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80006096:	9781                	srai	a5,a5,0x20
    80006098:	10001737          	lui	a4,0x10001
    8000609c:	08f72a23          	sw	a5,148(a4) # 10001094 <_entry-0x6fffef6c>
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    800060a0:	689c                	ld	a5,16(s1)
    800060a2:	0007869b          	sext.w	a3,a5
    800060a6:	10001737          	lui	a4,0x10001
    800060aa:	0ad72023          	sw	a3,160(a4) # 100010a0 <_entry-0x6fffef60>
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    800060ae:	9781                	srai	a5,a5,0x20
    800060b0:	10001737          	lui	a4,0x10001
    800060b4:	0af72223          	sw	a5,164(a4) # 100010a4 <_entry-0x6fffef5c>
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    800060b8:	10001737          	lui	a4,0x10001
    800060bc:	4785                	li	a5,1
    800060be:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    800060c0:	00f48c23          	sb	a5,24(s1)
    800060c4:	00f48ca3          	sb	a5,25(s1)
    800060c8:	00f48d23          	sb	a5,26(s1)
    800060cc:	00f48da3          	sb	a5,27(s1)
    800060d0:	00f48e23          	sb	a5,28(s1)
    800060d4:	00f48ea3          	sb	a5,29(s1)
    800060d8:	00f48f23          	sb	a5,30(s1)
    800060dc:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    800060e0:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    800060e4:	100017b7          	lui	a5,0x10001
    800060e8:	0727a823          	sw	s2,112(a5) # 10001070 <_entry-0x6fffef90>
}
    800060ec:	60e2                	ld	ra,24(sp)
    800060ee:	6442                	ld	s0,16(sp)
    800060f0:	64a2                	ld	s1,8(sp)
    800060f2:	6902                	ld	s2,0(sp)
    800060f4:	6105                	addi	sp,sp,32
    800060f6:	8082                	ret
    panic("could not find virtio disk");
    800060f8:	00002517          	auipc	a0,0x2
    800060fc:	58050513          	addi	a0,a0,1408 # 80008678 <etext+0x678>
    80006100:	ffffa097          	auipc	ra,0xffffa
    80006104:	460080e7          	jalr	1120(ra) # 80000560 <panic>
    panic("virtio disk FEATURES_OK unset");
    80006108:	00002517          	auipc	a0,0x2
    8000610c:	59050513          	addi	a0,a0,1424 # 80008698 <etext+0x698>
    80006110:	ffffa097          	auipc	ra,0xffffa
    80006114:	450080e7          	jalr	1104(ra) # 80000560 <panic>
    panic("virtio disk should not be ready");
    80006118:	00002517          	auipc	a0,0x2
    8000611c:	5a050513          	addi	a0,a0,1440 # 800086b8 <etext+0x6b8>
    80006120:	ffffa097          	auipc	ra,0xffffa
    80006124:	440080e7          	jalr	1088(ra) # 80000560 <panic>
    panic("virtio disk has no queue 0");
    80006128:	00002517          	auipc	a0,0x2
    8000612c:	5b050513          	addi	a0,a0,1456 # 800086d8 <etext+0x6d8>
    80006130:	ffffa097          	auipc	ra,0xffffa
    80006134:	430080e7          	jalr	1072(ra) # 80000560 <panic>
    panic("virtio disk max queue too short");
    80006138:	00002517          	auipc	a0,0x2
    8000613c:	5c050513          	addi	a0,a0,1472 # 800086f8 <etext+0x6f8>
    80006140:	ffffa097          	auipc	ra,0xffffa
    80006144:	420080e7          	jalr	1056(ra) # 80000560 <panic>
    panic("virtio disk kalloc");
    80006148:	00002517          	auipc	a0,0x2
    8000614c:	5d050513          	addi	a0,a0,1488 # 80008718 <etext+0x718>
    80006150:	ffffa097          	auipc	ra,0xffffa
    80006154:	410080e7          	jalr	1040(ra) # 80000560 <panic>

0000000080006158 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80006158:	7159                	addi	sp,sp,-112
    8000615a:	f486                	sd	ra,104(sp)
    8000615c:	f0a2                	sd	s0,96(sp)
    8000615e:	eca6                	sd	s1,88(sp)
    80006160:	e8ca                	sd	s2,80(sp)
    80006162:	e4ce                	sd	s3,72(sp)
    80006164:	e0d2                	sd	s4,64(sp)
    80006166:	fc56                	sd	s5,56(sp)
    80006168:	f85a                	sd	s6,48(sp)
    8000616a:	f45e                	sd	s7,40(sp)
    8000616c:	f062                	sd	s8,32(sp)
    8000616e:	ec66                	sd	s9,24(sp)
    80006170:	1880                	addi	s0,sp,112
    80006172:	8a2a                	mv	s4,a0
    80006174:	8bae                	mv	s7,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80006176:	00c52c83          	lw	s9,12(a0)
    8000617a:	001c9c9b          	slliw	s9,s9,0x1
    8000617e:	1c82                	slli	s9,s9,0x20
    80006180:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    80006184:	0001e517          	auipc	a0,0x1e
    80006188:	54c50513          	addi	a0,a0,1356 # 800246d0 <disk+0x128>
    8000618c:	ffffb097          	auipc	ra,0xffffb
    80006190:	aac080e7          	jalr	-1364(ra) # 80000c38 <acquire>
  for(int i = 0; i < 3; i++){
    80006194:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    80006196:	44a1                	li	s1,8
      disk.free[i] = 0;
    80006198:	0001eb17          	auipc	s6,0x1e
    8000619c:	410b0b13          	addi	s6,s6,1040 # 800245a8 <disk>
  for(int i = 0; i < 3; i++){
    800061a0:	4a8d                	li	s5,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    800061a2:	0001ec17          	auipc	s8,0x1e
    800061a6:	52ec0c13          	addi	s8,s8,1326 # 800246d0 <disk+0x128>
    800061aa:	a0ad                	j	80006214 <virtio_disk_rw+0xbc>
      disk.free[i] = 0;
    800061ac:	00fb0733          	add	a4,s6,a5
    800061b0:	00070c23          	sb	zero,24(a4) # 10001018 <_entry-0x6fffefe8>
    idx[i] = alloc_desc();
    800061b4:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    800061b6:	0207c563          	bltz	a5,800061e0 <virtio_disk_rw+0x88>
  for(int i = 0; i < 3; i++){
    800061ba:	2905                	addiw	s2,s2,1
    800061bc:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    800061be:	05590f63          	beq	s2,s5,8000621c <virtio_disk_rw+0xc4>
    idx[i] = alloc_desc();
    800061c2:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    800061c4:	0001e717          	auipc	a4,0x1e
    800061c8:	3e470713          	addi	a4,a4,996 # 800245a8 <disk>
    800061cc:	87ce                	mv	a5,s3
    if(disk.free[i]){
    800061ce:	01874683          	lbu	a3,24(a4)
    800061d2:	fee9                	bnez	a3,800061ac <virtio_disk_rw+0x54>
  for(int i = 0; i < NUM; i++){
    800061d4:	2785                	addiw	a5,a5,1
    800061d6:	0705                	addi	a4,a4,1
    800061d8:	fe979be3          	bne	a5,s1,800061ce <virtio_disk_rw+0x76>
    idx[i] = alloc_desc();
    800061dc:	57fd                	li	a5,-1
    800061de:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    800061e0:	03205163          	blez	s2,80006202 <virtio_disk_rw+0xaa>
        free_desc(idx[j]);
    800061e4:	f9042503          	lw	a0,-112(s0)
    800061e8:	00000097          	auipc	ra,0x0
    800061ec:	cc2080e7          	jalr	-830(ra) # 80005eaa <free_desc>
      for(int j = 0; j < i; j++)
    800061f0:	4785                	li	a5,1
    800061f2:	0127d863          	bge	a5,s2,80006202 <virtio_disk_rw+0xaa>
        free_desc(idx[j]);
    800061f6:	f9442503          	lw	a0,-108(s0)
    800061fa:	00000097          	auipc	ra,0x0
    800061fe:	cb0080e7          	jalr	-848(ra) # 80005eaa <free_desc>
    sleep(&disk.free[0], &disk.vdisk_lock);
    80006202:	85e2                	mv	a1,s8
    80006204:	0001e517          	auipc	a0,0x1e
    80006208:	3bc50513          	addi	a0,a0,956 # 800245c0 <disk+0x18>
    8000620c:	ffffc097          	auipc	ra,0xffffc
    80006210:	f00080e7          	jalr	-256(ra) # 8000210c <sleep>
  for(int i = 0; i < 3; i++){
    80006214:	f9040613          	addi	a2,s0,-112
    80006218:	894e                	mv	s2,s3
    8000621a:	b765                	j	800061c2 <virtio_disk_rw+0x6a>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    8000621c:	f9042503          	lw	a0,-112(s0)
    80006220:	00451693          	slli	a3,a0,0x4

  if(write)
    80006224:	0001e797          	auipc	a5,0x1e
    80006228:	38478793          	addi	a5,a5,900 # 800245a8 <disk>
    8000622c:	00a50713          	addi	a4,a0,10
    80006230:	0712                	slli	a4,a4,0x4
    80006232:	973e                	add	a4,a4,a5
    80006234:	01703633          	snez	a2,s7
    80006238:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    8000623a:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    8000623e:	01973823          	sd	s9,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80006242:	6398                	ld	a4,0(a5)
    80006244:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80006246:	0a868613          	addi	a2,a3,168
    8000624a:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    8000624c:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    8000624e:	6390                	ld	a2,0(a5)
    80006250:	00d605b3          	add	a1,a2,a3
    80006254:	4741                	li	a4,16
    80006256:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80006258:	4805                	li	a6,1
    8000625a:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    8000625e:	f9442703          	lw	a4,-108(s0)
    80006262:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80006266:	0712                	slli	a4,a4,0x4
    80006268:	963a                	add	a2,a2,a4
    8000626a:	058a0593          	addi	a1,s4,88
    8000626e:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80006270:	0007b883          	ld	a7,0(a5)
    80006274:	9746                	add	a4,a4,a7
    80006276:	40000613          	li	a2,1024
    8000627a:	c710                	sw	a2,8(a4)
  if(write)
    8000627c:	001bb613          	seqz	a2,s7
    80006280:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80006284:	00166613          	ori	a2,a2,1
    80006288:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    8000628c:	f9842583          	lw	a1,-104(s0)
    80006290:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80006294:	00250613          	addi	a2,a0,2
    80006298:	0612                	slli	a2,a2,0x4
    8000629a:	963e                	add	a2,a2,a5
    8000629c:	577d                	li	a4,-1
    8000629e:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    800062a2:	0592                	slli	a1,a1,0x4
    800062a4:	98ae                	add	a7,a7,a1
    800062a6:	03068713          	addi	a4,a3,48
    800062aa:	973e                	add	a4,a4,a5
    800062ac:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    800062b0:	6398                	ld	a4,0(a5)
    800062b2:	972e                	add	a4,a4,a1
    800062b4:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    800062b8:	4689                	li	a3,2
    800062ba:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    800062be:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    800062c2:	010a2223          	sw	a6,4(s4)
  disk.info[idx[0]].b = b;
    800062c6:	01463423          	sd	s4,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    800062ca:	6794                	ld	a3,8(a5)
    800062cc:	0026d703          	lhu	a4,2(a3)
    800062d0:	8b1d                	andi	a4,a4,7
    800062d2:	0706                	slli	a4,a4,0x1
    800062d4:	96ba                	add	a3,a3,a4
    800062d6:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    800062da:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    800062de:	6798                	ld	a4,8(a5)
    800062e0:	00275783          	lhu	a5,2(a4)
    800062e4:	2785                	addiw	a5,a5,1
    800062e6:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    800062ea:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    800062ee:	100017b7          	lui	a5,0x10001
    800062f2:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    800062f6:	004a2783          	lw	a5,4(s4)
    sleep(b, &disk.vdisk_lock);
    800062fa:	0001e917          	auipc	s2,0x1e
    800062fe:	3d690913          	addi	s2,s2,982 # 800246d0 <disk+0x128>
  while(b->disk == 1) {
    80006302:	4485                	li	s1,1
    80006304:	01079c63          	bne	a5,a6,8000631c <virtio_disk_rw+0x1c4>
    sleep(b, &disk.vdisk_lock);
    80006308:	85ca                	mv	a1,s2
    8000630a:	8552                	mv	a0,s4
    8000630c:	ffffc097          	auipc	ra,0xffffc
    80006310:	e00080e7          	jalr	-512(ra) # 8000210c <sleep>
  while(b->disk == 1) {
    80006314:	004a2783          	lw	a5,4(s4)
    80006318:	fe9788e3          	beq	a5,s1,80006308 <virtio_disk_rw+0x1b0>
  }

  disk.info[idx[0]].b = 0;
    8000631c:	f9042903          	lw	s2,-112(s0)
    80006320:	00290713          	addi	a4,s2,2
    80006324:	0712                	slli	a4,a4,0x4
    80006326:	0001e797          	auipc	a5,0x1e
    8000632a:	28278793          	addi	a5,a5,642 # 800245a8 <disk>
    8000632e:	97ba                	add	a5,a5,a4
    80006330:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80006334:	0001e997          	auipc	s3,0x1e
    80006338:	27498993          	addi	s3,s3,628 # 800245a8 <disk>
    8000633c:	00491713          	slli	a4,s2,0x4
    80006340:	0009b783          	ld	a5,0(s3)
    80006344:	97ba                	add	a5,a5,a4
    80006346:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    8000634a:	854a                	mv	a0,s2
    8000634c:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80006350:	00000097          	auipc	ra,0x0
    80006354:	b5a080e7          	jalr	-1190(ra) # 80005eaa <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80006358:	8885                	andi	s1,s1,1
    8000635a:	f0ed                	bnez	s1,8000633c <virtio_disk_rw+0x1e4>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    8000635c:	0001e517          	auipc	a0,0x1e
    80006360:	37450513          	addi	a0,a0,884 # 800246d0 <disk+0x128>
    80006364:	ffffb097          	auipc	ra,0xffffb
    80006368:	988080e7          	jalr	-1656(ra) # 80000cec <release>
}
    8000636c:	70a6                	ld	ra,104(sp)
    8000636e:	7406                	ld	s0,96(sp)
    80006370:	64e6                	ld	s1,88(sp)
    80006372:	6946                	ld	s2,80(sp)
    80006374:	69a6                	ld	s3,72(sp)
    80006376:	6a06                	ld	s4,64(sp)
    80006378:	7ae2                	ld	s5,56(sp)
    8000637a:	7b42                	ld	s6,48(sp)
    8000637c:	7ba2                	ld	s7,40(sp)
    8000637e:	7c02                	ld	s8,32(sp)
    80006380:	6ce2                	ld	s9,24(sp)
    80006382:	6165                	addi	sp,sp,112
    80006384:	8082                	ret

0000000080006386 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80006386:	1101                	addi	sp,sp,-32
    80006388:	ec06                	sd	ra,24(sp)
    8000638a:	e822                	sd	s0,16(sp)
    8000638c:	e426                	sd	s1,8(sp)
    8000638e:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80006390:	0001e497          	auipc	s1,0x1e
    80006394:	21848493          	addi	s1,s1,536 # 800245a8 <disk>
    80006398:	0001e517          	auipc	a0,0x1e
    8000639c:	33850513          	addi	a0,a0,824 # 800246d0 <disk+0x128>
    800063a0:	ffffb097          	auipc	ra,0xffffb
    800063a4:	898080e7          	jalr	-1896(ra) # 80000c38 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    800063a8:	100017b7          	lui	a5,0x10001
    800063ac:	53b8                	lw	a4,96(a5)
    800063ae:	8b0d                	andi	a4,a4,3
    800063b0:	100017b7          	lui	a5,0x10001
    800063b4:	d3f8                	sw	a4,100(a5)

  __sync_synchronize();
    800063b6:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    800063ba:	689c                	ld	a5,16(s1)
    800063bc:	0204d703          	lhu	a4,32(s1)
    800063c0:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    800063c4:	04f70863          	beq	a4,a5,80006414 <virtio_disk_intr+0x8e>
    __sync_synchronize();
    800063c8:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    800063cc:	6898                	ld	a4,16(s1)
    800063ce:	0204d783          	lhu	a5,32(s1)
    800063d2:	8b9d                	andi	a5,a5,7
    800063d4:	078e                	slli	a5,a5,0x3
    800063d6:	97ba                	add	a5,a5,a4
    800063d8:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    800063da:	00278713          	addi	a4,a5,2
    800063de:	0712                	slli	a4,a4,0x4
    800063e0:	9726                	add	a4,a4,s1
    800063e2:	01074703          	lbu	a4,16(a4)
    800063e6:	e721                	bnez	a4,8000642e <virtio_disk_intr+0xa8>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    800063e8:	0789                	addi	a5,a5,2
    800063ea:	0792                	slli	a5,a5,0x4
    800063ec:	97a6                	add	a5,a5,s1
    800063ee:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    800063f0:	00052223          	sw	zero,4(a0)
    wakeup(b);
    800063f4:	ffffc097          	auipc	ra,0xffffc
    800063f8:	d7c080e7          	jalr	-644(ra) # 80002170 <wakeup>

    disk.used_idx += 1;
    800063fc:	0204d783          	lhu	a5,32(s1)
    80006400:	2785                	addiw	a5,a5,1
    80006402:	17c2                	slli	a5,a5,0x30
    80006404:	93c1                	srli	a5,a5,0x30
    80006406:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    8000640a:	6898                	ld	a4,16(s1)
    8000640c:	00275703          	lhu	a4,2(a4)
    80006410:	faf71ce3          	bne	a4,a5,800063c8 <virtio_disk_intr+0x42>
  }

  release(&disk.vdisk_lock);
    80006414:	0001e517          	auipc	a0,0x1e
    80006418:	2bc50513          	addi	a0,a0,700 # 800246d0 <disk+0x128>
    8000641c:	ffffb097          	auipc	ra,0xffffb
    80006420:	8d0080e7          	jalr	-1840(ra) # 80000cec <release>
}
    80006424:	60e2                	ld	ra,24(sp)
    80006426:	6442                	ld	s0,16(sp)
    80006428:	64a2                	ld	s1,8(sp)
    8000642a:	6105                	addi	sp,sp,32
    8000642c:	8082                	ret
      panic("virtio_disk_intr status");
    8000642e:	00002517          	auipc	a0,0x2
    80006432:	30250513          	addi	a0,a0,770 # 80008730 <etext+0x730>
    80006436:	ffffa097          	auipc	ra,0xffffa
    8000643a:	12a080e7          	jalr	298(ra) # 80000560 <panic>
	...

0000000080007000 <_trampoline>:
    80007000:	14051073          	csrw	sscratch,a0
    80007004:	02000537          	lui	a0,0x2000
    80007008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000700a:	0536                	slli	a0,a0,0xd
    8000700c:	02153423          	sd	ra,40(a0)
    80007010:	02253823          	sd	sp,48(a0)
    80007014:	02353c23          	sd	gp,56(a0)
    80007018:	04453023          	sd	tp,64(a0)
    8000701c:	04553423          	sd	t0,72(a0)
    80007020:	04653823          	sd	t1,80(a0)
    80007024:	04753c23          	sd	t2,88(a0)
    80007028:	f120                	sd	s0,96(a0)
    8000702a:	f524                	sd	s1,104(a0)
    8000702c:	fd2c                	sd	a1,120(a0)
    8000702e:	e150                	sd	a2,128(a0)
    80007030:	e554                	sd	a3,136(a0)
    80007032:	e958                	sd	a4,144(a0)
    80007034:	ed5c                	sd	a5,152(a0)
    80007036:	0b053023          	sd	a6,160(a0)
    8000703a:	0b153423          	sd	a7,168(a0)
    8000703e:	0b253823          	sd	s2,176(a0)
    80007042:	0b353c23          	sd	s3,184(a0)
    80007046:	0d453023          	sd	s4,192(a0)
    8000704a:	0d553423          	sd	s5,200(a0)
    8000704e:	0d653823          	sd	s6,208(a0)
    80007052:	0d753c23          	sd	s7,216(a0)
    80007056:	0f853023          	sd	s8,224(a0)
    8000705a:	0f953423          	sd	s9,232(a0)
    8000705e:	0fa53823          	sd	s10,240(a0)
    80007062:	0fb53c23          	sd	s11,248(a0)
    80007066:	11c53023          	sd	t3,256(a0)
    8000706a:	11d53423          	sd	t4,264(a0)
    8000706e:	11e53823          	sd	t5,272(a0)
    80007072:	11f53c23          	sd	t6,280(a0)
    80007076:	140022f3          	csrr	t0,sscratch
    8000707a:	06553823          	sd	t0,112(a0)
    8000707e:	00853103          	ld	sp,8(a0)
    80007082:	02053203          	ld	tp,32(a0)
    80007086:	01053283          	ld	t0,16(a0)
    8000708a:	00053303          	ld	t1,0(a0)
    8000708e:	12000073          	sfence.vma
    80007092:	18031073          	csrw	satp,t1
    80007096:	12000073          	sfence.vma
    8000709a:	8282                	jr	t0

000000008000709c <userret>:
    8000709c:	12000073          	sfence.vma
    800070a0:	18051073          	csrw	satp,a0
    800070a4:	12000073          	sfence.vma
    800070a8:	02000537          	lui	a0,0x2000
    800070ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800070ae:	0536                	slli	a0,a0,0xd
    800070b0:	02853083          	ld	ra,40(a0)
    800070b4:	03053103          	ld	sp,48(a0)
    800070b8:	03853183          	ld	gp,56(a0)
    800070bc:	04053203          	ld	tp,64(a0)
    800070c0:	04853283          	ld	t0,72(a0)
    800070c4:	05053303          	ld	t1,80(a0)
    800070c8:	05853383          	ld	t2,88(a0)
    800070cc:	7120                	ld	s0,96(a0)
    800070ce:	7524                	ld	s1,104(a0)
    800070d0:	7d2c                	ld	a1,120(a0)
    800070d2:	6150                	ld	a2,128(a0)
    800070d4:	6554                	ld	a3,136(a0)
    800070d6:	6958                	ld	a4,144(a0)
    800070d8:	6d5c                	ld	a5,152(a0)
    800070da:	0a053803          	ld	a6,160(a0)
    800070de:	0a853883          	ld	a7,168(a0)
    800070e2:	0b053903          	ld	s2,176(a0)
    800070e6:	0b853983          	ld	s3,184(a0)
    800070ea:	0c053a03          	ld	s4,192(a0)
    800070ee:	0c853a83          	ld	s5,200(a0)
    800070f2:	0d053b03          	ld	s6,208(a0)
    800070f6:	0d853b83          	ld	s7,216(a0)
    800070fa:	0e053c03          	ld	s8,224(a0)
    800070fe:	0e853c83          	ld	s9,232(a0)
    80007102:	0f053d03          	ld	s10,240(a0)
    80007106:	0f853d83          	ld	s11,248(a0)
    8000710a:	10053e03          	ld	t3,256(a0)
    8000710e:	10853e83          	ld	t4,264(a0)
    80007112:	11053f03          	ld	t5,272(a0)
    80007116:	11853f83          	ld	t6,280(a0)
    8000711a:	7928                	ld	a0,112(a0)
    8000711c:	10200073          	sret
	...
