user/getcnt.o: user/getcnt.c kernel/types.h kernel/stat.h user/user.h
