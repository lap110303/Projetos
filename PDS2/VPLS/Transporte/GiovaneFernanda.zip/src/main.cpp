#include <iostream>
#include <list>
#include <memory>
#include <string>
#include "Passageiro.hpp"
#include "Trem.hpp"
#include "Metro.hpp"
#include "Onibus.hpp"

using namespace std;

int main() {
    list<shared_ptr<Passageiro>> l_passageiro;
    unique_ptr<Trem> trem;
    unique_ptr<Metro> metro;
    unique_ptr<Onibus> onibus;

    string comando;
    while (cin >> comando) {
        if (comando == "add") {
            string nome;
            int idade;
            float saldo;
            cin >> nome >> idade >> saldo;
            l_passageiro.push_back(make_shared<Passageiro>(nome, idade, saldo));
        } else if (comando == "trem") {
            int capacidade;
            float valor;
            cin >> capacidade >> valor;
            trem = make_unique<Trem>(capacidade, valor);
            for (auto& p : l_passageiro) {
                trem->embarcar(p);
            }
            trem->mover();
            trem->desembarcar();
        } else if (comando == "metro") {
            int capacidade;
            float valor;
            cin >> capacidade >> valor;
            metro = make_unique<Metro>(capacidade, valor);
            for (auto& p : l_passageiro) {
                metro->embarcar(p);
            }
            metro->mover();
            metro->desembarcar();
        } else if (comando == "onibus") {
            int capacidade;
            float valor;
            cin >> capacidade >> valor;
            onibus = make_unique<Onibus>(capacidade, valor);
            for (auto& p : l_passageiro) {
                onibus->embarcar(p);
            }
            onibus->mover();
            onibus->desembarcar();
        }
    }

    return 0;
}