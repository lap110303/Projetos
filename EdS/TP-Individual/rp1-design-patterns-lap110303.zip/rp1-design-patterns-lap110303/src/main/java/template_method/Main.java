package template_method;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        // TODO: Add the books into library.
        // TODO: Create Regular and Premium users.
        // TODO: Borrow books for each user.
        // TODO: Return books for each user.
    }
}
