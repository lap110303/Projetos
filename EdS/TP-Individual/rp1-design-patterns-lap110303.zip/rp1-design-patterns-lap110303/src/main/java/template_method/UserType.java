package template_method;

public enum UserType {
    PREMIUM,
    REGULAR
}
