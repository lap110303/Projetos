package template_method;

public abstract class BookLoanProcess {
    protected Library library;

    public BookLoanProcess(Library library) {
        this.library = library;
    }

    public final void borrowBook(String title, User user) {
        checkAvailability(title);
        validateUser(user);
        registerLoan(title, user);
        generateBorrowReceipt(title, user);
    }

    public final void returnBook(String title, User user) {
        checkReturn(title, user);
        registerReturn(title, user);
    }

    protected void checkAvailability(String title) {
        if (!library.isAvailable(title)) {
            throw new RuntimeException("Livro indisponível: " + title);
        }
        System.out.println("Verificando disponibilidade do livro: " + title);
    }

    protected abstract void validateUser(User user);

    protected void registerLoan(String title, User user) {
        library.borrowBook(title);
        user.borrowBook();
        System.out.println("Registrando empréstimo de '" + title + "' para o usuário " + user.getName());
    }

    protected abstract void generateBorrowReceipt(String title, User user);

    protected void checkReturn(String title, User user) {
        System.out.println("Verificando devolução do livro: " + title + " pelo usuário " + user.getName());
    }

    protected void registerReturn(String title, User user) {
        library.returnBook(title);
        user.returnBook();
        System.out.println("Registrando devolução de '" + title + "' pelo usuário " + user.getName());
    }

}