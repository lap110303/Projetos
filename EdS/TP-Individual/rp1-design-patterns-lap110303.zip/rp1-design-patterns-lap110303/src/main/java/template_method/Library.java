package template_method;

import java.util.HashMap;
import java.util.Map;

public class Library {
    private Map<String, Book> books = new HashMap<>();

    public void addBook(Book book) {
        books.put(book.getTitle(), book);
    }

    public Book findBook(String title) {
        return books.get(title);
    }

    public boolean isAvailable(String title) {
        Book book = books.get(title);
        return book != null && book.isAvailable();
    }

    public void borrowBook(String title) {
        Book book = books.get(title);
        if (book != null && book.isAvailable()) {
            book.borrow();
        } else {
            throw new RuntimeException("Livro indisponível: " + title);
        }
    }

    public void returnBook(String title) {
        Book book = books.get(title);
        if (book != null && !book.isAvailable()) {
            book.giveBack();
        }
    }
}
