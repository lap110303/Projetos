package template_method;


public class User {
    private String name;
    private int borrowedBooks;
    private int maxBooks;
    private UserType userType;


    public User(String name, UserType user_type) {
        this.name = name;
        this.userType = user_type;
        this.borrowedBooks = 0;


        // Ajusta o limite de acordo com o tipo do usuário
        if (user_type == UserType.REGULAR) {
            this.maxBooks = 3;
        } else if (user_type == UserType.PREMIUM) {
            this.maxBooks = 10;
        } else {
            this.maxBooks = 3; // fallback
        }
    }


    public String getName() {
        return name;
    }


    public int getBorrowedBooks() {
        return borrowedBooks;
    }


    public int getMaxBooks() {
        return maxBooks;
    }


    public UserType getUserType() {
        return userType;
    }


    public void setMaxBooks(int max_books) {
        this.maxBooks = max_books;
    }


    // Incrementa o contador de livros emprestados (se possível)
    public void borrowBook() {
        if (borrowedBooks < maxBooks) {
            borrowedBooks += 1;
            System.out.println("Usuário " + name + " agora possui " + borrowedBooks + " livros emprestados.");
        } else {
            System.out.println("Usuário " + name + " já atingiu o limite de " + maxBooks + " livros.");
        }
    }


    // Decrementa o contador de livros emprestados (evita valores negativos)
    public void returnBook() {
        if (borrowedBooks > 0) {
            borrowedBooks -= 1;
            System.out.println("Usuário " + name + " agora possui " + borrowedBooks + " livros emprestados.");
        } else {
            System.out.println("Usuário " + name + " não possui livros para devolver.");
        }
    }
}