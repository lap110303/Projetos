package template_method;


public class UserLoan extends BookLoanProcess {
    public UserLoan (Library library) {
        super(library);
    }


    // Valida se o usuário ainda pode pegar mais livros
    @Override
    protected void validateUser(User user) {
        if (user.getBorrowedBooks() >= user.getMaxBooks()) {
            throw new IllegalStateException("Usuário " + user.getName() + " atingiu o limite de empréstimos (" + user.getMaxBooks() + ").");
        }
        System.out.println("Usuário " + user.getName() + " válido para empréstimo (" + user.getBorrowedBooks() + "/" + user.getMaxBooks() + ").");
    }


    @Override
    protected void generateBorrowReceipt(String title, User user) {
        System.out.println("Recibo: " + user.getName() + " emprestou o livro '" + title + "'.");
    }
}