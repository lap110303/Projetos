package adapter;

public class LegacyWhatsAppService {
     public void sendMessage(String userPhone, String text) {
         System.out.println("WhatsApp enviado para " + userPhone + ": " + text);
     }
}