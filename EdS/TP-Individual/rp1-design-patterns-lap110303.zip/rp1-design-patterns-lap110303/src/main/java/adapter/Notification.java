package adapter;

public interface Notification {
    void send(String message);
}
