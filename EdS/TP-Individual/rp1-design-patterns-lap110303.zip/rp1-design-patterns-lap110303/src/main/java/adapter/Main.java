package adapter;

public class Main {
    public static void main(String[] args) {
        Notification email = new EmailNotification();
        Notification sms = new SmsNotification();
        LegacyWhatsAppService legacy = new LegacyWhatsAppService();
        Notification whatsapp = new WhatsAppAdapter(legacy, "phone_number");

        LibraryNotifier email_notifier = new LibraryNotifier(email);
        LibraryNotifier sms_notifier = new LibraryNotifier(sms);
        LibraryNotifier whatsapp_notifier = new LibraryNotifier(whatsapp);

        email_notifier.notifyUser("Livro emprestado com sucesso!");
        sms_notifier.notifyUser("Livro devolvido com sucesso!");
        whatsapp_notifier.notifyUser("Lembrete: livro vencendo hoje!");
    }
}