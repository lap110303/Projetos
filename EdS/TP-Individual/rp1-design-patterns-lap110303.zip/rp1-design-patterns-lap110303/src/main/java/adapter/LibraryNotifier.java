package adapter;

public class LibraryNotifier {
    private Notification notification;

    public LibraryNotifier(Notification notification) {
        this.notification = notification;
    }

    public void notifyUser(String message) {
        notification.send(message);
    }
}
