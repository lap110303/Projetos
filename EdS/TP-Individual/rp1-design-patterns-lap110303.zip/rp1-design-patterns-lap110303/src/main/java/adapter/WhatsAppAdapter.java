package adapter;


public class WhatsAppAdapter implements Notification {
    private LegacyWhatsAppService legacy;
    private String userPhone;


    public WhatsAppAdapter(LegacyWhatsAppService legacy, String userPhone) {
        this.legacy = legacy;
        this.userPhone = userPhone;
    }


    @Override
    public void send(String message) {
        // adapta a chamada para a interface do serviço legado
        legacy.sendMessage(userPhone, message);
    }
}