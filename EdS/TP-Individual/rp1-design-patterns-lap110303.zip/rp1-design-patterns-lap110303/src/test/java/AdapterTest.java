import adapter.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

@DisplayName("Adapter Pattern")
class AdapterTest {

    private Notification email;
    private Notification sms;
    private LegacyWhatsAppService legacy;
    private Notification whatsapp;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    @BeforeEach
    void setUp() {
        email = new EmailNotification();
        sms = new SmsNotification();
        legacy = new LegacyWhatsAppService();
        whatsapp = new WhatsAppAdapter(legacy, "phone_number");

        System.setOut(new PrintStream(outContent));
    }

    @Test
    @DisplayName("Send email function test")
    void sendEmail() {
        LibraryNotifier notifier = new LibraryNotifier(email);
        assertDoesNotThrow(() -> notifier.notifyUser("Teste email"));
    }

    @Test
    @DisplayName("Send sms function test")
    void sendSms() {
        LibraryNotifier notifier = new LibraryNotifier(sms);
        assertDoesNotThrow(() -> notifier.notifyUser("Teste SMS"));
    }

    @Test
    @DisplayName("Check if class WhatsAppAdapter has a method called send.")
    void testHasValidateUserMethod() throws Exception {
        Class<?> adapterClass = WhatsAppAdapter.class;

        Method method = adapterClass.getDeclaredMethod("send", String.class);

        assertNotNull(method, "A classe WhatsAppAdapter deve ter o método send(String)");
    }

    @Test
    @DisplayName("Send default whatsapp message function test")
    void sendDefaultWhatsAppMessage() {
        LibraryNotifier notifier = new LibraryNotifier(whatsapp);
        notifier.notifyUser("Teste Default WhatsApp");

        assertTrue(outContent.toString().contains("WhatsApp enviado para"));
        outContent.reset();
    }

}