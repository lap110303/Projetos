import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Method;
import static org.junit.jupiter.api.Assertions.*;

import template_method.*;

@DisplayName("Template Method Pattern")
class TemplateMethodTest {
    private Library library;
    private User regularUser;
    private User premiumUser;
    private BookLoanProcess userLoan;

    @BeforeEach
    void setUp() {
        library = new Library();
        library.addBook(new Book("Book 1"));
        library.addBook(new Book("Book 2"));
        library.addBook(new Book("Book 3"));
        library.addBook(new Book("Book 4"));
        library.addBook(new Book("Book 5"));
        library.addBook(new Book("Book 6"));
        library.addBook(new Book("Book 7"));
        library.addBook(new Book("Book 8"));
        library.addBook(new Book("Book 9"));
        library.addBook(new Book("Book 10"));
        library.addBook(new Book("Book 11"));
        library.addBook(new Book("Book 12"));

        regularUser = new User("regular_user_name", UserType.REGULAR);
        premiumUser = new User("premium_user_name", UserType.PREMIUM);

        userLoan = new UserLoan(library);
    }

    @Test
    @DisplayName("Check if class UserLoan has a method called validateUser.")
    void testHasValidateUserMethod() throws Exception {
        Class<?> userLoanClass = UserLoan.class;

        Method method = userLoanClass.getDeclaredMethod("validateUser", User.class);

        assertNotNull(method, "A classe UserLoan deve ter o método validateUser(User)");
    }

    @Test
    @DisplayName("Check the lend book functionality.")
    void lendBook() {
        userLoan.borrowBook("Book 1", regularUser);

        assertFalse(library.isAvailable("Book 1"));
        assertEquals(1, regularUser.getBorrowedBooks());
    }

    @Test
    @DisplayName("Check error when user tries to borrow an unavailable book.")
    void errorLendingBorrowedBook() {
        userLoan.borrowBook("Book 1", regularUser);

        Exception e = assertThrows(RuntimeException.class, () -> {
            userLoan.borrowBook("Book 1", premiumUser);
        });

        assertEquals("Livro indisponível: Book 1", e.getMessage());
    }

    @Test
    @DisplayName("Check the regular user borrow limit.")
    void regularUserLimitBorrowBook() {
        userLoan.borrowBook("Book 1", regularUser);
        userLoan.borrowBook("Book 2", regularUser);
        userLoan.borrowBook("Book 3", regularUser);

        Exception e = assertThrows(RuntimeException.class, () -> {
            userLoan.borrowBook("Book 4", regularUser);
        });

        assertEquals("Usuário " + regularUser.getUserType() + " " + regularUser.getName() +
                " atingiu o limite de 3 livros.", e.getMessage());
    }

    @Test
    @DisplayName("Check the premium user borrow limit.")
    void premiumUserLimitBorrowBook() {
        for (int i = 1; i <= 10; i++) {
            userLoan.borrowBook("Book " + i, premiumUser);
        }

        Exception e = assertThrows(RuntimeException.class, () -> {
            userLoan.borrowBook("Book 11", premiumUser);
        });

        assertEquals("Usuário " + premiumUser.getUserType() + " " + premiumUser.getName() +
                " atingiu o limite de 10 livros.", e.getMessage(), e.getMessage());
    }

    @Test
    @DisplayName("Check the return book functionality.")
    void returnBook() {
        userLoan.borrowBook("Book 12", premiumUser);
        assertFalse(library.isAvailable("Book 12"));

        userLoan.returnBook("Book 12", premiumUser);
        assertTrue(library.isAvailable("Book 12"));
        assertEquals(0, premiumUser.getBorrowedBooks());
    }
}
